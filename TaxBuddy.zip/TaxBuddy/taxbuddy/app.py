"""
TaxBuddy v3 — Income Tax Filing Assistant

Professional web application for Indian Income Tax filing.
Auto-parsing, inline download guides, smart exemption calculator.
"""
from __future__ import annotations

import streamlit as st

from taxbuddy.models.taxpayer import (
    TaxPayer, EmployerInfo, HRADetails, City,
    Deductions, OtherIncome, CapitalGains,
    TaxRegime, ResidentialStatus, ITRForm, METRO_CITIES,
)

st.set_page_config(
    page_title="TaxBuddy — Income Tax Filing Assistant",
    page_icon="https://em-content.zobj.net/source/apple/391/receipt_1f9fe.png",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={"Get help": None, "Report a Bug": None, "About": None},
)

# ═══════════════════════════════════════════════════════════════════
#  PREMIUM CSS
# ═══════════════════════════════════════════════════════════════════

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

    #MainMenu, header, footer,
    .stDeployButton,
    [data-testid="stToolbar"],
    [data-testid="stDecoration"],
    [data-testid="stStatusWidget"],
    .viewerBadge_container__r5tak,
    ._profileContainer_gzau3_53,
    [data-testid="manage-app-button"] { display: none !important; visibility: hidden !important; }

    /* Hide "Made with Streamlit" */
    footer::after { content: "TaxBuddy — Income Tax Filing Assistant" !important; display: block !important;
        visibility: visible !important; color: #94A3B8; font-size: 0.7rem; text-align: center; padding: 0.5rem; }

    html, body, [class*="css"] { font-family: 'Inter', -apple-system, sans-serif !important; }

    .block-container {
        padding-top: 0.6rem;
        padding-bottom: 1rem;
        max-width: 1120px;
    }

    /* ══ SIDEBAR — always visible ══ */
    [data-testid="stSidebar"] {
        background: linear-gradient(175deg, #0F172A 0%, #1E293B 100%) !important;
        border-right: none !important;
        box-shadow: 4px 0 24px rgba(0,0,0,0.15);
        min-width: 260px !important;
        width: 280px !important;
    }
    /* Force sidebar to stay open */
    [data-testid="stSidebar"][aria-expanded="false"] {
        display: block !important;
        width: 280px !important;
        min-width: 280px !important;
        margin-left: 0 !important;
        transform: none !important;
        z-index: 999999;
    }
    section[data-testid="stSidebar"] {
        display: block !important;
        width: 280px !important;
        transform: none !important;
    }
    /* Make sure collapse button is visible */
    button[kind="header"], [data-testid="collapsedControl"],
    [data-testid="stSidebarCollapsedControl"] {
        display: block !important;
        visibility: visible !important;
    }
    [data-testid="stSidebar"] > div:first-child {
        background: transparent !important;
    }
    [data-testid="stSidebar"] .stRadio > label { display: none; }
    [data-testid="stSidebar"] .stRadio > div { gap: 2px; }
    [data-testid="stSidebar"] .stRadio > div > label {
        padding: 0.55rem 1rem;
        border-radius: 10px;
        font-size: 0.82rem;
        color: #E2E8F0 !important;
        transition: all 0.2s ease;
        border-left: 3px solid transparent;
        background: rgba(255,255,255,0.05) !important;
    }
    [data-testid="stSidebar"] .stRadio > div > label *,
    [data-testid="stSidebar"] .stRadio > div > label p,
    [data-testid="stSidebar"] .stRadio > div > label span,
    [data-testid="stSidebar"] .stRadio > div > label div {
        color: #E2E8F0 !important;
    }
    [data-testid="stSidebar"] .stRadio > div > label:hover,
    [data-testid="stSidebar"] .stRadio > div > label:hover * {
        background: rgba(255,255,255,0.10) !important;
        color: #FFFFFF !important;
    }
    /* Active step */
    [data-testid="stSidebar"] .stRadio > div > label[data-checked="true"],
    [data-testid="stSidebar"] .stRadio > div > label[aria-checked="true"],
    [data-testid="stSidebar"] .stRadio > div > label:has(input:checked) {
        background: linear-gradient(90deg, rgba(59,130,246,0.25), rgba(59,130,246,0.10)) !important;
        color: #FFFFFF !important;
        font-weight: 700 !important;
        border-left: 3px solid #3B82F6 !important;
    }
    [data-testid="stSidebar"] .stRadio > div > label[data-checked="true"] *,
    [data-testid="stSidebar"] .stRadio > div > label[aria-checked="true"] *,
    [data-testid="stSidebar"] .stRadio > div > label:has(input:checked) * {
        color: #FFFFFF !important;
        font-weight: 700 !important;
    }
    [data-testid="stSidebar"] .stMarkdown p,
    [data-testid="stSidebar"] .stMarkdown span,
    [data-testid="stSidebar"] .stMarkdown div {
        color: #94A3B8 !important;
    }
    /* Sidebar collapse button */
    [data-testid="stSidebar"] [data-testid="stSidebarCollapsedControl"] {
        color: #94A3B8;
    }

    /* ══ METRICS ══ */
    [data-testid="stMetric"] {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 14px;
        padding: 1rem 1.2rem;
        box-shadow: 0 1px 3px rgba(0,0,0,0.04), 0 6px 16px rgba(0,0,0,0.02);
        transition: box-shadow 0.2s;
    }
    [data-testid="stMetric"]:hover {
        box-shadow: 0 2px 8px rgba(0,0,0,0.06), 0 8px 24px rgba(0,0,0,0.04);
    }
    [data-testid="stMetric"] label {
        color: #64748B !important;
        font-size: 0.68rem !important;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        font-weight: 700 !important;
    }
    [data-testid="stMetricValue"] {
        color: #0F172A !important;
        font-size: 1.4rem !important;
        font-weight: 800 !important;
    }

    /* ══ EXPANDERS ══ */
    [data-testid="stExpander"] {
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        background: #FFFFFF;
        box-shadow: 0 1px 3px rgba(0,0,0,0.03);
        overflow: hidden;
    }
    [data-testid="stExpander"] summary {
        font-weight: 700;
        color: #0F172A;
    }

    /* ══ BUTTONS ══ */
    .stButton > button[kind="primary"] {
        background: linear-gradient(135deg, #2563EB 0%, #4F46E5 100%);
        border: none;
        border-radius: 10px;
        font-weight: 700;
        padding: 0.65rem 1.8rem;
        color: white;
        letter-spacing: 0.3px;
        box-shadow: 0 2px 8px rgba(37,99,235,0.25);
        transition: all 0.2s;
    }
    .stButton > button[kind="primary"]:hover {
        box-shadow: 0 4px 16px rgba(37,99,235,0.35);
        transform: translateY(-1px);
    }
    .stButton > button[kind="secondary"] {
        border-radius: 10px;
        font-weight: 600;
        border: 1px solid #E2E8F0;
    }

    hr { border-color: #F1F5F9 !important; }
    [data-testid="stAlert"] { border-radius: 12px; }

    [data-testid="stFileUploader"] section {
        border-radius: 10px;
        border: 1.5px dashed #CBD5E1;
        background: #FAFBFC;
        padding: 0.6rem 0.8rem;
    }
    [data-testid="stFileUploader"] section:hover {
        border-color: #3B82F6;
        background: #EFF6FF;
    }
    [data-testid="stFileUploader"] section small {
        font-size: 0.65rem !important;
    }

    .stTabs [data-baseweb="tab-list"] { gap: 0; border-bottom: 2px solid #F1F5F9; }
    .stTabs [data-baseweb="tab"] {
        border-radius: 0;
        padding: 10px 24px;
        font-weight: 600;
        color: #94A3B8;
    }
    .stTabs [data-baseweb="tab"][aria-selected="true"] {
        color: #2563EB;
    }

    /* ══ CUSTOM ELEMENTS ══ */
    .hero-header {
        font-size: 1.7rem;
        font-weight: 800;
        background: linear-gradient(135deg, #0F172A, #1E40AF);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: 0.15rem;
    }
    .hero-sub {
        color: #64748B;
        font-size: 0.88rem;
        margin-bottom: 1.4rem;
        line-height: 1.6;
    }

    /* doc cards handled inline */

    .section-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 0.65rem;
        color: #64748B;
        text-transform: uppercase;
        letter-spacing: 1.2px;
        font-weight: 800;
        margin-bottom: 0.6rem;
        padding: 4px 0;
        border-bottom: 2px solid #E2E8F0;
    }

    .step-pill {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 0.65rem 0.85rem;
        background: linear-gradient(135deg, #F8FAFC, #FFFFFF);
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        margin-bottom: 0.45rem;
    }
    .step-pill-num {
        min-width: 26px; height: 26px;
        background: linear-gradient(135deg, #2563EB, #4F46E5);
        color: white;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-weight: 800; font-size: 0.72rem; flex-shrink: 0;
    }
    .step-pill-text { color: #334155; font-size: 0.83rem; font-weight: 500; padding-top: 2px; }
    .step-pill-text p { color: #64748B; font-size: 0.78rem; margin: 2px 0 0; }

    .progress-track {
        display: flex;
        gap: 0;
        margin-bottom: 1.2rem;
        background: #F8FAFC;
        border-radius: 12px;
        border: 1px solid #E2E8F0;
        overflow: hidden;
        box-shadow: 0 1px 4px rgba(0,0,0,0.04);
    }
    .progress-item {
        flex: 1;
        text-align: center;
        padding: 0.55rem 0.2rem;
        font-size: 0.62rem;
        font-weight: 700;
        color: #CBD5E1;
        white-space: nowrap;
        transition: all 0.25s ease;
        border-right: 1px solid #E2E8F0;
        position: relative;
    }
    .progress-item:last-child { border-right: none; }
    .progress-item.active {
        color: #FFFFFF;
        background: linear-gradient(135deg, #2563EB, #4F46E5);
        box-shadow: inset 0 -2px 0 rgba(0,0,0,0.1);
        font-weight: 800;
    }
    .progress-item.done {
        color: #16A34A;
        background: linear-gradient(135deg, #F0FDF4, #ECFDF5);
        font-weight: 700;
    }

    .audit-card {
        background: #FFFFFF;
        border-radius: 14px;
        padding: 1rem 1.2rem;
        margin-bottom: 0.7rem;
        border-left: 4px solid #E2E8F0;
        box-shadow: 0 1px 4px rgba(0,0,0,0.04);
    }
    .audit-card.critical { border-left-color: #EF4444; background: linear-gradient(90deg, #FEF2F2, #FFFFFF); }
    .audit-card.warning { border-left-color: #F59E0B; background: linear-gradient(90deg, #FFFBEB, #FFFFFF); }
    .audit-card.info { border-left-color: #3B82F6; background: linear-gradient(90deg, #EFF6FF, #FFFFFF); }

    .result-banner {
        border-radius: 14px;
        padding: 1.1rem 1.4rem;
        margin-bottom: 1rem;
        text-align: center;
    }
    .result-banner.success {
        background: linear-gradient(135deg, #ECFDF5, #F0FDF4);
        border: 1px solid #BBF7D0;
    }
    .result-banner.info {
        background: linear-gradient(135deg, #EFF6FF, #F0F9FF);
        border: 1px solid #BFDBFE;
    }

    .url-box {
        background: #F1F5F9; border: 1px solid #E2E8F0; border-radius: 8px;
        padding: 0.5rem 1rem; font-family: monospace; font-size: 0.85rem; color: #2563EB;
        margin: 0.4rem 0 1rem;
    }
</style>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════
#  SESSION STATE
# ═══════════════════════════════════════════════════════════════════

STEPS = [
    "Upload Documents",
    "Parsed Summary",
    "AIS Audit",
    "Smart Tax Optimizer",
    "Tax Computation",
    "ITR Recommendation",
    "Filing Guide",
    "Portal Issues",
]

def init_state():
    defaults = {
        "taxpayer": TaxPayer(),
        "ais_data": None,
        "form26as_data": None,
        "documents_parsed": False,
        "form16_parsed": [],
        "validation_alerts": [],
        "audit_findings": [],
        "current_step": 0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()
tp: TaxPayer = st.session_state.taxpayer

def go_next():
    if st.session_state.current_step < len(STEPS) - 1:
        st.session_state.current_step += 1

def go_prev():
    if st.session_state.current_step > 0:
        st.session_state.current_step -= 1


# ═══════════════════════════════════════════════════════════════════
#  SIDEBAR
# ═══════════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown("""
    <div style="text-align:center; padding:1.2rem 0 0.8rem;">
        <div style="width:52px; height:52px; margin:0 auto 10px;
             background: linear-gradient(135deg, #3B82F6, #8B5CF6);
             border-radius:14px; display:flex; align-items:center;
             justify-content:center; font-size:1.5rem;
             box-shadow: 0 4px 16px rgba(59,130,246,0.35);">
            &#x1f9fe;
        </div>
        <div style="font-size:1.3rem; font-weight:800; color:#FFFFFF;
             letter-spacing:-0.5px;">TaxBuddy</div>
        <div style="color:#94A3B8; font-size:0.7rem; margin-top:4px;
             letter-spacing:0.5px;">FY 2025-26 &middot; AY 2026-27</div>
    </div>
    """, unsafe_allow_html=True)

    # Step progress indicator in sidebar
    idx = st.session_state.current_step
    progress_pct = int((idx / max(len(STEPS) - 1, 1)) * 100)
    st.markdown(f"""
    <div style="margin:0 0.8rem 0.8rem;padding:0.5rem 0.7rem;
         background:rgba(255,255,255,0.04);border-radius:10px;
         border:1px solid rgba(255,255,255,0.06);">
        <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
            <span style="font-size:0.62rem;color:#94A3B8;font-weight:600;">PROGRESS</span>
            <span style="font-size:0.62rem;color:#3B82F6;font-weight:700;">{progress_pct}%</span>
        </div>
        <div style="height:4px;background:rgba(255,255,255,0.08);border-radius:2px;overflow:hidden;">
            <div style="height:100%;width:{progress_pct}%;
                 background:linear-gradient(90deg,#3B82F6,#8B5CF6);
                 border-radius:2px;transition:width 0.3s;"></div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    chosen = st.radio("nav", STEPS, index=st.session_state.current_step,
                       label_visibility="collapsed",
                       format_func=lambda s: f"{'✓ ' if STEPS.index(s) < idx else ''}{STEPS.index(s)+1}. {s}")
    if STEPS.index(chosen) != st.session_state.current_step:
        st.session_state.current_step = STEPS.index(chosen)
        st.rerun()

    st.markdown("""
    <div style="margin-top:1.5rem; padding:0.7rem 0.8rem; background:rgba(255,255,255,0.04);
         border-radius:10px; border:1px solid rgba(255,255,255,0.06);">
        <div style="font-size:0.62rem; color:#64748B; line-height:1.6;">
            TaxBuddy assists with computation &amp; guidance.
            Always verify on the official IT portal.<br>
            All references cite the Income Tax Act, 1961.
        </div>
    </div>
    """, unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════

def page_head(title, subtitle=""):
    idx = st.session_state.current_step
    html = '<div class="progress-track">'
    for i, s in enumerate(STEPS):
        cls = "done" if i < idx else ("active" if i == idx else "")
        pfx = "✓ " if i < idx else ""
        html += f'<div class="progress-item {cls}">{pfx}{s}</div>'
    html += '</div>'
    st.markdown(html, unsafe_allow_html=True)
    st.markdown(f'<div class="hero-header">{title}</div>', unsafe_allow_html=True)
    if subtitle:
        st.markdown(f'<div class="hero-sub">{subtitle}</div>', unsafe_allow_html=True)


def nav_buttons(next_label="Next Step →", show_prev=True, show_next=True, disabled=False):
    st.markdown("<div style='height:0.8rem'></div>", unsafe_allow_html=True)
    cols = st.columns([1, 2, 1])
    with cols[0]:
        if show_prev and st.session_state.current_step > 0:
            st.button("← Back", on_click=go_prev, use_container_width=True)
    with cols[2]:
        if show_next and st.session_state.current_step < len(STEPS) - 1:
            st.button(next_label, on_click=go_next, type="primary",
                      use_container_width=True, disabled=disabled)


def section_chip(text):
    st.markdown(f'<div class="section-chip">{text}</div>', unsafe_allow_html=True)


def _headroom_bar(label, claimed, limit, suggestion=""):
    """Render a consistent claimed/limit/headroom bar with suggestion."""
    used = min(claimed, limit)
    gap = max(limit - claimed, 0)
    pct = min(used / limit * 100, 100) if limit > 0 else 0
    bar_col = "#16A34A" if pct >= 100 else "#F59E0B" if pct >= 50 else "#3B82F6"
    st.markdown(
        f'<div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:8px;padding:0.5rem 0.8rem;margin:0.4rem 0;">'
        f'<div style="display:flex;justify-content:space-between;font-size:0.75rem;margin-bottom:3px;">'
        f'<span style="font-weight:700;color:#0F172A;">{label}</span>'
        f'<span style="color:#64748B;">{fmt(used)} / {fmt(limit)}</span></div>'
        f'<div style="height:6px;background:#E2E8F0;border-radius:3px;overflow:hidden;">'
        f'<div style="height:100%;width:{pct:.0f}%;background:{bar_col};border-radius:3px;"></div></div>'
        f'</div>', unsafe_allow_html=True)
    if gap > 0 and suggestion:
        st.warning(f"⚠️ **₹{gap:,.0f} remaining** out of {fmt(limit)} limit — {suggestion}", icon="💡")
    elif gap > 0:
        st.warning(f"⚠️ **₹{gap:,.0f} remaining** out of {fmt(limit)} limit. Claim more if eligible.", icon="💡")
    elif pct >= 100:
        st.success(f"✅ {label} fully utilized — {fmt(limit)} limit reached!", icon="🎉")


def step_card(num, title, desc=""):
    desc_html = f"<p>{desc}</p>" if desc else ""
    st.markdown(f"""
    <div class="step-pill">
        <span class="step-pill-num">{num}</span>
        <div class="step-pill-text"><strong>{title}</strong>{desc_html}</div>
    </div>""", unsafe_allow_html=True)


def fmt(v):
    return f"₹{v:,.0f}" if v else "₹0"


DOWNLOAD_TIPS = {
    "form16": "From your employer's HR / Payroll department. Changed jobs? Collect from BOTH.",
    "ais": "IT Portal → Login → Services → AIS → FY 2025-26 → Download PDF",
    "26as": "IT Portal → Login → e-File → View Form 26AS → TRACES → AY 2026-27 → Export PDF",
    "payslip": "From your company's HRMS portal. Latest month is enough.",
    "mf": "camsonline.com or kfintech.com → Capital Gains Statement → FY 2025-26 → Excel",
    "itcs": "From your employer's HRMS portal. Useful if Form 16 is not yet issued (e.g., previous employer).",
}


def _doc_block(icon, color, bg, title, caption, tip_key, uploader_key, ftype="pdf", multi=False):
    """Render a single unified document upload card with header + uploader in one bordered box."""
    tip = DOWNLOAD_TIPS.get(tip_key, "")
    tip_html = f"""
    <div style="display:flex;align-items:center;gap:5px;margin-top:6px;
         padding:3px 8px;background:#F8FAFC;border-radius:5px;border:1px solid #F1F5F9;">
        <span style="font-size:0.65rem;">📥</span>
        <span style="font-size:0.65rem;color:#64748B;">{tip}</span>
    </div>""" if tip else ""

    with st.container(border=False):
        st.markdown(f"""
        <div class="doc-card" style="background:#FFFFFF;border:1px solid #E2E8F0;border-radius:14px;
             padding:0.8rem 1rem 0.4rem;margin-bottom:-1rem;
             box-shadow:0 1px 4px rgba(0,0,0,0.04);border-top:3px solid {color};">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:3px;">
                <div style="width:32px;height:32px;border-radius:8px;background:{bg};
                     display:flex;align-items:center;justify-content:center;font-size:0.95rem;flex-shrink:0;">
                    {icon}
                </div>
                <div style="flex:1;min-width:0;">
                    <div style="font-size:0.82rem;font-weight:700;color:#0F172A;line-height:1.2;">{title}</div>
                    <div style="font-size:0.68rem;color:#94A3B8;line-height:1.3;margin-top:1px;">{caption}</div>
                </div>
            </div>
            {tip_html}
        </div>""", unsafe_allow_html=True)

        types = [ftype] if isinstance(ftype, str) else ftype
        result = st.file_uploader(uploader_key, type=types, accept_multiple_files=multi,
                                  key=uploader_key, label_visibility="collapsed")
        st.markdown("<div style='height:0.3rem'></div>", unsafe_allow_html=True)
    return result


# ═══════════════════════════════════════════════════════════════════
#  STEP 1: Upload Documents (auto-parse, unified cards)
# ═══════════════════════════════════════════════════════════════════

def page_upload():
    page_head("Upload Your Tax Documents",
              "Upload each document below — TaxBuddy will auto-parse everything the moment you add files.")

    st.markdown("""<div style="font-size:0.78rem;font-weight:700;color:#334155;
         letter-spacing:0.03em;text-transform:uppercase;margin-bottom:0.4rem;">
         Required Documents</div>""", unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3, gap="medium")

    with col1:
        form16_files = _doc_block(
            "📄", "#2563EB", "#DBEAFE",
            "Form 16",
            "Employer certificate. One per employer if you switched jobs.",
            "form16", "form16_upload", multi=True)

    with col2:
        ais_file = _doc_block(
            "📊", "#D97706", "#FEF3C7",
            "AIS",
            "Salary, interest, dividends, MF transactions from all sources.",
            "ais", "ais_upload")

    with col3:
        f26_file = _doc_block(
            "🏛️", "#4F46E5", "#E0E7FF",
            "Form 26AS",
            "TDS credit proof — authoritative source for claims.",
            "26as", "f26_upload")

    st.markdown("""<div style="font-size:0.78rem;font-weight:700;color:#334155;
         letter-spacing:0.03em;text-transform:uppercase;margin:0.6rem 0 0.3rem;">
         Optional</div>""", unsafe_allow_html=True)

    payslip_file = _doc_block(
        "📎", "#64748B", "#F1F5F9",
        "Salary Slip (any one month, e.g. March 2026)",
        "Auto-detects Basic, HRA, LTA, Special Allowance for accurate exemption pre-fill.",
        "payslip", "payslip_upload")

    mf_file = None
    itcs_files = None

    has_files = any([form16_files, ais_file, f26_file, payslip_file])

    file_sig = "|".join(sorted([
        f.name for f in (form16_files or [])
    ] + [
        ais_file.name if ais_file else "",
        f26_file.name if f26_file else "",
        payslip_file.name if payslip_file else "",
    ]))
    prev_sig = st.session_state.get("_file_sig", "")

    if has_files and (not st.session_state.documents_parsed or file_sig != prev_sig):
        st.session_state["_file_sig"] = file_sig
        _parse_all(form16_files, ais_file, f26_file, payslip_file, mf_file, itcs_files)

    if st.session_state.documents_parsed:
        tp = st.session_state.taxpayer
        total_gross = sum(e.gross_salary for e in tp.employers)
        total_tds = sum(e.tds_deducted for e in tp.employers)
        audit_count = len(st.session_state.audit_findings)
        st.markdown(f"""
        <div style="background:linear-gradient(135deg,#ECFDF5,#F0FDF4);border:1px solid #BBF7D0;
             border-radius:14px;padding:1rem 1.2rem;margin-top:0.5rem;">
            <div style="font-weight:800;color:#166534;font-size:1rem;margin-bottom:0.5rem;">
                ✓ All Documents Parsed
            </div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0.5rem;">
                <div style="text-align:center;background:white;padding:0.5rem;border-radius:10px;border:1px solid #BBF7D0;">
                    <div style="font-size:0.58rem;color:#64748B;text-transform:uppercase;font-weight:700;">Salary</div>
                    <div style="font-size:1.05rem;font-weight:800;color:#0F172A;">{fmt(total_gross)}</div>
                </div>
                <div style="text-align:center;background:white;padding:0.5rem;border-radius:10px;border:1px solid #BBF7D0;">
                    <div style="font-size:0.58rem;color:#64748B;text-transform:uppercase;font-weight:700;">TDS</div>
                    <div style="font-size:1.05rem;font-weight:800;color:#0F172A;">{fmt(total_tds)}</div>
                </div>
                <div style="text-align:center;background:white;padding:0.5rem;border-radius:10px;border:1px solid #BBF7D0;">
                    <div style="font-size:0.58rem;color:#64748B;text-transform:uppercase;font-weight:700;">Employers</div>
                    <div style="font-size:1.05rem;font-weight:800;color:#0F172A;">{len(tp.employers)}</div>
                </div>
                <div style="text-align:center;background:white;padding:0.5rem;border-radius:10px;border:1px solid #BBF7D0;">
                    <div style="font-size:0.58rem;color:#64748B;text-transform:uppercase;font-weight:700;">Audit Flags</div>
                    <div style="font-size:1.05rem;font-weight:800;color:{'#DC2626' if audit_count > 0 else '#16A34A'};">{audit_count}</div>
                </div>
            </div>
        </div>""", unsafe_allow_html=True)

    nav_buttons("Next: Parsed Summary →", disabled=(not st.session_state.documents_parsed))


def _parse_all(form16_files, ais_file, f26_file, payslip_file, mf_file, itcs_files=None):
    import tempfile, os
    total = sum([len(form16_files) if form16_files else 0,
                 len(itcs_files) if itcs_files else 0,
                 1 if ais_file else 0, 1 if f26_file else 0,
                 1 if payslip_file else 0, 1 if mf_file else 0])
    if total == 0:
        return

    bar = st.progress(0, text="Parsing documents...")
    cur = 0
    def _save_tmp(uploaded, suffix):
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
            f.write(uploaded.read()); return f.name

    if form16_files:
        st.session_state.taxpayer.employers = []
        st.session_state.form16_parsed = []
        for f in form16_files:
            cur += 1; bar.progress(cur / total, f"Parsing Form 16: {f.name}")
            try:
                from taxbuddy.parsers.form16 import parse_form16
                p = _save_tmp(f, ".pdf"); emp = parse_form16(p); os.unlink(p)
                if emp:
                    st.session_state.taxpayer.employers.append(emp)
                    st.session_state.form16_parsed.append({
                        "employer": emp.name, "tan": emp.tan,
                        "gross": emp.gross_salary, "tds": emp.tds_deducted,
                        "regime": emp.regime_at_employer.value,
                    })
            except Exception as e:
                st.error(f"Form 16 error: {e}")

    # Auto-fill taxpayer name/PAN from Form 16 if not already set
    tp = st.session_state.taxpayer
    for emp in tp.employers:
        if not tp.pan and emp.pan:
            tp.pan = emp.pan
        if not tp.name and emp.name:
            tp.name = emp.name

    # Transfer Form 16 deductions to taxpayer.deductions model
    ded = st.session_state.taxpayer.deductions
    for emp in st.session_state.taxpayer.employers:
        exm = emp.sec10_exemptions
        f16_80c = exm.get("deduction_80C", 0)
        if f16_80c > ded.sec_80c:
            ded.sec_80c = f16_80c
        f16_1b = exm.get("deduction_80CCD_1B", 0)
        if f16_1b > ded.sec_80ccd_1b:
            ded.sec_80ccd_1b = f16_1b
        f16_2 = exm.get("deduction_80CCD_2", 0)
        ded.sec_80ccd_2 += f16_2
        f16_80d = exm.get("deduction_80D", 0)
        if f16_80d > 0 and ded.sec_80d_self == 0:
            ded.sec_80d_self = min(f16_80d, 25000)
            if f16_80d > 25000:
                ded.sec_80d_parents = min(f16_80d - 25000, 50000)

    # Parse ITCS (IT Computation Sheet) — alternative to Form 16
    if itcs_files:
        for f in itcs_files:
            cur += 1; bar.progress(cur / total, f"Parsing ITCS: {f.name}")
            try:
                from taxbuddy.parsers.itcs import parse_itcs
                p = _save_tmp(f, ".pdf"); emp = parse_itcs(p); os.unlink(p)
                if emp and emp.gross_salary > 0:
                    # Check if this employer (by TAN) is already added from Form 16
                    existing = [e for e in st.session_state.taxpayer.employers if e.tan == emp.tan]
                    if existing:
                        # Merge ITCS data into existing employer (fill gaps)
                        ex = existing[0]
                        if ex.basic_salary == 0 and emp.basic_salary > 0:
                            ex.basic_salary = emp.basic_salary
                        if ex.hra_received == 0 and emp.hra_received > 0:
                            ex.hra_received = emp.hra_received
                        if ex.lta_received == 0 and emp.lta_received > 0:
                            ex.lta_received = emp.lta_received
                        if ex.bonus == 0 and emp.bonus > 0:
                            ex.bonus = emp.bonus
                        st.toast(f"📑 ITCS merged into existing employer: {ex.name}")
                    else:
                        st.session_state.taxpayer.employers.append(emp)
                        st.session_state.form16_parsed.append({
                            "employer": emp.name, "tan": emp.tan,
                            "gross": emp.gross_salary, "tds": emp.tds_deducted,
                            "regime": emp.regime_at_employer.value,
                            "source": "ITCS",
                        })
                        st.toast(f"📑 ITCS parsed: {emp.name} — Salary ₹{emp.gross_salary:,.0f}")

                        # Transfer ITCS deductions
                        exm = emp.sec10_exemptions
                        ded = st.session_state.taxpayer.deductions
                        for key, attr in [("deduction_80C", "sec_80c"), ("deduction_80CCD_1B", "sec_80ccd_1b")]:
                            v = exm.get(key, 0)
                            if v > getattr(ded, attr):
                                setattr(ded, attr, v)
                        if exm.get("deduction_80CCD_2", 0) > 0:
                            ded.sec_80ccd_2 += exm["deduction_80CCD_2"]
            except Exception as e:
                st.error(f"ITCS error: {e}")

    if ais_file:
        cur += 1; bar.progress(cur / total, "Parsing AIS...")
        try:
            from taxbuddy.parsers.ais import parse_ais
            p = _save_tmp(ais_file, ".pdf"); data = parse_ais(p); os.unlink(p)
            st.session_state.ais_data = data
            if data.get("pan"): st.session_state.taxpayer.pan = data["pan"]
            if data.get("name"): st.session_state.taxpayer.name = data["name"]
            if data.get("interest_savings", 0) > 0:
                st.session_state.taxpayer.other_income.interest_savings = data["interest_savings"]
            if data.get("interest_fd", 0) > 0:
                st.session_state.taxpayer.other_income.interest_fd = data["interest_fd"]
            if data.get("dividend_income", 0) > 0:
                st.session_state.taxpayer.other_income.dividend = data["dividend_income"]
            emp_count = data.get("employer_count", 0)
            st.toast(f"✅ AIS parsed — {emp_count} employer(s), "
                     f"Interest: ₹{data.get('interest_income', 0):,.0f}")
        except Exception as e:
            st.error(f"AIS parsing failed: {e}")
            st.session_state.ais_data = None

    if f26_file:
        cur += 1; bar.progress(cur / total, "Parsing Form 26AS...")
        try:
            from taxbuddy.parsers.form26as import parse_form26as
            p = _save_tmp(f26_file, ".pdf"); d = parse_form26as(p); os.unlink(p)
            st.session_state.form26as_data = d
        except Exception as e:
            st.error(f"26AS error: {e}")

    if payslip_file:
        cur += 1; bar.progress(cur / total, "Parsing Payslip...")
        try:
            from taxbuddy.parsers.payslip import parse_payslip
            p = _save_tmp(payslip_file, ".pdf"); d = parse_payslip(p); os.unlink(p)
            st.session_state["payslip_data"] = d
            tp = st.session_state.taxpayer

            ps_employer = (d.get("employer_name") or "").lower()
            monthly_basic = d.get("earnings", {}).get("basic", 0)
            monthly_hra = d.get("earnings", {}).get("hra", 0)
            cum_basic = d.get("tax_calculation", {}).get("cumulative_basic", 0)

            # Match payslip to correct employer only
            for emp in tp.employers:
                emp_name_lower = (emp.name or "").lower()
                if not ps_employer or not emp_name_lower:
                    continue
                # Fuzzy match: check if key words overlap
                ps_words = set(w for w in ps_employer.split() if len(w) > 3)
                emp_words = set(w for w in emp_name_lower.split() if len(w) > 3)
                if ps_words & emp_words:
                    if emp.basic_salary == 0:
                        emp.basic_salary = cum_basic if cum_basic > 0 else monthly_basic * 12
                    if emp.hra_received == 0 and monthly_hra > 0:
                        emp.hra_received = monthly_hra * 12

            # Pre-fill HRA rent from investment declarations
            rent_annual = d.get("investment_declarations", {}).get("hra_rent_paid", 0)
            if rent_annual > 0:
                rent_monthly = rent_annual / 12
                if not tp.hra_details or tp.hra_details.rent_paid_monthly == 0:
                    tp.hra_details = HRADetails(
                        rent_paid_monthly=rent_monthly,
                        rent_paid_annual=rent_annual,
                        total_basic_salary=tp.total_basic_salary,
                        total_hra_received=tp.total_hra_received,
                    )

            if not tp.name and d.get("employee_name"):
                tp.name = d["employee_name"]
            if not tp.pan and d.get("pan"):
                tp.pan = d["pan"]

            st.toast(f"✅ Payslip parsed — {d.get('employer_name', 'Employer')}, {d.get('month', '')}")
        except Exception as e:
            st.error(f"Payslip error: {e}")

    if mf_file:
        cur += 1; bar.progress(cur / total, "Parsing MF Report...")
        try:
            from taxbuddy.parsers.mutual_funds import parse_mutual_fund_sheet
            p = _save_tmp(mf_file, ".xlsx"); cg = parse_mutual_fund_sheet(p); os.unlink(p)
            st.session_state.taxpayer.capital_gains = cg
            st.session_state.taxpayer.has_capital_gains = (cg.stcg_111a != 0 or cg.ltcg_112a != 0)
        except Exception as e:
            st.error(f"MF error: {e}")

    # Estimate basic/HRA if still missing (typical: Basic=40% of CTC, HRA=50% of Basic)
    for emp in st.session_state.taxpayer.employers:
        if emp.basic_salary == 0 and emp.gross_salary > 0:
            emp.basic_salary = round(emp.gross_salary * 0.40)
        if emp.hra_received == 0 and emp.basic_salary > 0:
            emp.hra_received = round(emp.basic_salary * 0.50)

    bar.progress(0.9, "Running audit checks...")
    try:
        from taxbuddy.engine.cross_validator import cross_validate
        st.session_state.validation_alerts = cross_validate(
            st.session_state.taxpayer.employers,
            st.session_state.ais_data, st.session_state.form26as_data,
            taxpayer=st.session_state.taxpayer)

        # Update form16_parsed with any auto-added AIS employers
        existing_tans = {f["tan"] for f in st.session_state.form16_parsed}
        for emp in st.session_state.taxpayer.employers:
            if emp.tan and emp.tan not in existing_tans:
                st.session_state.form16_parsed.append({
                    "employer": emp.name, "tan": emp.tan,
                    "gross": emp.gross_salary, "tds": emp.tds_deducted,
                    "regime": emp.regime_at_employer.value,
                    "source": "AIS",
                })
    except Exception:
        pass
    try:
        from taxbuddy.engine.ais_auditor import run_ais_audit
        st.session_state.audit_findings = run_ais_audit(
            st.session_state.taxpayer,
            st.session_state.ais_data, st.session_state.form26as_data)
    except Exception:
        pass

    # Estimate basic/HRA for employers where Form 16 doesn't provide breakup
    # Standard Indian MNC structure: Basic ≈ 40% of gross, HRA ≈ 50% of basic
    tp = st.session_state.taxpayer
    for emp in tp.employers:
        if emp.gross_salary > 0 and emp.basic_salary == 0:
            emp.basic_salary = round(emp.gross_salary * 0.40)
            emp._basic_estimated = True
        if emp.gross_salary > 0 and emp.hra_received == 0:
            emp.hra_received = round(emp.basic_salary * 0.50)
            emp._hra_estimated = True

    # Re-fill HRA details from payslip rent after basic/HRA estimation
    psd = st.session_state.get("payslip_data")
    if psd:
        rent_annual = psd.get("investment_declarations", {}).get("hra_rent_paid", 0)
        if rent_annual > 0:
            rent_monthly = rent_annual / 12
            tp.hra_details = HRADetails(
                rent_paid_monthly=rent_monthly,
                rent_paid_annual=rent_annual,
                total_basic_salary=tp.total_basic_salary,
                total_hra_received=tp.total_hra_received,
            )

    st.session_state.documents_parsed = True
    bar.empty()


# ═══════════════════════════════════════════════════════════════════
#  STEP 2: Parsed Summary
# ═══════════════════════════════════════════════════════════════════

def page_summary():
    page_head("Parsed Summary", "Everything extracted from your documents at a glance.")
    if not st.session_state.documents_parsed:
        st.info("Upload documents first."); nav_buttons(); return

    tp = st.session_state.taxpayer
    total_gross = sum(e.gross_salary for e in tp.employers)
    total_tds = sum(e.tds_deducted for e in tp.employers)
    interest = tp.other_income.interest_savings + tp.other_income.interest_fd

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Gross Salary", fmt(total_gross))
    m2.metric("TDS Deducted", fmt(total_tds))
    m3.metric("Interest Income", fmt(interest))
    m4.metric("Audit Findings", str(len(st.session_state.audit_findings)))

    st.divider()

    if st.session_state.form16_parsed:
        section_chip("📄 Employers")
        for i, f16 in enumerate(st.session_state.form16_parsed):
            source = f16.get("source", "Form 16")
            badge_map = {"Form 16": "", "AIS": " ⚠️ *from AIS (no Form 16)*", "ITCS": " 📑 *from IT Computation Sheet*"}
            badge = badge_map.get(source, "")
            with st.expander(f"**{f16['employer'] or 'Employer'}** — TAN: `{f16['tan']}`{badge}", expanded=True):
                if source == "AIS":
                    st.warning("This employer's data was auto-filled from AIS because no Form 16 was uploaded. "
                               "Get Form 16 for detailed salary breakup (Basic, HRA, etc.).", icon="⚠️")
                elif source == "ITCS":
                    st.info("This employer's data was parsed from ITCS (IT Computation Sheet). "
                            "TaxBuddy extracted full salary breakup including Basic, HRA, and TDS.", icon="📑")
                c1, c2, c3 = st.columns(3)
                c1.metric("Gross Salary", fmt(f16['gross']))
                c2.metric("TDS Deducted", fmt(f16['tds']))
                c3.metric("Source", source)
                emp = tp.employers[i] if i < len(tp.employers) else None
                if emp:
                    items = []
                    est_tag = " *(estimated)*" if getattr(emp, '_basic_estimated', False) else ""
                    if emp.basic_salary > 0: items.append(f"Basic: {fmt(emp.basic_salary)}{est_tag}")
                    hra_tag = " *(estimated)*" if getattr(emp, '_hra_estimated', False) else ""
                    if emp.hra_received > 0: items.append(f"HRA Received: {fmt(emp.hra_received)}{hra_tag}")
                    if emp.pf_employee > 0: items.append(f"EPF: {fmt(emp.pf_employee)}")
                    if emp.nps_employer > 0: items.append(f"NPS (Employer): {fmt(emp.nps_employer)}")
                    if emp.standard_deduction > 0: items.append(f"Std Deduction: {fmt(emp.standard_deduction)}")
                    if emp.professional_tax > 0: items.append(f"Prof Tax: {fmt(emp.professional_tax)}")
                    for k, lbl in [("deduction_80C","80C"),("deduction_80CCD_1B","80CCD(1B)"),("deduction_80D","80D")]:
                        v = emp.sec10_exemptions.get(k, 0)
                        if v > 0: items.append(f"{lbl}: {fmt(v)}")
                    if items:
                        c1, c2 = st.columns(2)
                        with c1:
                            for it in items[:len(items)//2+1]: st.markdown(f"- {it}")
                        with c2:
                            for it in items[len(items)//2+1:]: st.markdown(f"- {it}")

    ais = st.session_state.ais_data
    if ais:
        st.divider()
        section_chip("📊 AIS — Annual Information Statement")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Employers in AIS", str(ais.get("employer_count", 0)))
        c2.metric("Savings Interest", fmt(ais.get('interest_savings', 0)))
        c3.metric("FD Interest", fmt(ais.get('interest_fd', 0)))
        c4.metric("MF Sales", fmt(ais.get('mf_sale_total', 0)))

    # ── Payslip Summary ──
    psd = st.session_state.get("payslip_data")
    if psd:
        st.divider()
        section_chip("💰 Payslip Summary")
        c1, c2, c3 = st.columns(3)
        c1.metric("Month", psd.get("month", "N/A"))
        c2.metric("Net Salary", fmt(psd.get("net_salary", 0)))
        c3.metric("Designation", psd.get("designation", "N/A"))

        earn = psd.get("earnings", {})
        ded_ps = psd.get("deductions", {})
        tax_calc = psd.get("tax_calculation", {})
        with st.expander("Earnings & Deductions", expanded=False):
            c1, c2 = st.columns(2)
            with c1:
                st.markdown("**Earnings (Monthly)**")
                for k, v in earn.items():
                    if v > 0: st.markdown(f"- {k.replace('_',' ').title()}: {fmt(v)}")
            with c2:
                st.markdown("**Deductions (Monthly)**")
                for k, v in ded_ps.items():
                    if v > 0: st.markdown(f"- {k.replace('_',' ').title()}: {fmt(v)}")
            if tax_calc:
                st.markdown("**Tax Calculation (Cumulative)**")
                c1, c2, c3 = st.columns(3)
                c1.metric("Gross Taxable", fmt(tax_calc.get("gross_taxable_income", 0)))
                c2.metric("Std Deduction", fmt(tax_calc.get("standard_deduction", 0)))
                c3.metric("Tax Payable", fmt(tax_calc.get("tax_payable", 0)))

    # ── Consolidated Summary across all employers ──
    st.divider()
    section_chip("📊 Consolidated Income & Tax Summary")
    total_basic = tp.total_basic_salary
    total_hra_r = tp.total_hra_received
    total_epf = sum(e.pf_employee for e in tp.employers)
    total_nps = sum(e.nps_employer for e in tp.employers)
    total_std = sum(e.standard_deduction for e in tp.employers)
    total_ptax = sum(e.professional_tax for e in tp.employers)

    st.markdown(f"""
    <div style="background:#FAFBFC;border:1px solid #E2E8F0;border-radius:12px;padding:0.8rem 1rem;">
        <table style="width:100%;font-size:0.82rem;border-collapse:collapse;">
        <tr style="background:#F1F5F9;"><th style="text-align:left;padding:6px 10px;">Component</th><th style="text-align:right;padding:6px 10px;">Amount</th></tr>
        <tr><td style="padding:4px 10px;">Gross Salary (all employers)</td><td style="text-align:right;padding:4px 10px;font-weight:700;">₹{total_gross:,.0f}</td></tr>
        <tr><td style="padding:4px 10px;">Basic Salary</td><td style="text-align:right;padding:4px 10px;">₹{total_basic:,.0f}</td></tr>
        <tr><td style="padding:4px 10px;">HRA Received</td><td style="text-align:right;padding:4px 10px;">₹{total_hra_r:,.0f}</td></tr>
        <tr><td style="padding:4px 10px;">EPF (Employee)</td><td style="text-align:right;padding:4px 10px;">₹{total_epf:,.0f}</td></tr>
        <tr><td style="padding:4px 10px;">NPS (Employer)</td><td style="text-align:right;padding:4px 10px;">₹{total_nps:,.0f}</td></tr>
        <tr style="background:#F1F5F9;"><td style="padding:4px 10px;">Standard Deduction</td><td style="text-align:right;padding:4px 10px;">₹{total_std:,.0f}</td></tr>
        <tr><td style="padding:4px 10px;">Professional Tax</td><td style="text-align:right;padding:4px 10px;">₹{total_ptax:,.0f}</td></tr>
        <tr style="background:#F1F5F9;"><td style="padding:4px 10px;">Interest Income (Savings + FD)</td><td style="text-align:right;padding:4px 10px;">₹{interest:,.0f}</td></tr>
        <tr style="border-top:2px solid #3B82F6;"><td style="padding:6px 10px;font-weight:800;">Total TDS Deducted</td><td style="text-align:right;padding:6px 10px;font-weight:800;color:#166534;">₹{total_tds:,.0f}</td></tr>
        </table>
    </div>""", unsafe_allow_html=True)

    nav_buttons("Next: AIS Audit →")


# ═══════════════════════════════════════════════════════════════════
#  STEP 3: AIS Audit
# ═══════════════════════════════════════════════════════════════════

def page_ais_audit():
    page_head("Document Cross-Check & Audit",
              "Compares your Form 16, AIS, and Form 26AS to flag discrepancies before you file.")
    if not st.session_state.documents_parsed:
        st.info("Upload documents first."); nav_buttons(); return

    tp = st.session_state.taxpayer
    ais = st.session_state.ais_data
    f26 = st.session_state.form26as_data
    findings = st.session_state.audit_findings
    alerts = st.session_state.validation_alerts

    # ── Document Status Banner ──
    doc_items = []
    doc_items.append(("Form 16", len(tp.employers) > 0,
                      f"{len(tp.employers)} employer(s)" if tp.employers else "Not uploaded"))
    doc_items.append(("AIS", ais is not None,
                      f"{ais.get('employer_count', 0)} employers, "
                      f"Interest ₹{ais.get('interest_income', 0):,.0f}"
                      if ais else "Not uploaded"))
    doc_items.append(("Form 26AS", f26 is not None,
                      "Parsed" if f26 else "Not uploaded"))
    if st.session_state.get("payslip_data"):
        doc_items.append(("Payslip", True, "Parsed"))

    doc_html = ""
    for name, ok, desc in doc_items:
        icon = "✅" if ok else "⬜"
        color = "#166534" if ok else "#94A3B8"
        bg = "#F0FDF4" if ok else "#F8FAFC"
        border = "#BBF7D0" if ok else "#E2E8F0"
        doc_html += (
            f'<div style="background:{bg};border:1px solid {border};border-radius:10px;'
            f'padding:0.5rem 0.7rem;text-align:center;">'
            f'<div style="font-size:0.9rem;">{icon}</div>'
            f'<div style="font-size:0.72rem;font-weight:700;color:{color};">{name}</div>'
            f'<div style="font-size:0.6rem;color:#94A3B8;">{desc}</div></div>'
        )
    st.markdown(f'<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0.5rem;'
                f'margin-bottom:1rem;">{doc_html}</div>', unsafe_allow_html=True)

    # ── AIS Data Summary (if uploaded) ──
    if ais:
        st.divider()
        section_chip("📊 AIS Data Summary — What IT Department Sees")

        ais_employers = ais.get("salary_tds", [])
        f16_tans = {e.tan for e in tp.employers if e.tan}

        for entry in ais_employers:
            has_f16 = entry.tan in f16_tans
            status_icon = "✅" if has_f16 else "⚠️"
            status_text = "Form 16 uploaded" if has_f16 else "**Form 16 MISSING** — using AIS data"
            status_bg = "#F0FDF4" if has_f16 else "#FFFBEB"
            status_border = "#BBF7D0" if has_f16 else "#FDE68A"
            st.markdown(f"""
            <div style="background:{status_bg};border:1px solid {status_border};border-radius:10px;
                 padding:0.6rem 0.9rem;margin-bottom:0.4rem;">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <div>
                        <span style="font-weight:700;color:#0F172A;font-size:0.85rem;">
                            {status_icon} {entry.deductor_name or 'Unknown'}
                        </span>
                        <span style="font-size:0.68rem;color:#94A3B8;margin-left:8px;">
                            TAN: {entry.tan}
                        </span>
                    </div>
                    <div style="font-size:0.68rem;color:#64748B;">{status_text}</div>
                </div>
                <div style="display:flex;gap:1.5rem;margin-top:0.3rem;">
                    <span style="font-size:0.75rem;color:#475569;">
                        Salary: <b>₹{entry.income_credited:,.0f}</b>
                    </span>
                    <span style="font-size:0.75rem;color:#475569;">
                        TDS: <b>₹{entry.tds_deducted:,.0f}</b>
                    </span>
                </div>
            </div>""", unsafe_allow_html=True)

        # Other income from AIS
        other_items = []
        if ais.get("interest_savings", 0) > 0:
            other_items.append(("Savings Interest", ais["interest_savings"], "SFT-016(SB)", "info"))
        if ais.get("interest_fd", 0) > 0:
            other_items.append(("FD / Term Deposit Interest", ais["interest_fd"], "SFT-016(TD)", "info"))
        if ais.get("dividend_income", 0) > 0:
            other_items.append(("Dividend Income", ais["dividend_income"], "Dividend", "info"))
        if ais.get("mf_sale_total", 0) > 0:
            other_items.append(("Mutual Fund Redemptions", ais["mf_sale_total"], "SFT-18-EMF", "warning"))
        if ais.get("property_transactions"):
            for pt in ais["property_transactions"]:
                other_items.append(("Property Transaction", pt["amount"], "194IA", "warning"))

        if other_items:
            st.markdown("")
            section_chip("💰 Other Transactions in AIS")

            for label, amount, code, sev in other_items:
                icon = "ℹ️" if sev == "info" else "⚠️"
                with st.expander(f"{icon} **{label}** ({code}) — **₹{amount:,.0f}**"):
                    # Savings Interest details
                    if code == "SFT-016(SB)" and ais.get("savings_details"):
                        for sd in ais["savings_details"]:
                            st.markdown(f"**{sd['source']}** — ₹{sd['amount']:,.0f}")
                            for entry in sd.get("entries", []):
                                acct = entry.get("account", "")
                                st.markdown(f"- Account: `{acct}` — ₹{entry['amount']:,.0f}")
                    # FD Interest details
                    elif code == "SFT-016(TD)" and ais.get("fd_details"):
                        for fd in ais["fd_details"]:
                            st.markdown(f"**{fd['source']}** — ₹{fd['amount']:,.0f}")
                            for entry in fd.get("entries", []):
                                acct = entry.get("account", "")
                                st.markdown(f"- Account: `{acct}` — ₹{entry['amount']:,.0f}")
                    # MF Sales details
                    elif code == "SFT-18-EMF" and ais.get("mf_sale_details"):
                        for md in ais["mf_sale_details"]:
                            st.markdown(f"**Source:** {md['source']} — Total: ₹{md['amount']:,.0f}")
                            txns = md.get("transactions", [])
                            if txns:
                                for tx in txns:
                                    t = tx.get("type", "")
                                    type_badge = f" `{t}`" if t else ""
                                    st.markdown(
                                        f"- {tx.get('date', '')} | **{tx.get('fund', 'MF')}**{type_badge} — ₹{tx['amount']:,.0f}"
                                    )
                            else:
                                st.caption("Individual transaction details not available in parsed data.")
                    # Property details
                    elif code == "194IA":
                        for pt in ais.get("property_transactions", []):
                            entries = pt.get("entries", [])
                            if entries:
                                for pe in entries:
                                    addr = pe.get("address", "N/A")
                                    st.markdown(f"- **{pe.get('date', '')}** — ₹{pe['amount']:,.0f}")
                                    if addr:
                                        st.caption(f"  📍 {addr}")
                            else:
                                st.markdown(f"Total: ₹{pt['amount']:,.0f}")
                    else:
                        st.markdown(f"Total amount reported: **₹{amount:,.0f}**")

    # ── Audit Findings (from ais_auditor.py) ──
    if findings:
        st.divider()
        section_chip("🔍 IT Department Audit Checks")

        critical = [f for f in findings if f.severity == "critical"]
        warnings = [f for f in findings if f.severity == "warning"]
        infos = [f for f in findings if f.severity == "info"]

        c1, c2, c3 = st.columns(3)
        if critical: c1.error(f"**{len(critical)}** Critical")
        else: c1.success("**0** Critical")
        if warnings: c2.warning(f"**{len(warnings)}** Warning(s)")
        else: c2.success("**0** Warnings")
        c3.info(f"**{len(infos)}** Info")

        for finding in findings:
            icon = {"critical": "🚨", "warning": "⚠️", "info": "ℹ️"}.get(finding.severity, "ℹ️")
            risk_color = {"High": "#DC2626", "Medium": "#F59E0B", "Low": "#16A34A"}.get(finding.notice_risk, "#64748B")
            st.markdown(f"""
            <div class="audit-card {finding.severity}">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.3rem;">
                    <div style="font-weight:700;color:#0F172A;font-size:0.85rem;">{icon} {finding.title}</div>
                    <div style="font-size:0.6rem;font-weight:700;color:{risk_color};
                         background:{risk_color}12;padding:2px 8px;border-radius:8px;">
                        Risk: {finding.notice_risk}
                    </div>
                </div>
                <div style="font-size:0.78rem;color:#475569;margin-bottom:0.3rem;">{finding.detail.replace(chr(10), '<br>')}</div>
                <div style="font-size:0.7rem;color:#64748B;border-top:1px solid #F1F5F9;padding-top:0.3rem;">
                    <b>Section:</b> {finding.section} &nbsp;|&nbsp;
                    <b>Yours:</b> {fmt(finding.itr_value)} &nbsp;|&nbsp;
                    <b>AIS:</b> {fmt(finding.ais_value)}
                </div>
                <div style="font-size:0.75rem;color:#1E40AF;background:#EFF6FF;padding:0.3rem 0.6rem;
                     border-radius:6px;margin-top:0.3rem;">
                    💡 <b>Fix:</b> {finding.action}
                </div>
            </div>""", unsafe_allow_html=True)

    # ── Cross-Validation Alerts ──
    if alerts:
        st.divider()
        section_chip("⚡ Cross-Validation Alerts")
        for alert in alerts:
            icon = {"critical": "🚨", "warning": "⚠️", "info": "ℹ️"}.get(alert.severity, "ℹ️")
            border_color = {"critical": "#EF4444", "warning": "#F59E0B", "info": "#3B82F6"}.get(alert.severity, "#94A3B8")
            bg = {"critical": "#FEF2F2", "warning": "#FFFBEB", "info": "#EFF6FF"}.get(alert.severity, "#F8FAFC")
            with st.expander(f"{icon}  **{alert.title}**", expanded=(alert.severity == "critical")):
                st.markdown(alert.detail)
                st.markdown(
                    f'<div style="background:{bg};border-left:3px solid {border_color};'
                    f'padding:0.5rem 0.8rem;border-radius:6px;margin-top:0.5rem;'
                    f'font-size:0.82rem;">'
                    f'<b>👉 Action:</b> {alert.action}</div>',
                    unsafe_allow_html=True,
                )

    # ── All clear ──
    if not findings and not alerts:
        st.markdown("""
        <div class="result-banner success">
            <div style="font-size:2rem;">✅</div>
            <div style="font-size:1.05rem;font-weight:800;color:#166534;margin-top:0.3rem;">
                All Clear — No Red Flags Found
            </div>
            <div style="color:#16A34A;font-size:0.85rem;">
                Your documents are consistent. Low risk of IT notice.
            </div>
        </div>""", unsafe_allow_html=True)

    nav_buttons("Next: Smart Tax Optimizer →")


# ═══════════════════════════════════════════════════════════════════
#  STEP 4: Smart Tax Optimizer
# ═══════════════════════════════════════════════════════════════════

def page_smart_optimizer():
    page_head("Smart Tax Optimizer",
              "Auto-computes all exemptions from your documents. Only fill what's missing.")

    tp = st.session_state.taxpayer

    st.markdown("""
    <div style="background:linear-gradient(135deg,#EFF6FF,#F0F9FF); border:1px solid #BFDBFE;
         border-radius:12px; padding:0.65rem 1rem; margin-bottom:1.2rem; display:flex; align-items:center; gap:10px;">
        <div style="font-size:1.2rem;">🤖</div>
        <div style="font-size:0.82rem; color:#1E40AF;">
            Values marked <span style="background:#DBEAFE;padding:1px 8px;border-radius:4px;font-size:0.7rem;font-weight:700;">AUTO</span>
            are extracted from your documents. Fill the rest — TaxBuddy calculates the optimal exemption.
        </div>
    </div>""", unsafe_allow_html=True)

    with st.expander("**👤 Personal Info** — for HRA city classification", expanded=True):
        c1, c2, c3 = st.columns(3)
        tp.name = c1.text_input("Name (as per PAN)", value=tp.name, key="o_name")
        tp.pan = c2.text_input("PAN", value=tp.pan, key="o_pan")
        tp.city = c3.text_input("City of Residence", value=tp.city or "Bangalore", key="o_city")

    is_metro = tp.city.lower().strip() in METRO_CITIES if tp.city else False

    # ── HRA: Editable Basic & HRA with correct sum across all employers ──
    st.divider()
    section_chip("🏠 Section 10(13A) — HRA Exemption")

    with st.expander("**HRA Calculation** — All 3 criteria auto-computed", expanded=True):
        city_label = "Metro (50%)" if is_metro else "Non-Metro (40%)"
        auto_basic = tp.total_basic_salary
        auto_hra_r = tp.total_hra_received
        if auto_hra_r == 0 and auto_basic > 0:
            auto_hra_r = round(auto_basic * 0.50)

        has_estimate = any(getattr(e, '_basic_estimated', False) for e in tp.employers)
        if has_estimate:
            est_names = [e.name for e in tp.employers if getattr(e, '_basic_estimated', False)]
            st.caption(f"ℹ️ Basic/HRA for **{', '.join(est_names)}** estimated (40%/50% of gross). Upload payslip/ITCS for exact values.")

        st.markdown("**Editable** — auto-filled from documents (sum of all employers). Correct if needed.")
        c1, c2, c3 = st.columns(3)
        total_basic = c1.number_input("Total Basic Salary (annual)", 0, 50000000, int(auto_basic), 10000, key="hra_basic")
        total_hra = c2.number_input("Total HRA Received (annual)", 0, 50000000, int(auto_hra_r), 10000, key="hra_recv")
        c3.text_input("City", value=f"{tp.city} → {city_label}", disabled=True, key="hra_city_disp")

        rent_default = int(tp.hra_details.rent_paid_monthly if tp.hra_details and tp.hra_details.rent_paid_monthly > 0 else 0)
        if rent_default > 0:
            rent_source = "Payslip" if st.session_state.get("payslip_data") else "Saved"
            st.markdown(
                f'<div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;'
                f'padding:0.4rem 0.8rem;font-size:0.78rem;color:#166534;margin-bottom:0.5rem;">'
                f'✅ Rent <b>₹{rent_default:,.0f}/month</b> (₹{rent_default*12:,.0f}/year) auto-detected from {rent_source}'
                f'</div>', unsafe_allow_html=True)
        rent = st.number_input("Monthly Rent Paid (₹)", min_value=0, value=rent_default, step=1000, key="rent_in")

        if rent > 0 and total_basic > 0 and total_hra > 0:
            from taxbuddy.engine.salary import compute_hra_exemption
            hra = compute_hra_exemption(total_basic, total_hra, rent * 12, is_metro)
            a_win = hra["exemption"] == hra["actual_hra"]
            b_win = hra["exemption"] == hra["rent_minus_10pct"]
            c_win = hra["exemption"] == hra["metro_pct_of_salary"]
            c1, c2, c3 = st.columns(3)
            c1.metric("(A) Actual HRA", fmt(hra["actual_hra"]), delta="✓ Wins" if a_win else None)
            c2.metric("(B) Rent − 10% Basic", fmt(hra["rent_minus_10pct"]), delta="✓ Wins" if b_win else None)
            pct = "50" if is_metro else "40"
            c3.metric(f"(C) {pct}% of Basic", fmt(hra["metro_pct_of_salary"]), delta="✓ Wins" if c_win else None)
            st.markdown(f"""
            <div style="background:linear-gradient(135deg,#ECFDF5,#F0FDF4);border:1px solid #BBF7D0;
                 border-radius:10px;padding:0.7rem 1rem;margin-top:0.4rem;">
                <div style="font-weight:800;color:#166534;font-size:0.95rem;">HRA Exemption = {fmt(hra['exemption'])}</div>
                <div style="color:#16A34A;font-size:0.78rem;">Taxable HRA: {fmt(hra['taxable_hra'])} &nbsp;|&nbsp; Annual Rent: {fmt(rent*12)}</div>
            </div>""", unsafe_allow_html=True)

            metro_pct = 0.50 if is_metro else 0.40
            cap_a = total_hra
            cap_c = metro_pct * total_basic
            binding_cap = min(cap_a, cap_c)
            optimal_annual_rent = binding_cap + (0.10 * total_basic)
            optimal_monthly_rent = round(optimal_annual_rent / 12)
            current_annual_rent = rent * 12

            if current_annual_rent < optimal_annual_rent:
                gap_monthly = optimal_monthly_rent - rent
                max_hra = compute_hra_exemption(total_basic, total_hra, optimal_annual_rent, is_metro)
                extra_saving = max_hra["exemption"] - hra["exemption"]
                st.markdown(f"""
                <div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;
                     padding:0.7rem 1rem;margin-top:0.5rem;">
                    <div style="font-weight:700;color:#92400E;font-size:0.85rem;">
                        💡 Maximum HRA-optimal rent: <b>₹{optimal_monthly_rent:,}/month</b></div>
                    <div style="color:#78350F;font-size:0.76rem;margin-top:4px;">
                        At ₹{optimal_monthly_rent:,}/month, your HRA exemption would be <b>{fmt(max_hra['exemption'])}</b>
                        — saving you an additional <b>{fmt(extra_saving)}</b> in taxable income.</div>
                    <div style="color:#78350F;font-size:0.76rem;margin-top:2px;">
                        You're currently <b>₹{gap_monthly:,}/month below</b> the optimal rent for max HRA.</div>
                </div>""", unsafe_allow_html=True)
            elif current_annual_rent >= optimal_annual_rent:
                st.markdown(f"""
                <div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:10px;
                     padding:0.5rem 1rem;margin-top:0.5rem;">
                    <div style="font-weight:700;color:#166534;font-size:0.8rem;">
                        ✅ Your rent already maximizes HRA exemption (optimal threshold: ₹{optimal_monthly_rent:,}/month)</div>
                </div>""", unsafe_allow_html=True)

            st.markdown(f"""
            <div style="background:#FFF1F2;border:1px solid #FECDD3;border-radius:10px;
                 padding:0.5rem 1rem;margin-top:0.5rem;">
                <div style="font-weight:700;color:#9F1239;font-size:0.8rem;">
                    ⚠️ Claim only the actual rent you pay — do not inflate rent to match the optimal figure.</div>
                <div style="color:#881337;font-size:0.72rem;margin-top:3px;">
                    If annual rent exceeds ₹1,00,000, landlord's PAN is mandatory. IT Dept can verify rent receipts
                    during scrutiny. Fraudulent HRA claims attract penalty u/s 270A (50–200% of tax evaded).</div>
            </div>""", unsafe_allow_html=True)

            tp.hra_details = HRADetails(
                total_hra_received=total_hra, total_basic_salary=total_basic,
                rent_paid_monthly=rent, rent_paid_annual=rent*12,
                city=City.METRO if is_metro else City.NON_METRO,
                hra_exemption=hra["exemption"])
            tp.exemptions.hra = hra["exemption"]
        elif rent == 0:
            st.caption("Enter your monthly rent to see the full HRA calculation with all 3 criteria.")

    # ── LTA — Leave Travel Allowance ──
    st.divider()
    section_chip("✈️ Section 10(5) — LTA (Leave Travel Allowance)")
    total_lta = sum(e.lta_received for e in tp.employers)
    with st.expander(f"**LTA Exemption** {'| From Form 16: ' + fmt(total_lta) if total_lta > 0 else ''}", expanded=False):
        st.markdown("""
**What is LTA?** Exemption for actual travel expenses on leave. Only **domestic travel** costs are exempt — not hotel, food, or shopping.

**Rules:**
- Claimable **twice in a block of 4 years** (current block: 2022-25, next: 2026-29)
- Only **shortest route economy fare** is allowed
- **Bills/tickets required** — boarding passes, rail tickets, or bus receipts
- Family: self, spouse, 2 children, dependent parents/siblings
""")
        c1, c2 = st.columns(2)
        lta_from_f16 = total_lta
        lta_claimed = c1.number_input("LTA Amount Claimed (₹)", 0, 500000, int(lta_from_f16), 5000, key="lta_amt")
        lta_cap = sum(e.lta_received for e in tp.employers) if total_lta > 0 else round(tp.total_basic_salary * 0.04)
        c2.metric("Your LTA Cap (from salary)", fmt(lta_cap if lta_cap > 0 else 0))
        if lta_cap > 0:
            _headroom_bar("LTA Exemption", lta_claimed, lta_cap,
                          "claim if you travelled on leave — keep boarding passes and travel tickets.")
        if lta_claimed > 0:
            st.warning("⚠️ **Keep your travel bills!** Boarding passes, tickets, and travel invoices are mandatory. "
                       "Only actual travel cost is exempt — not hotel/food.", icon="📋")
        tp.exemptions.lta = lta_claimed

    # ── Children Education Allowance ──
    section_chip("👨‍👧‍👦 Section 10(14) — Children Education Allowance")
    with st.expander("**Children Education + Hostel Allowance**", expanded=False):
        st.markdown("""
**Rules (Section 10(14), Rule 2BB):**
- **₹100/month per child** (₹1,200/year) for education allowance — max 2 children
- **₹300/month per child** (₹3,600/year) for hostel expenditure — max 2 children
- **Total max: ₹9,600/year** (₹4,800 education + ₹4,800 hostel for 2 children)
- No bills required — it's a flat exemption if your salary includes this component
""")
        c1, c2 = st.columns(2)
        num_children = c1.number_input("Number of children (max 2)", 0, 2, 0, key="num_kids")
        hostel = c2.checkbox("Children in hostel?", key="kids_hostel")
        kids_edu = num_children * 1200
        kids_hostel_amt = num_children * 3600 if hostel else 0
        total_kids = kids_edu + kids_hostel_amt
        if num_children > 0:
            st.success(f"✅ Children Education: **{fmt(kids_edu)}** + Hostel: **{fmt(kids_hostel_amt)}** = **{fmt(total_kids)}**/year")

    # ── Driver & Fuel / Transport Allowance ──
    section_chip("🚗 Other Sec 10 Exemptions — Transport, Fuel, Food")
    with st.expander("**Transport / Fuel / Driver / Meal Allowances**", expanded=False):
        st.markdown("""
**Common salary components that can be tax-free (Old Regime only):**

| Allowance | Limit | Proof Required? |
|-----------|-------|-----------------|
| **Transport Allowance** (disabled employees) | ₹3,200/month | Medical certificate |
| **Meal Coupons (Sodexo etc.)** | ₹50/meal (₹26,400/year for 22 days × 12 months) | Auto via salary |
| **Uniform Allowance** | Actual amount | Bills for purchase/maintenance |
| **Mobile/Internet Reimbursement** | Actual amount | Monthly bills |
| **Books & Periodicals** | Actual amount | Purchase receipts |
| **Gadget/Laptop (company provided)** | Not taxable if used for work | Company policy |

*These are usually handled by your employer in salary structuring. Check your payslip for these components.*
""")
        c1, c2 = st.columns(2)
        fuel_reimb = c1.number_input("Fuel/Driver Reimbursement (annual ₹)", 0, 500000, 0, 5000, key="fuel")
        meal_exempt = c2.number_input("Meal Coupon Exemption (annual ₹)", 0, 30000, 0, 1000, key="meal_ex")
        if fuel_reimb > 0:
            st.warning("⚠️ Keep fuel bills and driver salary receipts. Employer must include this in your salary structure.", icon="⛽")

    st.divider()
    section_chip("📋 Chapter VI-A — Deductions (Old Regime)")

    # ── 80C ──
    f16_80c = max([e.sec10_exemptions.get("deduction_80C", 0) for e in tp.employers] or [0])
    auto_80c = f16_80c
    headroom = max(150000 - auto_80c, 0)
    with st.expander(f"**80C** — From Form 16: {fmt(auto_80c)} | Headroom: {fmt(headroom)}", expanded=True):
        if auto_80c > 0:
            st.markdown(
                f'<div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;'
                f'padding:0.4rem 0.8rem;font-size:0.78rem;color:#166534;margin-bottom:0.5rem;">'
                f'✅ <b>₹{auto_80c:,.0f}</b> auto-detected from Form 16 (EPF + PPF + ELSS + LIC etc.)'
                f'</div>', unsafe_allow_html=True)
        c1, c2, c3 = st.columns(3)
        ppf = c1.number_input("PPF (additional)", 0, 150000, 0, 5000, key="ppf")
        elss = c2.number_input("ELSS / Tax Saver MF", 0, 150000, 0, 5000, key="elss")
        lic = c3.number_input("LIC Premium", 0, 150000, 0, 5000, key="lic")
        c1, c2, c3 = st.columns(3)
        tuition = c1.number_input("Tuition Fees (max 2 kids)", 0, 150000, 0, 5000, key="tui")
        home_p = c2.number_input("Home Loan Principal", 0, 150000, 0, 5000, key="hlp")
        nsc = c3.number_input("NSC / Tax Saver FD", 0, 150000, 0, 5000, key="nsc")
        additional = ppf + elss + lic + tuition + home_p + nsc
        total_80c = min(auto_80c + additional, 150000)
        pct_80c = min(total_80c / 150000 * 100, 100)
        st.progress(pct_80c / 100, text=f"80C: {fmt(total_80c)} / ₹1,50,000 ({pct_80c:.0f}%)")
        if total_80c >= 150000:
            st.success("✅ 80C fully utilized — ₹1,50,000 limit reached!", icon="🎉")
        elif total_80c > 0:
            gap = 150000 - total_80c
            st.info(f"💡 You've claimed **₹{total_80c:,.0f}** under 80C. **₹{gap:,.0f} more** can be claimed — consider PPF, ELSS, or tax-saver FD.", icon="💰")
        tp.deductions.sec_80c = total_80c

    # ── 80CCD — NPS with 10% of basic cap ──
    nps_employer = sum(e.nps_employer for e in tp.employers)
    f16_1b = max([e.sec10_exemptions.get("deduction_80CCD_1B", 0) for e in tp.employers] or [0])
    cap_10pct = round(total_basic * 0.10)
    with st.expander(f"**80CCD — NPS** | 80CCD(1B): {fmt(f16_1b)} | Employer: {fmt(nps_employer)}", expanded=False):
        if f16_1b > 0 or nps_employer > 0:
            st.markdown(
                f'<div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;'
                f'padding:0.4rem 0.8rem;font-size:0.78rem;color:#166534;margin-bottom:0.5rem;">'
                f'✅ Auto-detected — 80CCD(1B): <b>₹{f16_1b:,.0f}</b> | Employer NPS: <b>₹{nps_employer:,.0f}</b>'
                f'</div>', unsafe_allow_html=True)

        st.markdown(f"""
**80CCD(1) — Employee NPS:** Max **10% of Basic** = **{fmt(cap_10pct)}** (included in 80C ₹1.5L limit)
**80CCD(1B) — Additional NPS:** Extra **₹50,000** (over and above 80C limit)
**80CCD(2) — Employer NPS:** **14% of Basic** for Govt / **10% for Pvt** (both regimes)
""")
        c1, c2 = st.columns(2)
        nps_self = c1.number_input("80CCD(1B) — Your NPS contribution (₹)", 0, 50000, int(f16_1b or tp.deductions.sec_80ccd_1b), 5000, key="n1b")
        nps_emp_edit = c2.number_input("80CCD(2) — Employer NPS (₹)", 0, 5000000, int(nps_employer), 5000, key="n2_edit")
        tp.deductions.sec_80ccd_1b = nps_self
        tp.deductions.sec_80ccd_2 = nps_emp_edit

        _headroom_bar("80CCD(1B) — Your NPS", nps_self, 50000,
                      "invest in NPS Tier-1 to claim. Only enter if you've actually contributed.")
        if cap_10pct > 0:
            _headroom_bar("80CCD(2) — Employer NPS (10% of Basic)", nps_emp_edit, cap_10pct,
                          "check with your employer if they contribute to NPS on your behalf.")
        if nps_emp_edit > cap_10pct > 0:
            st.warning(f"⚠️ Employer NPS exceeds 10% of basic ({fmt(cap_10pct)}). Excess ₹{nps_emp_edit - cap_10pct:,.0f} will be taxable.", icon="⚠️")
        st.caption("⚠️ Only enter amounts you've **actually contributed**. Incorrect claims can lead to scrutiny.")

    # ── 80D — Health Insurance + Medical Treatment ──
    f16_80d = max([e.sec10_exemptions.get("deduction_80D", 0) for e in tp.employers] or [0])
    with st.expander(f"**80D — Health Insurance & Medical** {('| Form 16: ' + fmt(f16_80d)) if f16_80d > 0 else ''}", expanded=False):
        if f16_80d > 0:
            st.markdown(
                f'<div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:8px;'
                f'padding:0.4rem 0.8rem;font-size:0.78rem;color:#166534;margin-bottom:0.5rem;">'
                f'✅ <b>₹{f16_80d:,.0f}</b> declared in Form 16 under 80D</div>', unsafe_allow_html=True)

        st.markdown("""
**Two ways to claim 80D:**
1. **Health Insurance Premium** — needs policy number & premium receipt
2. **Medical Expenditure** (for uninsured senior citizens) — needs medical bills, **no policy number** required

| Category | Below 60 | Senior (60+) |
|----------|----------|--------------|
| Self/Family Insurance | ₹25,000 | ₹50,000 |
| Parents Insurance | ₹25,000 | ₹50,000 |
| Preventive Health Checkup | ₹5,000 (within above) | ₹5,000 (within above) |
| Medical Expenditure (uninsured 60+) | N/A | ₹50,000 |
""")
        default_self = int(tp.deductions.sec_80d_self) if tp.deductions.sec_80d_self > 0 else min(int(f16_80d), 25000) if f16_80d > 0 else 0
        default_parents = int(tp.deductions.sec_80d_parents) if tp.deductions.sec_80d_parents > 0 else max(int(f16_80d) - 25000, 0) if f16_80d > 25000 else 0

        st.markdown("**Self / Family:**")
        c1, c2 = st.columns(2)
        s_sr = c1.checkbox("Self 60+?", key="ssr")
        self_via = c2.radio("Claim via:", ["Insurance Premium", "Medical Expenditure (no policy needed)"], key="self_80d_via", horizontal=True)
        ps = st.number_input("Self/Family Amount (₹)", 0, 50000, default_self, 5000, key="d_s")

        st.markdown("**Parents:**")
        c1, c2 = st.columns(2)
        p_sr = c1.checkbox("Parents 60+?", key="psr")
        parent_via = c2.radio("Claim via:", ["Insurance Premium", "Medical Expenditure (no policy needed)"], key="par_80d_via", horizontal=True)
        pp = st.number_input("Parents Amount (₹)", 0, 50000, default_parents, 5000, key="d_p")

        checkup = st.number_input("Preventive Health Checkup (₹, max ₹5,000)", 0, 5000, 0, 1000, key="d_chk")

        sl = 50000 if s_sr else 25000
        pl = 50000 if p_sr else 25000
        tp.deductions.sec_80d_self = min(ps + checkup, sl)
        tp.deductions.sec_80d_parents = min(pp, pl)
        total_80d = tp.deductions.sec_80d_self + tp.deductions.sec_80d_parents

        _headroom_bar("80D — Self/Family", tp.deductions.sec_80d_self, sl,
                      "submit insurance premium bills or preventive checkup receipt (₹5,000 within limit).")
        _headroom_bar("80D — Parents", tp.deductions.sec_80d_parents, pl,
                      f"{'₹50K limit for senior citizen parents — medical bills or insurance' if p_sr else 'add parents health insurance; ₹50K limit if they are 60+'}.")

        if "Medical" in self_via:
            st.info("ℹ️ Medical expenditure claim doesn't need policy number — keep hospital/pharmacy bills.", icon="🏥")
        if "Medical" in parent_via and p_sr:
            st.info("ℹ️ For uninsured senior citizen parents, up to ₹50,000 medical bills are deductible.", icon="🏥")
        elif "Medical" in parent_via and not p_sr:
            st.warning("⚠️ Medical expenditure (without insurance) is only available for **senior citizens (60+)**.", icon="⚠️")

    # ── 80TTA ──
    savings_int = tp.other_income.interest_savings
    tta = min(savings_int, 10000)
    with st.expander(f"**80TTA** — Savings Interest `AUTO`: {fmt(tta)}", expanded=False):
        st.markdown(f"AIS Savings Interest: **{fmt(savings_int)}** → Deduction: **{fmt(tta)}** (max ₹10,000)")
        _headroom_bar("80TTA — Savings Interest", tta, 10000, "auto-capped at ₹10,000 from savings bank interest.")
        tp.deductions.sec_80tta = tta

    # ── 80E — Education Loan ──
    with st.expander("**80E — Education Loan Interest**", expanded=False):
        st.markdown("""
**What:** Interest paid on loan for **higher education** (self, spouse, children, or student you're legal guardian of).
**Limit:** **No upper limit** — full interest amount is deductible.
**Duration:** Available for **8 years** from the year you start repaying, or until interest is fully repaid.
**Eligible loans:** From any **financial institution or approved charitable institution** only (not from relatives/friends).
**Proof:** Interest certificate from the bank/NBFC.
""")
        tp.deductions.sec_80e = st.number_input("Education Loan Interest Paid (annual ₹)", 0, 5000000, int(tp.deductions.sec_80e), 5000, key="e80")
        if tp.deductions.sec_80e > 0:
            st.success(f"✅ **{fmt(tp.deductions.sec_80e)}** deductible under 80E. No upper limit!", icon="🎓")

    # ── 80G — Donations ──
    with st.expander("**80G — Donations to Charity**", expanded=False):
        st.markdown("""
**What:** Donations to eligible funds/institutions.
**Categories:**
- **100% deduction (no limit):** PM CARES, National Defence Fund, PM National Relief Fund
- **100% deduction (with 10% of income limit):** Approved local NGOs
- **50% deduction (with 10% limit):** Government hospitals, educational institutions
**Proof:** Donation receipt with PAN of the organization, 80G certificate number.
**Tip:** Cash donations > ₹2,000 are NOT eligible — always use bank transfer/UPI.
""")
        tp.deductions.sec_80g = st.number_input("Eligible Donation Amount (₹)", 0, 2000000, int(tp.deductions.sec_80g), 5000, key="g80")
        if tp.deductions.sec_80g > 0:
            st.caption("Deduction amount depends on the category of the donee. Ensure you have the 80G receipt.")

    # ── 80DD — Disabled Dependent ──
    with st.expander("**80DD — Maintenance of Disabled Dependent**", expanded=False):
        st.markdown("""
**What:** Flat deduction for maintenance/medical treatment of a **dependent with disability**.
**Who qualifies:** Spouse, children, parents, siblings who have ≥40% disability (certified).
**Limits:**
- **₹75,000** for disability ≥40% and <80%
- **₹1,25,000** for severe disability ≥80%
**Proof:** Certificate from a government medical authority (Form 10-IA).
**Note:** This is a **flat deduction** — you get the full amount regardless of actual expenditure.
""")
        c1, c2 = st.columns(2)
        has_dep = c1.checkbox("I have a dependent with disability", key="dd_has")
        if has_dep:
            severe = c2.checkbox("Severe disability (≥80%)?", key="dd_severe")
            dd_amt = 125000 if severe else 75000
            tp.deductions.sec_80dd = dd_amt
            st.success(f"✅ Flat deduction of **{fmt(dd_amt)}** under 80DD. Get Form 10-IA from govt medical authority.", icon="♿")
        else:
            tp.deductions.sec_80dd = 0

    # ── 80DDB — Medical Treatment of Specified Diseases ──
    with st.expander("**80DDB — Treatment of Specified Diseases**", expanded=False):
        st.markdown("""
**What:** Expenses on treatment of **specified diseases** for self or dependents.
**Covered diseases:** Cancer, AIDS, chronic renal failure, hemophilia, thalassemia, neurological diseases (dementia, dystonia, Parkinson's, chorea), and any malignant type disease.
**Limits:**
- **₹40,000** for persons below 60
- **₹1,00,000** for senior citizens (60+)
**Proof:** Prescription from a specialist doctor (Form 10-I from a specialist in a govt hospital).
**Note:** Reduce the claim by any insurance reimbursement received.
""")
        c1, c2 = st.columns(2)
        ddb_amt = c1.number_input("Treatment Expense (₹)", 0, 200000, int(tp.deductions.sec_80ddb), 5000, key="ddb")
        ddb_sr = c2.checkbox("Patient is 60+?", key="ddb_sr")
        ddb_limit = 100000 if ddb_sr else 40000
        tp.deductions.sec_80ddb = min(ddb_amt, ddb_limit)
        if ddb_amt > 0:
            _headroom_bar("80DDB — Specified Disease Treatment", tp.deductions.sec_80ddb, ddb_limit,
                          f"get Form 10-I from specialist in govt hospital ({'senior citizen limit' if ddb_sr else 'below 60 limit'}).")

    # ── 80U — Self Disability ──
    with st.expander("**80U — Self Disability**", expanded=False):
        st.markdown("""
**What:** Flat deduction if **you yourself** have a disability (≥40%).
**Limits:** ₹75,000 (40-79%) or ₹1,25,000 (≥80% severe).
**Proof:** Certificate from government medical authority.
""")
        c1, c2 = st.columns(2)
        has_self_dis = c1.checkbox("I have a disability (≥40%)", key="u80_has")
        if has_self_dis:
            severe_self = c2.checkbox("Severe (≥80%)?", key="u80_sev")
            u_amt = 125000 if severe_self else 75000
            tp.deductions.sec_80u = u_amt
            st.success(f"✅ Flat deduction of **{fmt(u_amt)}** under 80U.", icon="♿")
        else:
            tp.deductions.sec_80u = 0

    # ── 80GG — Rent (if no HRA) ──
    with st.expander("**80GG — Rent Paid (if no HRA in salary)**", expanded=False):
        st.markdown("""
**What:** If your salary does NOT include HRA, you can still claim rent deduction under 80GG.
**Conditions:** You, spouse, or minor child should not own a house in the city of employment.
**Limit:** Least of (a) ₹5,000/month, (b) 25% of total income, (c) Rent paid − 10% of total income.
**Note:** Cannot be claimed if you already claim HRA exemption u/s 10(13A).
""")
        if tp.exemptions.hra > 0:
            st.warning("You're already claiming HRA u/s 10(13A). 80GG is NOT applicable.", icon="⚠️")
        else:
            gg = st.number_input("Annual Rent Paid (₹)", 0, 1000000, int(tp.deductions.sec_80gg), 5000, key="gg80")
            tp.deductions.sec_80gg = gg

    # ── Home Loan Interest — Sec 24(b) ──
    section_chip("🏠 Section 24(b) — Home Loan Interest")
    with st.expander("**Home Loan Interest Deduction**", expanded=False):
        st.markdown("""
**Limit:** Up to **₹2,00,000/year** for self-occupied property.
**Condition:** Possession must be taken within 5 years of loan disbursement.
**Proof:** Interest certificate from the bank.
""")
        hl_int = st.number_input("Home Loan Interest Paid (annual ₹)", 0, 500000, 0, 10000, key="hl_int_24b")
        if hl_int > 0:
            _headroom_bar("Sec 24(b) — Home Loan Interest", min(hl_int, 200000), 200000,
                          "deduction capped at ₹2,00,000 for self-occupied property.")
        tp.other_income.interest_housing_loan = hl_int

        # ── HRA vs Home Loan trade-off warning ──
        hra_claimed = tp.exemptions.hra
        if hl_int > 0 and hra_claimed > 0:
            st.divider()
            st.markdown("""
<div style="background:linear-gradient(135deg,#FFFBEB,#FEF3C7);border:1px solid #FDE68A;border-radius:10px;padding:0.8rem 1rem;">
<div style="font-weight:800;color:#92400E;font-size:0.9rem;margin-bottom:0.4rem;">⚖️ HRA vs Home Loan Interest — Can You Claim Both?</div>
<div style="font-size:0.78rem;color:#78350F;line-height:1.6;">

<b>YES, you CAN claim both</b> HRA u/s 10(13A) and Home Loan Interest u/s 24(b) <b>simultaneously</b> — but only if:

<ul style="margin:0.3rem 0;">
<li><b>You live in a rented house</b> (different city or same city but different location) AND own a house elsewhere on loan</li>
<li><b>Or</b> you live in rented accommodation because your own house is under construction / in another city</li>
</ul>

<b>You CANNOT claim both if:</b>
<ul style="margin:0.3rem 0;">
<li>You live in the same house for which you're paying the home loan — then <b>only Sec 24(b)</b> applies, not HRA</li>
</ul>

<b>Legal Ref:</b> Sec 10(13A) read with Rule 2A + Sec 24(b) of IT Act, 1961. <i>CIT vs Sudhanshu Sharma (ITAT Delhi)</i> upheld that both can be claimed if genuinely living on rent.
</div></div>
""", unsafe_allow_html=True)

            hra_benefit = hra_claimed
            hl_benefit = min(hl_int, 200000)
            st.markdown("")
            c1, c2 = st.columns(2)
            c1.metric("HRA Exemption (Sec 10(13A))", fmt(hra_benefit))
            c2.metric("Home Loan Interest (Sec 24(b))", fmt(hl_benefit))
            combined = hra_benefit + hl_benefit
            st.success(f"✅ If eligible for both: **Combined tax benefit = {fmt(combined)}**. Ensure you have rent receipts AND bank interest certificate.", icon="💰")

            st.markdown("""
<div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:8px;padding:0.6rem 0.8rem;font-size:0.75rem;color:#1E40AF;margin-top:0.3rem;">
<b>💡 Trade-off if you live in your own house:</b> You lose HRA ({hra_fmt}) but keep Home Loan Interest ({hl_fmt}).
If HRA > Home Loan Interest, it may be more beneficial to continue renting and let out your property (claim full interest without ₹2L cap under "let out" property).
</div>
""".replace("{hra_fmt}", fmt(hra_benefit)).replace("{hl_fmt}", fmt(hl_benefit)), unsafe_allow_html=True)

        elif hl_int > 0 and hra_claimed == 0:
            st.info("ℹ️ You're not claiming HRA. If you also pay rent, check **80GG** above — you may be able to claim rent deduction separately.", icon="💡")

    st.divider()
    section_chip("📝 ITR Form Selection")

    ais = st.session_state.ais_data
    ais_mf = ais.get("mf_sale_total", 0) if ais else 0
    ais_prop = ais.get("property_transactions", []) if ais else []
    ais_mf_details = ais.get("mf_sale_details", []) if ais else []
    auto_cg = tp.has_capital_gains or ais_mf > 0 or len(ais_prop) > 0

    c1, c2, c3 = st.columns(3)
    tp.has_capital_gains = c1.checkbox("Sold shares/MF/property?", value=auto_cg, key="cg")
    tp.has_foreign_assets = c2.checkbox("Foreign assets (RSU/ESOP)?", value=tp.has_foreign_assets, key="fa")
    tp.is_director = c3.checkbox("Director in a company?", value=tp.is_director, key="di")

    detected_items = []
    if ais_mf > 0:
        detected_items.append(("mf", "Mutual Fund Redemptions", ais_mf, ais_mf_details))
    if ais_prop:
        total_prop = sum(p.get("amount", 0) for p in ais_prop)
        detected_items.append(("prop", "Property Transactions", total_prop, ais_prop))

    if detected_items:
        st.markdown("""<div style="background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;
             padding:0.5rem 0.8rem;margin:0.5rem 0 0.3rem;font-size:0.78rem;color:#92400E;font-weight:600;">
             🔍 Auto-detected from AIS — these are pre-checked above. Verify and fill capital gains details below.
        </div>""", unsafe_allow_html=True)

        cols = st.columns(len(detected_items), gap="medium")
        for idx, (dtype, label, total, details) in enumerate(detected_items):
            with cols[idx]:
                border_color = "#F59E0B" if dtype == "mf" else "#8B5CF6"
                icon = "📈" if dtype == "mf" else "🏠"
                st.markdown(f"""
                <div style="background:#FFFFFF;border:1px solid #E2E8F0;border-radius:12px;
                     padding:0.7rem 0.9rem;border-left:3px solid {border_color};
                     box-shadow:0 1px 3px rgba(0,0,0,0.04);">
                    <div style="display:flex;align-items:center;gap:8px;margin-bottom:0.4rem;">
                        <span style="font-size:1.1rem;">{icon}</span>
                        <div>
                            <div style="font-size:0.8rem;font-weight:700;color:#0F172A;">{label}</div>
                            <div style="font-size:0.72rem;color:#64748B;">Total: <b style="color:#0F172A;">₹{total:,.0f}</b></div>
                        </div>
                    </div>
                </div>""", unsafe_allow_html=True)

                if dtype == "mf" and details:
                    with st.expander(f"MF transactions ({len(details)} source(s))", expanded=False):
                        for md in details:
                            st.markdown(f"**{md.get('source', 'Unknown')}** — ₹{md.get('amount', 0):,.0f}")
                            for txn in md.get("transactions", []):
                                fund = txn.get("fund", "")
                                amt = txn.get("amount", 0)
                                dt = txn.get("date", "")
                                ttype = txn.get("type", "")
                                tag = f" `{ttype}`" if ttype else ""
                                st.markdown(f"&nbsp;&nbsp;• {fund} — ₹{amt:,.0f} ({dt}){tag}")
                elif dtype == "prop" and details:
                    with st.expander(f"Property details ({len(details)} transaction(s))", expanded=False):
                        for pt in details:
                            amt = pt.get("amount", 0)
                            dt = pt.get("date", "")
                            addr = pt.get("address", "N/A")
                            st.markdown(f"• ₹{amt:,.0f} on {dt} — {addr}")

        if tp.has_capital_gains:
            st.markdown("""
            <div style="background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;
                 padding:0.6rem 0.9rem;margin-top:0.5rem;">
                <div style="font-weight:700;color:#1E40AF;font-size:0.82rem;">📋 Recommendation: ITR-2 required</div>
                <div style="font-size:0.73rem;color:#1E3A8A;margin-top:3px;">
                    Capital gains from MF/shares/property require <b>ITR-2</b>. You'll need:
                </div>
                <div style="font-size:0.73rem;color:#1E3A8A;margin-top:3px;padding-left:0.8rem;">
                    • <b>Schedule CG</b> — report each capital gain transaction<br>
                    • <b>Schedule 112A</b> — for listed equity/MF LTCG (>₹1.25 lakh exempt)<br>
                    • <b>Schedule 111A</b> — for listed equity/MF STCG @15%<br>
                    • <b>Table F</b> — for property sale capital gains
                </div>
                <div style="font-size:0.72rem;color:#64748B;margin-top:5px;">
                    💡 Use your broker/AMC capital gains statement for exact purchase date and cost basis.
                    AIS amounts are <b>sale consideration</b>, not profit — you still need to calculate gain after cost.
                </div>
            </div>""", unsafe_allow_html=True)

    st.divider()
    hra_val = tp.exemptions.hra if tp.hra_details else 0
    via_val = tp.deductions.total_via
    total_ben = hra_val + via_val + 50000

    st.markdown(f"""
    <div style="background:#FFFFFF; border:1px solid #E2E8F0; border-radius:16px;
         padding:1.2rem; box-shadow:0 2px 8px rgba(0,0,0,0.04);">
        <div style="font-weight:800; color:#0F172A; font-size:1rem; margin-bottom:0.7rem;">
            💰 Estimated Tax Benefit (Old Regime)
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:0.5rem;">
            <div style="background:#F8FAFC; padding:0.6rem; border-radius:10px; text-align:center;">
                <div style="font-size:0.6rem; color:#64748B; text-transform:uppercase; font-weight:700;">HRA Exempt</div>
                <div style="font-size:1.1rem; font-weight:800; color:#1E293B;">{fmt(hra_val)}</div>
            </div>
            <div style="background:#F8FAFC; padding:0.6rem; border-radius:10px; text-align:center;">
                <div style="font-size:0.6rem; color:#64748B; text-transform:uppercase; font-weight:700;">Std Deduction</div>
                <div style="font-size:1.1rem; font-weight:800; color:#1E293B;">₹50,000</div>
            </div>
            <div style="background:#F8FAFC; padding:0.6rem; border-radius:10px; text-align:center;">
                <div style="font-size:0.6rem; color:#64748B; text-transform:uppercase; font-weight:700;">VI-A Deductions</div>
                <div style="font-size:1.1rem; font-weight:800; color:#1E293B;">{fmt(via_val)}</div>
            </div>
            <div style="background:linear-gradient(135deg,#EFF6FF,#E0E7FF); padding:0.6rem; border-radius:10px; text-align:center;">
                <div style="font-size:0.6rem; color:#4338CA; text-transform:uppercase; font-weight:700;">Total Benefit</div>
                <div style="font-size:1.1rem; font-weight:800; color:#2563EB;">{fmt(total_ben)}</div>
            </div>
        </div>
    </div>""", unsafe_allow_html=True)

    nav_buttons("Next: Tax Computation →")


# ═══════════════════════════════════════════════════════════════════
#  STEP 5: Tax Computation
# ═══════════════════════════════════════════════════════════════════

def page_tax_computation():
    page_head("Tax Computation", "Old vs New Regime — side-by-side comparison with recommendation.")
    tp = st.session_state.taxpayer
    if not tp.employers:
        st.info("No salary data. Upload Form 16 or fill the **Smart Tax Optimizer**.")
        nav_buttons(); return

    try:
        from taxbuddy.engine.tax_calculator import compare_regimes
        comp = compare_regimes(tp)
    except Exception as e:
        st.error(f"Error: {e}"); nav_buttons(); return

    rec = comp["recommended"]
    savings = comp["savings"]
    rec_label = "Old Regime" if rec == "old" else "New Regime"

    if savings > 0:
        st.markdown(f"""
        <div class="result-banner info">
            <div style="font-weight:800; color:#1E40AF; font-size:1rem;">
                💡 Recommended: {rec_label}
            </div>
            <div style="color:#3B82F6; font-size:0.88rem;">
                You save <b>{fmt(savings)}</b> compared to the other regime.
            </div>
        </div>""", unsafe_allow_html=True)

    for r in comp["reasons"]: st.markdown(f"- {r}")

    st.divider()
    tab_old, tab_new, tab_cmp = st.tabs(["Old Regime", "New Regime", "Side-by-Side"])
    with tab_old: _render_regime(comp["old_regime"])
    with tab_new: _render_regime(comp["new_regime"])
    with tab_cmp: _render_cmp(comp)

    nav_buttons("Next: ITR Recommendation →")


def _line(label, val, bold=False, neg=False):
    c1, c2 = st.columns([3, 1])
    c1.markdown(f"**{label}**" if bold else label)
    if neg:
        c2.markdown(f"<span style='color:#DC2626'>(₹{abs(val):,.0f})</span>", unsafe_allow_html=True)
    elif bold:
        c2.markdown(f"**₹{val:,.0f}**")
    else:
        c2.markdown(f"₹{val:,.0f}")


def _render_regime(data):
    sal = data["salary"]
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Gross Salary", fmt(sal['gross_salary']))
    m2.metric("Taxable Income", fmt(data['taxable_income']))
    m3.metric("Total Tax", fmt(data['tax_computation']['total_tax']))
    if data["is_refund"]:
        m4.metric("Refund", fmt(data['tax_payable']), delta="Refund")
    else:
        m4.metric("Tax Payable", fmt(data['tax_payable']), delta="Due", delta_color="inverse")
    st.divider()
    with st.expander("Salary Breakdown", expanded=True):
        _line("Gross Salary", sal["gross_salary"])
        _line("Less: Sec 10 Exemptions", sal["sec10_exemptions"]["total"], neg=True)
        _line("Less: Std Deduction", sal["sec16_deductions"]["standard_deduction"], neg=True)
        _line("Less: Professional Tax", sal["sec16_deductions"]["professional_tax"], neg=True)
        _line("Income under Salary", sal["salary_income"], bold=True)
    if data["deductions"]:
        with st.expander("Chapter VI-A Deductions", expanded=True):
            for n, v in data["deductions"].items(): _line(n, v)
            st.divider()
            _line("Total Deductions", data["total_deductions"], bold=True)
    with st.expander("Tax Calculation", expanded=True):
        tax = data["tax_computation"]
        _line("Tax on income", tax["tax_on_normal"])
        if tax.get("tax_on_stcg_111a", 0) > 0: _line("STCG @ 20%", tax["tax_on_stcg_111a"])
        if tax.get("tax_on_ltcg_112a", 0) > 0: _line("LTCG @ 12.5%", tax["tax_on_ltcg_112a"])
        if tax.get("surcharge", 0) > 0: _line("Surcharge", tax["surcharge"])
        _line("Cess @ 4%", tax["cess"])
        _line("Total Tax", tax["total_tax"], bold=True)
        st.divider()
        _line("TDS Paid", data["total_tds"])
        color = "#16A34A" if data["is_refund"] else "#DC2626"
        label = "REFUND" if data["is_refund"] else "Tax Payable"
        c1, c2 = st.columns([3, 1])
        c1.markdown(f"**{label}**")
        c2.markdown(f"<span style='color:{color};font-weight:800;font-size:1.15rem'>{fmt(data['tax_payable'])}</span>", unsafe_allow_html=True)


def _render_cmp(comp):
    old, new = comp["old_regime"], comp["new_regime"]
    rows = [
        ("Gross Salary", old["salary"]["gross_salary"], new["salary"]["gross_salary"]),
        ("Sec 10 Exemptions", old["salary"]["sec10_exemptions"]["total"], new["salary"]["sec10_exemptions"]["total"]),
        ("Standard Deduction", old["salary"]["sec16_deductions"]["standard_deduction"], new["salary"]["sec16_deductions"]["standard_deduction"]),
        ("Salary Income", old["salary"]["salary_income"], new["salary"]["salary_income"]),
        ("Gross Total Income", old["gross_total_income"], new["gross_total_income"]),
        ("VI-A Deductions", old["total_deductions"], new["total_deductions"]),
        ("Taxable Income", old["taxable_income"], new["taxable_income"]),
        ("Total Tax", old["tax_computation"]["total_tax"], new["tax_computation"]["total_tax"]),
        ("TDS Paid", old["total_tds"], new["total_tds"]),
    ]
    op = old["tax_payable"]*(-1 if old["is_refund"] else 1)
    np_ = new["tax_payable"]*(-1 if new["is_refund"] else 1)
    rows.append(("Payable / (Refund)", op, np_))
    st.table([{"Particulars": l, "Old (₹)": f"{o:,.0f}", "New (₹)": f"{n:,.0f}",
               "Diff (₹)": f"{n-o:+,.0f}" if n != o else "—"} for l, o, n in rows])


# ═══════════════════════════════════════════════════════════════════
#  STEP 6: ITR Recommendation
# ═══════════════════════════════════════════════════════════════════

def page_itr():
    page_head("ITR Recommendation & Filing Plan",
              "Your ITR form, recommended regime, and complete deduction summary before you file.")
    tp = st.session_state.taxpayer

    from taxbuddy.engine.itr_selector import select_itr_form
    result = select_itr_form(tp)
    is_itr1 = result["can_use_itr1"]

    # ── ITR Form ──
    bg = "#F0FDF4" if is_itr1 else "#EFF6FF"
    border = "#BBF7D0" if is_itr1 else "#BFDBFE"
    color = "#166534" if is_itr1 else "#1E40AF"
    st.markdown(f"""
    <div style="text-align:center;background:{bg};border:1px solid {border};
         border-radius:14px;padding:1.2rem;margin-bottom:0.8rem;">
        <div style="font-size:1.2rem;font-weight:800;color:{color};">{result['form_name']}</div>
    </div>""", unsafe_allow_html=True)
    for r in result["reasons"]: st.markdown(f"- {r}")
    if result["warnings"]:
        for w in result["warnings"]: st.warning(w)

    # ── Regime Recommendation ──
    st.divider()
    try:
        from taxbuddy.engine.tax_calculator import compare_regimes
        comp = compare_regimes(tp)
        rec = comp["recommended"]
        rec_label = "Old Regime" if rec == "old" else "New Regime"
        savings = comp["savings"]
        rec_data = comp[f"{rec}_regime"]
        other_data = comp["new_regime" if rec == "old" else "old_regime"]

        rec_bg = "#F0FDF4" if savings > 0 else "#F8FAFC"
        st.markdown(f"""
        <div style="background:{rec_bg};border:1px solid #BBF7D0;border-radius:14px;
             padding:1rem 1.2rem;margin-bottom:0.8rem;">
            <div style="font-weight:800;color:#166534;font-size:1rem;">
                💡 Recommended: {rec_label}
                {'— saves ' + fmt(savings) + ' over ' + ('New' if rec == 'old' else 'Old') + ' Regime' if savings > 0 else ''}
            </div>
        </div>""", unsafe_allow_html=True)
        for r in comp["reasons"]: st.markdown(f"- {r}")
    except Exception:
        comp = None; rec_data = None

    # ── Comprehensive Deduction & Exemption Plan ──
    st.divider()
    section_chip("📋 Your Complete Deduction & Exemption Plan")
    st.caption("This is what TaxBuddy recommends based on your documents. Review before filing.")

    ded = tp.deductions
    sal = rec_data.get("salary", {}) if rec_data else {}
    sec10 = sal.get("sec10_exemptions", {}) if sal else {}

    def _plan_row(section, label, claimed, limit, note=""):
        used = min(claimed, limit) if limit else claimed
        headroom = max(limit - claimed, 0) if limit else 0
        pct = min(used / limit * 100, 100) if limit else 100
        bar_color = "#16A34A" if pct >= 100 else "#F59E0B" if pct >= 50 else "#EF4444"
        extra = ""
        if headroom > 0 and limit > 0:
            extra = f'<span style="font-size:0.68rem;color:#D97706;">💡 ₹{headroom:,.0f} more{" — " + note if note else ""}</span>'
        elif note:
            extra = f'<span style="font-size:0.68rem;color:#64748B;">{note}</span>'
        html = (
            f'<div style="display:flex;align-items:center;gap:8px;padding:0.4rem 0.6rem;border-radius:8px;background:#FAFBFC;margin-bottom:4px;border:1px solid #F1F5F9;">'
            f'<div style="min-width:120px;font-size:0.72rem;font-weight:700;color:#1E40AF;">{section}</div>'
            f'<div style="flex:1;"><span style="font-size:0.78rem;font-weight:600;color:#0F172A;">{label}</span>'
            f'<div style="height:3px;background:#E2E8F0;border-radius:2px;margin-top:3px;"><div style="height:100%;width:{pct:.0f}%;background:{bar_color};border-radius:2px;"></div></div>'
            f'{extra}</div>'
            f'<div style="min-width:90px;text-align:right;font-family:monospace;font-size:0.82rem;font-weight:700;color:#0F172A;">₹{used:,.0f}</div>'
            f'</div>'
        )
        st.markdown(html, unsafe_allow_html=True)

    # Sec 10 Exemptions
    hra = sec10.get("hra_10_13a", 0)
    if hra > 0:
        _plan_row("Sec 10(13A)", "HRA Exemption", hra, 0, "Based on rent, basic salary, and city")
    lta = sec10.get("lta_10_5", 0)
    if lta > 0:
        _plan_row("Sec 10(5)", "LTA Exemption", lta, 0)

    # Standard Deduction
    std_ded = sal.get("sec16_deductions", {}).get("standard_deduction", 0)
    if std_ded > 0:
        _plan_row("Sec 16(ia)", "Standard Deduction", std_ded, std_ded, "Auto-applied")

    # Chapter VI-A
    _plan_row("Sec 80C", f"EPF + PPF + ELSS + LIC", ded.sec_80c_total, 150000,
              "Add more PPF/ELSS if under limit")
    if ded.sec_80ccd_1b > 0 or True:
        _plan_row("Sec 80CCD(1B)", "Additional NPS", ded.sec_80ccd_1b, 50000,
                  "NPS Tier-1 contribution")
    if ded.sec_80ccd_2 > 0:
        _plan_row("Sec 80CCD(2)", "Employer NPS", ded.sec_80ccd_2, 0, "Available in both regimes")

    d_self = ded.sec_80d_self
    d_parent = ded.sec_80d_parents
    self_limit = 25000
    parent_limit = 25000
    _plan_row("Sec 80D (Self)", "Health Insurance — Self/Family", d_self, self_limit,
              "Include preventive health checkup up to ₹5,000")
    _plan_row("Sec 80D (Parents)", "Health Insurance — Parents", d_parent, parent_limit,
              "₹50K limit if parents are senior citizens (60+)")

    if ded.sec_80tta > 0:
        _plan_row("Sec 80TTA", "Savings Interest Deduction", ded.sec_80tta, 10000)
    if ded.sec_80e > 0:
        _plan_row("Sec 80E", "Education Loan Interest", ded.sec_80e, 0, "No upper limit")
    if ded.sec_80g > 0:
        _plan_row("Sec 80G", "Donations", ded.sec_80g, 0)

    # ── Total Tax Benefit Summary ──
    total_sec10 = sum([hra, lta, sec10.get("gratuity_10_10", 0), sec10.get("leave_encash_10_10aa", 0)])
    total_via = ded.total_via
    total_benefit = total_sec10 + std_ded + total_via

    st.markdown(f"""
    <div style="background:linear-gradient(135deg,#EFF6FF,#F0F9FF);border:1px solid #BFDBFE;
         border-radius:12px;padding:0.8rem 1rem;margin-top:0.8rem;">
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0.5rem;text-align:center;">
            <div>
                <div style="font-size:0.6rem;color:#64748B;text-transform:uppercase;font-weight:700;">Sec 10 Exemptions</div>
                <div style="font-size:1rem;font-weight:800;color:#1E40AF;">{fmt(total_sec10)}</div>
            </div>
            <div>
                <div style="font-size:0.6rem;color:#64748B;text-transform:uppercase;font-weight:700;">Chapter VI-A</div>
                <div style="font-size:1rem;font-weight:800;color:#1E40AF;">{fmt(total_via)}</div>
            </div>
            <div>
                <div style="font-size:0.6rem;color:#64748B;text-transform:uppercase;font-weight:700;">Total Tax Benefit</div>
                <div style="font-size:1rem;font-weight:800;color:#166534;">{fmt(total_benefit)}</div>
            </div>
        </div>
    </div>""", unsafe_allow_html=True)

    # ── Headroom alerts ──
    headroom_msgs = []
    if ded.sec_80c_total < 150000:
        gap = 150000 - ded.sec_80c_total
        headroom_msgs.append(f"**80C:** ₹{gap:,.0f} more claimable — add PPF, ELSS, or tax-saver FD")
    if ded.sec_80ccd_1b < 50000:
        gap = 50000 - ded.sec_80ccd_1b
        headroom_msgs.append(f"**80CCD(1B):** ₹{gap:,.0f} NPS contribution can save additional tax")
    if ded.sec_80d_self < self_limit:
        gap = self_limit - ded.sec_80d_self
        headroom_msgs.append(f"**80D (Self):** ₹{gap:,.0f} more claimable if you have health insurance bills")
    if ded.sec_80d_parents < parent_limit:
        gap = parent_limit - ded.sec_80d_parents
        headroom_msgs.append(f"**80D (Parents):** ₹{gap:,.0f} more claimable for parents' health insurance")

    if headroom_msgs:
        st.divider()
        section_chip("💰 Optimization Opportunities")
        for msg in headroom_msgs:
            st.info(msg, icon="💡")

    if result.get("reference"):
        with st.expander("Legal Reference"):
            ref = result["reference"]
            st.markdown(f"**Section:** {ref.get('section','N/A')}")
            st.markdown(f"**Description:** {ref.get('description','N/A')}")

    nav_buttons("Next: Filing Guide →")


# ═══════════════════════════════════════════════════════════════════
#  STEP 7: Filing Guide (with portal mockups + pre-filled values)
# ═══════════════════════════════════════════════════════════════════

def _get_regime_data(tp):
    """Get the recommended regime's computed data for pre-filling."""
    try:
        from taxbuddy.engine.tax_calculator import compare_regimes
        comp = compare_regimes(tp)
        rec = comp["recommended"]
        return comp[f"{rec}_regime"], comp
    except Exception:
        return None, None


def _render_schedule_selector(schedules):
    """Render the checklist of schedules/sub-sections to select on portal."""
    st.markdown("""
    <div style="background:linear-gradient(135deg,#EFF6FF,#F0F9FF);border:1px solid #BFDBFE;
         border-radius:14px;padding:1rem 1.3rem;margin-bottom:1rem;">
        <div style="font-size:1rem;font-weight:800;color:#1E40AF;margin-bottom:0.4rem;">
            📋 Schedules & Sub-sections to Select on Portal
        </div>
        <div style="font-size:0.75rem;color:#64748B;">
            Based on your data, tick ONLY the schedules marked ✅ below.
            Skip the ones marked ⬜ to avoid unnecessary validation errors.
        </div>
    </div>""", unsafe_allow_html=True)

    for s in schedules:
        icon = "✅" if s["select"] else "⬜"
        indent = s.get("indent", False)
        bg = "#F0FDF4" if s["select"] else "#F8FAFC"
        border = "#BBF7D0" if s["select"] else "#E2E8F0"
        color = "#166534" if s["select"] else "#94A3B8"
        ml = "24px" if indent else "0"
        font = "0.72rem" if indent else "0.78rem"
        st.markdown(f"""
        <div style="display:flex;align-items:center;gap:8px;padding:5px 10px;
             margin-left:{ml};margin-bottom:3px;border-radius:8px;
             background:{bg};border:1px solid {border};">
            <span style="font-size:0.9rem;">{icon}</span>
            <div>
                <span style="font-size:{font};font-weight:600;color:{color};">
                    {s['schedule']}
                </span>
                <span style="font-size:0.68rem;color:#94A3B8;margin-left:6px;">
                    {s['reason']}
                </span>
            </div>
        </div>""", unsafe_allow_html=True)


def _render_prefill_section(section):
    """Render one pre-fill section as a portal-styled card with copy-paste values."""
    rows = ""
    for f in section.fields:
        hl = "border-left:3px solid #2563EB;background:#EFF6FF;" if f.highlight else ""
        note_html = (f'<div style="font-size:0.62rem;color:#2563EB;margin-top:1px;">'
                     f'💡 {f.note}</div>') if f.note else ""

        if f.value == "":
            rows += (f'<div style="background:#F1F5F9;padding:4px 10px;border-radius:6px;'
                     f'font-weight:600;color:#1E40AF;font-size:0.72rem;margin:4px 0 1px;">'
                     f'{f.label}</div>')
            continue

        rows += (
            f'<div style="display:grid;grid-template-columns:220px 1fr;gap:6px;'
            f'align-items:start;padding:4px 8px;border-radius:6px;{hl}">'
            f'<div style="font-size:0.72rem;color:#64748B;padding-top:4px;">{f.label}</div>'
            f'<div>'
            f'<div style="padding:4px 10px;border:1px solid #CBD5E1;border-radius:6px;'
            f'background:#FFFFFF;font-size:0.78rem;font-weight:600;color:#0F172A;'
            f'font-family:monospace;letter-spacing:0.5px;">{f.value}</div>'
            f'{note_html}</div>'
            f'</div>'
        )

    st.markdown(f"""
    <div style="border:1px solid #E2E8F0;border-radius:12px;padding:12px;
         background:#FFFFFF;box-shadow:0 1px 4px rgba(0,0,0,0.05);margin-bottom:10px;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;
             padding-bottom:6px;border-bottom:2px solid #2563EB;">
            <span style="font-size:1.1rem;">{section.icon}</span>
            <span style="font-size:0.88rem;font-weight:700;color:#1E293B;">
                {section.title}
            </span>
            <span style="font-size:0.55rem;background:#DBEAFE;color:#1E40AF;
                  padding:2px 8px;border-radius:4px;margin-left:auto;">
                Copy → Portal
            </span>
        </div>
        <div style="display:flex;flex-direction:column;gap:2px;">{rows}</div>
    </div>""", unsafe_allow_html=True)


def page_filing_guide():
    tp = st.session_state.taxpayer
    form = "ITR-2" if (tp.itr_form and "2" in tp.itr_form.value) or tp.has_capital_gains else "ITR-1"
    page_head(f"{form} Filing Guide",
              f"Page-by-page walkthrough with portal previews for {form}.")

    regime_data, comp = _get_regime_data(tp)

    # ── Tab layout: Schedules | Page-by-Page Guide | Your Portal Values ──
    tab_sel, tab_guide, tab_prefill = st.tabs([
        "📋 Schedules to Select",
        "📖 Page-by-Page Guide",
        "📝 Your Portal Values (Copy-Paste)",
    ])

    # ── TAB 1: Applicable Schedules Selector ──
    with tab_sel:
        if regime_data:
            from taxbuddy.guides.portal_prefill import get_applicable_schedules
            schedules = get_applicable_schedules(tp, regime_data, form)
            rec_label = "Old Regime" if regime_data.get("regime") == "old" else "New Regime"
            st.markdown(f"""
            <div style="background:linear-gradient(135deg,#ECFDF5,#F0FDF4);border:1px solid #BBF7D0;
                 border-radius:12px;padding:0.8rem 1.1rem;margin-bottom:0.8rem;">
                <span style="font-size:0.82rem;font-weight:700;color:#166534;">
                    Filing as: {form} under {rec_label}
                </span>
            </div>""", unsafe_allow_html=True)
            _render_schedule_selector(schedules)
            st.info("On the IT portal's first screen, you'll see checkboxes for applicable schedules. "
                    "Tick ONLY the ones marked ✅ above. Selecting unnecessary schedules causes "
                    "validation errors.", icon="💡")
        else:
            st.warning("Upload documents and complete Tax Computation first to see applicable schedules.")

    # ── TAB 2: Page-by-page filing guide ──
    with tab_guide:
        from taxbuddy.guides.itr_filing_guide import get_guide
        for pg in get_guide(form):
            with st.expander(f"**Page {pg['page']}: {pg['title']}**", expanded=(pg['page'] <= 2)):
                if pg.get("mockup"):
                    col_steps, col_mock = st.columns([1, 1], gap="large")
                else:
                    col_steps = st.container()
                    col_mock = None

                with col_steps:
                    for i, s in enumerate(pg.get("steps", []), 1):
                        step_card(i, s)
                    for tip in pg.get("tips", []):
                        st.info(tip, icon="💡")
                    if pg.get("important_lesson"):
                        st.warning(f"**Lesson:** {pg['important_lesson']}", icon="📝")
                    for err in pg.get("common_errors", []):
                        st.error(f"**Error:** {err['error']}")
                        st.success(f"**Fix:** {err['fix']}")

                if col_mock is not None:
                    with col_mock:
                        st.markdown(pg["mockup"], unsafe_allow_html=True)

    # ── TAB 3: Pre-filled portal values ──
    with tab_prefill:
        if regime_data:
            from taxbuddy.guides.portal_prefill import generate_prefill_values
            sections = generate_prefill_values(tp, regime_data, form)
            rec_label = "Old Regime" if regime_data.get("regime") == "old" else "New Regime"

            st.markdown(f"""
            <div style="background:linear-gradient(135deg,#FFF7ED,#FFFBEB);border:1px solid #FED7AA;
                 border-radius:14px;padding:1rem 1.3rem;margin-bottom:1rem;">
                <div style="font-size:1rem;font-weight:800;color:#9A3412;margin-bottom:0.3rem;">
                    📝 Your Exact Portal Values — {form} ({rec_label})
                </div>
                <div style="font-size:0.75rem;color:#78716C;">
                    Copy-paste these values directly into the IT portal fields.
                    All numbers are computed from your uploaded documents.
                </div>
            </div>""", unsafe_allow_html=True)

            for section in sections:
                _render_prefill_section(section)
        else:
            st.warning("Upload documents and complete Tax Computation first to see pre-filled values.")

    nav_buttons("Next: Portal Issues →")


# ═══════════════════════════════════════════════════════════════════
#  STEP 8: Portal Issues
# ═══════════════════════════════════════════════════════════════════

def page_portal():
    page_head("Common Portal Issues & Fixes",
              "Known problems on the e-filing portal and how to solve them.")
    from taxbuddy.knowledge.rules import PORTAL_LESSONS
    for i, l in enumerate(PORTAL_LESSONS, 1):
        with st.expander(f"**{i}. {l['issue']}**"):
            st.markdown(f"**Cause:** {l['cause']}")
            st.divider()
            st.markdown(f"**Fix:** {l['fix']}")
    nav_buttons(show_next=False)


# ═══════════════════════════════════════════════════════════════════
#  ROUTING
# ═══════════════════════════════════════════════════════════════════

PAGE_MAP = {
    0: page_upload,
    1: page_summary,
    2: page_ais_audit,
    3: page_smart_optimizer,
    4: page_tax_computation,
    5: page_itr,
    6: page_filing_guide,
    7: page_portal,
}

PAGE_MAP.get(st.session_state.current_step, page_upload)()
