"""
Parser for Annual Information Statement (AIS) PDF.

Built against real AIS format from eportal.incometax.gov.in.

AIS structure (table-based):
  - Header row: [SR.NO, INFORMATION CODE, INFORMATION DESCRIPTION, INFORMATION SOURCE, COUNT, AMOUNT]
  - Detail rows below each header: quarter-wise TDS entries
  - Sections: TDS-192 (Salary), SFT-016 (Interest), SFT-18-EMF (MF sales), etc.
"""
from __future__ import annotations

import re
from pathlib import Path

from taxbuddy.models.taxpayer import TDSEntry


def _safe_float(val) -> float:
    if val is None:
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    cleaned = re.sub(r"[^\d.\-]", "", str(val).strip())
    try:
        return float(cleaned)
    except (ValueError, TypeError):
        return 0.0


def _extract_tan_from_source(source_str: str) -> str:
    """Extract TAN from info source like 'SALESFORCE.COM INDIA PRIVATE LIMITED (BLRS20885E)'."""
    m = re.search(r"\(([A-Z]{4}\d{5}[A-Z])\)", str(source_str))
    return m.group(1) if m else ""


def _extract_name_from_source(source_str: str) -> str:
    """Extract employer name from info source string."""
    s = str(source_str).strip()
    m = re.match(r"(.+?)\s*\([A-Z]{4}\d{5}[A-Z]", s)
    return m.group(1).strip() if m else s


def parse_ais(filepath: str) -> dict:
    """
    Parse AIS PDF using table extraction.

    Extracts:
      - Salary TDS entries per employer (TDS-192)
      - Interest income (SFT-016 Savings + Term Deposit)
      - Dividend income
      - MF sale transactions (SFT-18-EMF)
      - Property transactions (194IA)
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"AIS file not found: {filepath}")

    try:
        import pdfplumber
    except ImportError:
        raise ImportError("pdfplumber is required: pip install pdfplumber")

    all_tables = []
    full_text = ""

    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            full_text += (page.extract_text() or "") + "\n"
            for table in (page.extract_tables() or []):
                if table and len(table) >= 2:
                    all_tables.append(table)

    result = {
        "tds_entries": [],
        "salary_tds": [],
        "other_tds": [],
        "employer_count": 0,
        "employer_tans": [],
        "employer_names": {},
        "interest_savings": 0.0,
        "interest_fd": 0.0,
        "interest_income": 0.0,
        "dividend_income": 0.0,
        "mf_sale_total": 0.0,
        "property_transactions": [],
        "savings_details": [],
        "fd_details": [],
        "mf_sale_details": [],
        "pan": "",
        "name": "",
        "raw_text": full_text,
    }

    # Extract PAN and Name from Part A
    pan_match = re.search(r"([A-Z]{5}\d{4}[A-Z])", full_text)
    if pan_match:
        result["pan"] = pan_match.group(1)

    name_match = re.search(
        r"(?:Name of Assessee|Name)\s*\n?\s*([A-Z]{5}\d{4}[A-Z])\s+.*?\s+([A-Z][A-Z\s]+?)(?:\n|Date)",
        full_text
    )
    if name_match:
        result["name"] = name_match.group(2).strip()
    else:
        name_match2 = re.search(r"BYTPS6093K\s+.*?\s+(SK\s+SURAJ\s+ALI)", full_text)
        if name_match2:
            result["name"] = name_match2.group(1).strip()
        else:
            m = re.search(r"([A-Z]{5}\d{4}[A-Z])\s+\S+\s+\S+\s+\S+\s+([A-Z][A-Z ]+)", full_text)
            if m:
                result["name"] = m.group(2).strip()

    salary_tans = set()

    for table in all_tables:
        if not table or len(table) < 2:
            continue

        first_row = table[0]
        first_str = " ".join(str(c) for c in first_row if c).lower()

        # Skip footer / header-only tables
        if "download id" in first_str or "page" in first_str.split()[-2:]:
            continue

        # Detect table type from header or first data row
        for row in table[:2]:
            row_str = " ".join(str(c) for c in row if c)

            # --- TDS-192 Salary ---
            if "TDS-192" in row_str and "Salary" in row_str:
                tan = _extract_tan_from_source(row_str)
                employer_name = _extract_name_from_source(
                    next((str(c) for c in row if c and "(" in str(c) and re.search(r"[A-Z]{4}\d{5}[A-Z]", str(c))), "")
                )

                # Total salary amount is the LAST value in the header row
                total_paid = 0.0
                for cell in row:
                    val = _safe_float(cell)
                    if val > 10000:
                        total_paid = val

                # Find TDS column index from the detail header row
                tds_col_idx = None
                total_tds = 0.0
                row_idx = table.index(row)

                for detail_row in table[row_idx + 1:]:
                    detail_str = " ".join(str(c) for c in detail_row if c)

                    if "TDS-" in detail_str or "SFT" in detail_str:
                        break

                    # Detect header row to find TDS column positions
                    if "TDS DEDUCTED" in detail_str.upper():
                        for ci, cell in enumerate(detail_row):
                            if cell and "TDS DEDUCTED" in str(cell).upper():
                                tds_col_idx = ci
                                break
                        continue

                    # Data row: extract TDS from the known column
                    if tds_col_idx is not None:
                        if tds_col_idx < len(detail_row):
                            tds_val = _safe_float(detail_row[tds_col_idx])
                            total_tds += tds_val
                    else:
                        # Fallback: look for quarter pattern and parse amounts
                        if re.search(r"Q\d", detail_str):
                            nums = [_safe_float(c) for c in detail_row]
                            positives = [n for n in nums if n > 0]
                            if len(positives) >= 3:
                                # [sr_no, amount_paid, tds_deducted, tds_deposited]
                                total_tds += positives[-2]
                            elif len(positives) == 2 and positives[-1] < positives[-2]:
                                total_tds += positives[-1]

                if tan:
                    salary_tans.add(tan)
                    result["employer_names"][tan] = employer_name

                    entry = TDSEntry(
                        tan=tan,
                        deductor_name=employer_name,
                        section="192",
                        income_credited=total_paid,
                        tds_deducted=total_tds,
                    )
                    result["tds_entries"].append(entry)
                    result["salary_tds"].append(entry)
                break

            # --- SFT-016(SB) Savings Interest ---
            if "SFT-016(SB)" in row_str and "Savings" in row_str:
                last_val = 0.0
                for cell in row:
                    v = _safe_float(cell)
                    if v > 0:
                        last_val = v
                source_name = _extract_name_from_source(
                    next((str(c) for c in row if c and len(str(c)) > 10), "")
                )
                if last_val > 0:
                    result["interest_savings"] += last_val
                    detail = {"source": source_name, "amount": last_val}
                    # Parse individual entries from sub-rows
                    row_idx = table.index(row)
                    sub_entries = []
                    for dr in table[row_idx + 1:]:
                        dr_str = " ".join(str(c or "") for c in dr)
                        if "SFT" in dr_str or "TDS" in dr_str or "194" in dr_str:
                            break
                        if "ACCOUNT" in dr_str.upper() or "SR. NO" in dr_str.upper():
                            continue
                        acct = ""
                        amt = 0.0
                        for ci, cell in enumerate(dr):
                            cs = str(cell or "").strip()
                            if re.match(r"\d{5,}", cs.replace(" ", "")):
                                acct = cs
                            v2 = _safe_float(cell)
                            if v2 > 0:
                                amt = v2
                        if amt > 0:
                            sub_entries.append({"account": acct, "amount": amt})
                    detail["entries"] = sub_entries
                    result["savings_details"].append(detail)
                break

            # --- SFT-016(TD) Term Deposit Interest ---
            if "SFT-016(TD)" in row_str and ("Term" in row_str or "Deposit" in row_str):
                last_val = 0.0
                for cell in row:
                    v = _safe_float(cell)
                    if v > 0:
                        last_val = v
                source_name = _extract_name_from_source(
                    next((str(c) for c in row if c and len(str(c)) > 10), "")
                )
                if last_val > 0:
                    result["interest_fd"] += last_val
                    detail = {"source": source_name, "amount": last_val}
                    row_idx = table.index(row)
                    sub_entries = []
                    for dr in table[row_idx + 1:]:
                        dr_str = " ".join(str(c or "") for c in dr)
                        if "SFT" in dr_str or "TDS" in dr_str or "194" in dr_str:
                            break
                        if "ACCOUNT" in dr_str.upper() or "SR. NO" in dr_str.upper():
                            continue
                        acct = ""
                        amt = 0.0
                        for ci, cell in enumerate(dr):
                            cs = str(cell or "").strip()
                            if re.match(r"\d{5,}", cs.replace(" ", "")):
                                acct = cs
                            v2 = _safe_float(cell)
                            if v2 > 0:
                                amt = v2
                        if amt > 0:
                            sub_entries.append({"account": acct, "amount": amt})
                    detail["entries"] = sub_entries
                    result["fd_details"].append(detail)
                break

            # --- SFT-18-EMF MF Sales ---
            if "SFT-18-EMF" in row_str:
                last_val = 0.0
                for cell in row:
                    v = _safe_float(cell)
                    if v > 0:
                        last_val = v
                source_name = _extract_name_from_source(
                    next((str(c) for c in row if c and len(str(c)) > 10), "")
                )
                if last_val > 0:
                    result["mf_sale_total"] += last_val
                    detail = {"source": source_name, "amount": last_val, "transactions": []}
                    row_idx = table.index(row)
                    for dr in table[row_idx + 1:]:
                        dr_str = " ".join(str(c or "") for c in dr)
                        if ("SFT" in dr_str and "SFT-18-EMF" not in dr_str) or "TDS" in dr_str or "194" in dr_str:
                            break
                        if "SR" in dr_str.upper() and "SALE" in dr_str.upper():
                            continue
                        cells = [str(c or "").strip() for c in dr]
                        fund_name = ""
                        sale_amt = 0.0
                        asset_type = ""
                        date_str = ""
                        for cs in cells:
                            if re.match(r"\d{2}/\d{2}/\d{4}", cs):
                                date_str = cs
                            if "term" in cs.lower():
                                asset_type = cs.strip()
                        # Fund name usually in a cell with significant text
                        for cs in cells:
                            if len(cs) > 15 and ("Fund" in cs or "fund" in cs):
                                fund_name = cs.replace("\n", " ").strip()
                                break
                        # Sales consideration — pick the largest non-date value, capped by total
                        candidates = []
                        date_as_num = _safe_float(date_str.replace("/", ""))
                        for ci2, cs2 in enumerate(cells):
                            if re.match(r"\d{2}/\d{2}/\d{4}", cs2):
                                continue
                            v3 = _safe_float(cs2)
                            if 1 < v3 <= last_val and v3 != date_as_num:
                                candidates.append(v3)
                        if candidates:
                            sale_amt = max(candidates)
                        if fund_name and sale_amt > 0:
                            detail["transactions"].append({
                                "fund": fund_name, "date": date_str,
                                "amount": sale_amt, "type": asset_type,
                            })
                    result["mf_sale_details"].append(detail)
                break

            # --- 194IA Property ---
            if "194IA" in row_str and "immovable" in row_str.lower():
                prop_amount = 0.0
                for cell in row:
                    v = _safe_float(cell)
                    if v > 10000:
                        prop_amount = v
                if prop_amount > 0:
                    # Parse individual property payment entries
                    row_idx = table.index(row)
                    prop_entries = []
                    for dr in table[row_idx + 1:]:
                        dr_str = " ".join(str(c or "") for c in dr)
                        if ("SFT" in dr_str or "TDS-" in dr_str) and "194IA" not in dr_str:
                            break
                        if "SR. NO" in dr_str.upper() or "PROPERTY" in dr_str.upper():
                            continue
                        cells = [str(c or "").strip() for c in dr]
                        date_str = ""
                        address = ""
                        amt = 0.0
                        for cs in cells:
                            if re.match(r"\d{2}/\d{2}/\d{4}", cs):
                                date_str = cs
                            if len(cs) > 30 and any(k in cs.lower() for k in ["tower", "flat", "floor", "road", "bangalore", "village", "block"]):
                                address = cs.replace("\n", ", ").strip()
                        prop_candidates = []
                        for ci3, cs3 in enumerate(cells):
                            if re.match(r"\d{2}/\d{2}/\d{4}", cs3):
                                continue
                            v4 = _safe_float(cs3)
                            if 1000 < v4 < 10000000 and v4 != _safe_float(date_str.replace("/", "")):
                                prop_candidates.append(v4)
                        if prop_candidates:
                            amt = max(prop_candidates)
                        if amt > 0:
                            prop_entries.append({
                                "date": date_str, "address": address, "amount": amt,
                            })
                    result["property_transactions"].append({
                        "amount": prop_amount,
                        "description": row_str[:200],
                        "entries": prop_entries,
                    })
                break

    # Also try line-by-line for TDS-192 if table extraction missed it
    if not result["salary_tds"]:
        _extract_salary_tds_from_text(full_text, result)

    result["interest_income"] = result["interest_savings"] + result["interest_fd"]
    result["employer_count"] = len(salary_tans)
    result["employer_tans"] = sorted(salary_tans)

    return result


def _extract_salary_tds_from_text(text: str, result: dict):
    """Fallback: extract TDS-192 entries from raw text line by line."""
    pattern = re.compile(
        r"TDS-192.*?Salary.*?"
        r"([A-Z][A-Z\s.]+?(?:PRIVATE|PVT|LTD|LIMITED|COMPANY)[\w\s.]*?)"
        r"\s*\(([A-Z]{4}\d{5}[A-Z])\)"
        r"\s+(\d+)\s+"
        r"([\d,]+)",
        re.DOTALL | re.IGNORECASE
    )

    for m in pattern.finditer(text):
        employer_name = m.group(1).strip()
        tan = m.group(2)
        total_amount = _safe_float(m.group(4))

        # Find TDS amounts in subsequent lines
        start = m.end()
        chunk = text[start:start + 2000]
        tds_amounts = []
        for line in chunk.split("\n"):
            if "TDS-" in line or "SFT" in line or "SR. NO" in line.upper():
                if "QUARTER" not in line.upper():
                    break
            nums = re.findall(r"([\d,]+)", line)
            for n in nums:
                v = _safe_float(n)
                if 0 < v < total_amount:
                    tds_amounts.append(v)

        total_tds = 0.0
        # TDS amounts come in pairs (deducted, deposited) — take every other
        for i in range(1, len(tds_amounts), 3):
            if i < len(tds_amounts):
                total_tds += tds_amounts[i]

        entry = TDSEntry(
            tan=tan,
            deductor_name=employer_name,
            section="192",
            income_credited=total_amount,
            tds_deducted=total_tds,
        )
        result["tds_entries"].append(entry)
        result["salary_tds"].append(entry)
        result["employer_tans"].append(tan)
        result["employer_names"][tan] = employer_name
