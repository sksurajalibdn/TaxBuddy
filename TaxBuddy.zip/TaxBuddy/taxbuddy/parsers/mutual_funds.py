"""
Parser for Mutual Fund Capital Gains Report (Excel / CSV).

Typically downloaded from AMC portals or CAMS/KFinTech, this contains:
  - Fund name, folio number
  - Purchase date, NAV, units, cost
  - Redemption date, NAV, units, sale value
  - STCG and LTCG amounts
  - Grandfathering clause values (for pre-31-Jan-2018 purchases)
"""
from __future__ import annotations

import re
from datetime import date, datetime
from pathlib import Path
from collections import defaultdict
from typing import Optional

from taxbuddy.models.taxpayer import MutualFundTransaction, CapitalGains


def _parse_date(val) -> Optional[date]:
    """Parse various date formats to date object."""
    if isinstance(val, (date, datetime)):
        return val if isinstance(val, date) else val.date()
    if not val:
        return None
    val_str = str(val).strip()
    formats = ["%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S",
               "%d-%b-%Y", "%d-%b-%y", "%m/%d/%Y"]
    for fmt in formats:
        try:
            return datetime.strptime(val_str[:10], fmt).date()
        except ValueError:
            continue
    return None


def _safe_float(val) -> float:
    if val is None:
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    cleaned = re.sub(r"[^\d.\-]", "", str(val).strip())
    try:
        return float(cleaned)
    except (ValueError, TypeError):
        return 0.0


def _get_table_f_period(redeem_date: date) -> str:
    """
    Map redemption date to Table F period for ITR Schedule CG.

    Table F periods (FY 2025-26):
      (i)   Up to 15th June 2025
      (ii)  16th June to 15th September 2025
      (iii) 16th September to 15th December 2025
      (iv)  16th December 2025 to 15th March 2026
      (v)   16th March to 31st March 2026
    """
    fy_start_year = redeem_date.year if redeem_date.month >= 4 else redeem_date.year - 1

    boundaries = [
        ("i",   date(fy_start_year, 4, 1),     date(fy_start_year, 6, 15)),
        ("ii",  date(fy_start_year, 6, 16),     date(fy_start_year, 9, 15)),
        ("iii", date(fy_start_year, 9, 16),      date(fy_start_year, 12, 15)),
        ("iv",  date(fy_start_year, 12, 16),     date(fy_start_year + 1, 3, 15)),
        ("v",   date(fy_start_year + 1, 3, 16),  date(fy_start_year + 1, 3, 31)),
    ]

    for period, start, end in boundaries:
        if start <= redeem_date <= end:
            return period
    return "i"


def parse_mutual_fund_sheet(filepath: str) -> CapitalGains:
    """
    Parse a Mutual Fund Capital Gains Report (Excel).

    Supports common formats from CAMS, KFinTech, and AMC portals.

    Args:
        filepath: Path to .xlsx or .xls file.

    Returns:
        CapitalGains with computed STCG/LTCG and quarterly breakup.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Mutual fund report not found: {filepath}")

    try:
        import openpyxl
    except ImportError:
        raise ImportError("openpyxl is required: pip install openpyxl")

    wb = openpyxl.load_workbook(str(path), data_only=True)

    # Try common sheet names
    sheet_names = [s for s in wb.sheetnames]
    target_sheet = None
    for preferred in ["Capital gains", "Capital Gains", "CG", "Sheet1", "STCG_LTCG"]:
        if preferred in sheet_names:
            target_sheet = wb[preferred]
            break
    if target_sheet is None:
        target_sheet = wb[sheet_names[0]]

    rows = list(target_sheet.iter_rows(values_only=True))
    if not rows:
        return CapitalGains()

    # Find header row
    header_row = None
    header_idx = 0
    for idx, row in enumerate(rows):
        row_str = " ".join(str(c).lower() for c in row if c)
        if any(kw in row_str for kw in ["fund", "scheme", "folio", "redeem", "purchase"]):
            header_row = [str(c).strip().lower() if c else "" for c in row]
            header_idx = idx
            break

    if header_row is None:
        header_row = [str(c).strip().lower() if c else "" for c in rows[0]]
        header_idx = 0

    # Map column indices
    col_map = {}
    keywords = {
        "fund_name": ["fund", "scheme", "name"],
        "folio": ["folio"],
        "purchase_date": ["purchase date", "buy date", "allot"],
        "purchase_nav": ["purchase nav", "buy nav", "purchase price"],
        "purchase_units": ["purchase unit", "buy unit"],
        "purchase_cost": ["purchase cost", "cost", "buy value", "purchase value", "cost of acquisition"],
        "redeem_date": ["redeem date", "sell date", "redemption date", "sale date"],
        "redeem_nav": ["redeem nav", "sell nav", "redemption nav", "sale price"],
        "redeem_units": ["redeem unit", "sell unit", "redemption unit"],
        "redeem_value": ["redeem value", "sell value", "redemption value", "sale value",
                         "sale consideration", "full value"],
        "stcg": ["stcg", "short term", "short-term"],
        "ltcg": ["ltcg", "long term", "long-term"],
        "gain_type": ["type", "gain type", "nature"],
    }

    for field, kws in keywords.items():
        for col_idx, header in enumerate(header_row):
            if any(kw in header for kw in kws):
                col_map[field] = col_idx
                break

    # Parse transactions
    transactions = []
    data_rows = rows[header_idx + 1:]

    for row in data_rows:
        if not row or not any(row):
            continue

        # Skip summary/total rows
        row_str = " ".join(str(c).lower() for c in row if c)
        if any(skip in row_str for skip in ["total", "grand total", "summary"]):
            continue

        txn = MutualFundTransaction()

        if "fund_name" in col_map and row[col_map["fund_name"]]:
            txn.fund_name = str(row[col_map["fund_name"]]).strip()
        if "folio" in col_map and row[col_map["folio"]]:
            txn.folio = str(row[col_map["folio"]]).strip()

        if "purchase_date" in col_map:
            txn.purchase_date = str(row[col_map["purchase_date"]] or "")
        if "purchase_cost" in col_map:
            txn.purchase_cost = _safe_float(row[col_map["purchase_cost"]])
        if "purchase_nav" in col_map:
            txn.purchase_nav = _safe_float(row[col_map["purchase_nav"]])
        if "purchase_units" in col_map:
            txn.purchase_units = _safe_float(row[col_map["purchase_units"]])

        if "redeem_date" in col_map:
            txn.redeem_date = str(row[col_map["redeem_date"]] or "")
        if "redeem_value" in col_map:
            txn.redeem_value = _safe_float(row[col_map["redeem_value"]])
        if "redeem_nav" in col_map:
            txn.redeem_nav = _safe_float(row[col_map["redeem_nav"]])
        if "redeem_units" in col_map:
            txn.redeem_units = _safe_float(row[col_map["redeem_units"]])

        if "stcg" in col_map:
            txn.stcg = _safe_float(row[col_map["stcg"]])
        if "ltcg" in col_map:
            txn.ltcg = _safe_float(row[col_map["ltcg"]])

        if txn.stcg != 0:
            txn.gain_type = "STCG"
        elif txn.ltcg != 0:
            txn.gain_type = "LTCG"
        elif "gain_type" in col_map and row[col_map["gain_type"]]:
            txn.gain_type = str(row[col_map["gain_type"]]).strip().upper()

        if txn.fund_name or txn.stcg != 0 or txn.ltcg != 0:
            transactions.append(txn)

    # Compute totals and quarterly breakup
    cg = CapitalGains(transactions=transactions)
    stcg_by_period = defaultdict(float)
    ltcg_by_period = defaultdict(float)

    for txn in transactions:
        redeem = _parse_date(txn.redeem_date)
        if redeem is None:
            period = "i"
        else:
            period = _get_table_f_period(redeem)

        cg.stcg_111a += txn.stcg
        cg.ltcg_112a += txn.ltcg
        stcg_by_period[period] += txn.stcg
        ltcg_by_period[period] += txn.ltcg

    # Round quarterly values to ensure exact match with totals
    # (Lesson learned: Table F must EXACTLY match BFLA totals)
    cg.stcg_111a = round(cg.stcg_111a)
    cg.ltcg_112a = round(cg.ltcg_112a)

    for period in ["i", "ii", "iii", "iv", "v"]:
        stcg_by_period[period] = round(stcg_by_period[period])
        ltcg_by_period[period] = round(ltcg_by_period[period])

    # Adjust rounding to exactly match totals
    stcg_sum = sum(stcg_by_period.values())
    if stcg_sum != cg.stcg_111a:
        diff = cg.stcg_111a - stcg_sum
        for p in ["i", "ii", "iii", "iv", "v"]:
            if stcg_by_period[p] != 0:
                stcg_by_period[p] += diff
                break

    ltcg_sum = sum(ltcg_by_period.values())
    if ltcg_sum != cg.ltcg_112a:
        diff = cg.ltcg_112a - ltcg_sum
        for p in ["i", "ii", "iii", "iv", "v"]:
            if ltcg_by_period[p] != 0:
                ltcg_by_period[p] += diff
                break

    cg.stcg_quarterly = dict(stcg_by_period)
    cg.ltcg_quarterly = dict(ltcg_by_period)
    cg.ltcg_112a_exempt = min(cg.ltcg_112a, 125000)

    return cg
