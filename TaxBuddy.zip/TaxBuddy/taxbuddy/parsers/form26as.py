"""
Parser for Form 26AS — Annual Tax Statement.

Form 26AS contains:
  - Part A: TDS on income (salary, interest, etc.)
  - Part A1: TDS on income (15G/15H)
  - Part A2: TDS on sale of immovable property
  - Part B: TCS collected
  - Part C: Tax paid (advance tax / self-assessment tax)
  - Part D: Refunds
  - Part E: AIR transactions (SFT)
  - Part F: TDS on sale of immovable property (buyer)
  - Part G: TDS defaults
"""
from __future__ import annotations

import re
from pathlib import Path

from taxbuddy.models.taxpayer import TDSEntry


def _safe_float(val: str) -> float:
    if not val:
        return 0.0
    cleaned = re.sub(r"[^\d.\-]", "", val.strip())
    try:
        return float(cleaned)
    except (ValueError, TypeError):
        return 0.0


def parse_form26as(filepath: str) -> dict:
    """
    Parse Form 26AS PDF and extract TDS/TCS/Tax payment details.

    Returns dict with:
      - tds_salary: TDS on salary (Part A, Section 192)
      - tds_other: TDS on other income
      - tcs: Tax collected at source
      - advance_tax: Advance tax / self-assessment tax paid
      - refunds: Refunds received
      - total_tds: Total TDS credit available
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Form 26AS not found: {filepath}")

    try:
        import pdfplumber
    except ImportError:
        raise ImportError("pdfplumber is required: pip install pdfplumber")

    full_text = ""
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            full_text += page_text + "\n"

    result = {
        "tds_salary": [],
        "tds_other": [],
        "tcs": [],
        "advance_tax": [],
        "refunds": [],
        "total_tds": 0.0,
        "total_tcs": 0.0,
        "total_advance_tax": 0.0,
        "pan": "",
        "raw_text": full_text,
    }

    # Extract PAN
    pan_match = re.search(r"PAN\s*[:\-]?\s*([A-Z]{5}\d{4}[A-Z])", full_text)
    if pan_match:
        result["pan"] = pan_match.group(1)

    # Extract TDS entries
    # Typical pattern: TAN | Deductor Name | Section | Date | Amount Paid | TDS Deposited
    tds_pattern = re.compile(
        r"([A-Z]{4}\d{5}[A-Z])"     # TAN
        r"\s+(.+?)"                    # Deductor name
        r"\s+(192|194[A-Z]?\d?)"       # Section
        r"\s+.*?"
        r"(\d[\d,]*\.?\d*)"            # Amount paid/credited
        r"\s+(\d[\d,]*\.?\d*)",        # TDS
        re.IGNORECASE
    )

    for m in tds_pattern.finditer(full_text):
        entry = TDSEntry(
            tan=m.group(1),
            deductor_name=m.group(2).strip(),
            section=m.group(3),
            income_credited=_safe_float(m.group(4)),
            tds_deducted=_safe_float(m.group(5)),
        )
        if entry.section == "192":
            result["tds_salary"].append(entry)
        else:
            result["tds_other"].append(entry)

    # Calculate totals
    result["total_tds"] = sum(
        e.tds_deducted for e in result["tds_salary"] + result["tds_other"]
    )

    return result


def extract_26as_tables(filepath: str) -> list[dict]:
    """Extract all tables from Form 26AS for manual inspection."""
    try:
        import pdfplumber
    except ImportError:
        raise ImportError("pdfplumber is required: pip install pdfplumber")

    tables = []
    with pdfplumber.open(filepath) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            for table_idx, table in enumerate(page.extract_tables() or []):
                if table:
                    tables.append({
                        "page": page_num,
                        "table_index": table_idx,
                        "headers": table[0] if table else [],
                        "rows": table[1:] if len(table) > 1 else [],
                    })
    return tables
