"""
Parser for ITCS (Income Tax Computation Statement) PDF.

ITCS is an employer-generated tax computation sheet that provides detailed
salary breakup, deductions, and TDS — useful when Form 16 is not yet available
(e.g., mid-year or from a previous employer).

Structure (single large table):
  - Header: Employee info (Name, PAN, TAN, DOB, Regime)
  - Salary components: Basic, HRA, LTA, Bonus, Special Allowance, etc.
  - Gross Salary, Exemptions u/s 10, Standard Deduction
  - Chapter VI-A deductions
  - Tax computation: Tax payable, surcharge, cess, TDS deducted
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from taxbuddy.models.taxpayer import EmployerInfo, TaxRegime


def _safe_float(val) -> float:
    if val is None:
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    cleaned = re.sub(r"[^\d.\-]", "", str(val).strip())
    try:
        return float(cleaned)
    except (ValueError, TypeError):
        return 0.0


def _get_total_col(row: list) -> float:
    """Get the 'Total' column value — last numeric positive cell in the row."""
    result = 0.0
    for cell in reversed(row):
        v = _safe_float(cell)
        if v > 0:
            return v
    return result


def parse_itcs(filepath: str) -> Optional[EmployerInfo]:
    """Parse an ITCS PDF and return an EmployerInfo object."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"ITCS file not found: {filepath}")

    try:
        import pdfplumber
    except ImportError:
        raise ImportError("pdfplumber is required: pip install pdfplumber")

    employer = EmployerInfo()
    full_text = ""

    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            full_text += text + "\n"

            for table in (page.extract_tables() or []):
                if not table or len(table) < 5:
                    continue
                _parse_table(table, employer)

    _parse_header_text(full_text, employer)

    # Company name from first line of PDF (before "Income Tax Computation")
    lines = full_text.strip().split("\n")
    company_name = ""
    for line in lines:
        l = line.strip()
        if not l:
            continue
        if "income tax" in l.lower():
            break
        if len(l) > 5 and l[0].isupper() and "floor" not in l.lower() and "survey" not in l.lower() and "district" not in l.lower():
            company_name = l
            break

    if company_name:
        employer.name = company_name

    return employer


def _parse_header_text(text: str, emp: EmployerInfo):
    """Extract header info from text if not already found from tables."""
    # Employee PAN
    if not emp.pan:
        m = re.search(r"Employee PAN\s+([A-Z]{5}\d{4}[A-Z])", text)
        if m:
            emp.pan = m.group(1)

    # Company TAN
    if not emp.tan:
        m = re.search(r"Company TAN\s+([A-Z]{4}\d{5}[A-Z])", text)
        if m:
            emp.tan = m.group(1)

    # Employee Name
    if not emp.name:
        m = re.search(r"Employee Name\s+([A-Za-z\s]+?)(?:\s{2,}|$|\n)", text)
        if m:
            emp.name = m.group(1).strip()

    # Employer name (first line)
    lines = text.strip().split("\n")
    if lines and not any(x in lines[0].lower() for x in ["income tax", "employee"]):
        candidate = lines[0].strip()
        if len(candidate) > 5 and candidate[0].isupper():
            emp.name_company = candidate

    # Regime
    if "new regime" in text.lower():
        emp.regime_at_employer = TaxRegime.NEW
    elif "old regime" in text.lower():
        emp.regime_at_employer = TaxRegime.OLD

    # DOB
    m = re.search(r"Date of Birth\s+(\d{2}-[A-Z]{3}-\d{4})", text)
    if m:
        emp.sec10_exemptions["dob"] = m.group(1)


def _parse_table(table: list, emp: EmployerInfo):
    """Parse the main ITCS table with salary breakup."""
    for row in table:
        if not row:
            continue

        label = str(row[0] or "").strip()
        label_lower = label.lower()

        # Skip empty or header rows
        if not label or label_lower in ("", "heads of income", "income from salary"):
            continue

        # Header info extraction
        if "employee pan" in label_lower:
            m = re.search(r"([A-Z]{5}\d{4}[A-Z])", label)
            if m and not emp.pan:
                emp.pan = m.group(1)

        if "employee code" in label_lower:
            for cell in row[1:]:
                s = str(cell or "").strip()
                if s and s.isdigit():
                    emp.sec10_exemptions["employee_code"] = s
                    break

        if "employee name" in label_lower:
            for cell in row[1:]:
                s = str(cell or "").strip()
                if s and len(s) > 2 and not s.isdigit():
                    emp.sec10_exemptions["employee_name"] = s
                    break

        if "company tan" in label_lower:
            m = re.search(r"([A-Z]{4}\d{5}[A-Z])", " ".join(str(c) for c in row if c))
            if m and not emp.tan:
                emp.tan = m.group(1)

        # Salary components — use the Total column (last positive value)
        total = _get_total_col(row[1:])

        if label_lower == "basic pay":
            emp.basic_salary = total
        elif label_lower == "house rent allowance":
            emp.hra_received = total
        elif label_lower == "leave travel allowance":
            emp.lta_received = total
        elif label_lower == "bonus":
            emp.bonus = total
        elif label_lower in ("special allowance taxable", "special allowance"):
            emp.special_allowance = total
        elif label_lower == "perquisites":
            emp.perquisites_value = total
        elif label_lower == "previous employer income":
            if total > 0:
                emp.sec10_exemptions["prev_employer_income"] = total

        elif label_lower == "gross salary":
            if total > 10000:
                emp.gross_salary = total

        elif "exemption u/s 10" in label_lower or "exemption under section 10" in label_lower:
            if total > 0:
                emp.sec10_exemptions["total_sec10"] = total

        elif label_lower == "standard deduction":
            emp.standard_deduction = total
        elif label_lower in ("tax on employment", "professional tax"):
            emp.professional_tax = total

        # Chapter VI-A deductions
        elif "80c" in label_lower and "80ccc" not in label_lower and "80ccd" not in label_lower:
            if total > 0:
                emp.pf_employee = total
                emp.sec10_exemptions["deduction_80C"] = total
        elif "80ccd" in label_lower and "1b" in label_lower:
            if total > 0:
                emp.sec10_exemptions["deduction_80CCD_1B"] = total
        elif "80ccd" in label_lower and "(2)" in label_lower:
            if total > 0:
                emp.nps_employer = total
                emp.sec10_exemptions["deduction_80CCD_2"] = total
        elif "80d" in label_lower:
            if total > 0:
                emp.sec10_exemptions["deduction_80D"] = total

        # Tax computation
        elif "tax recovered" in label_lower or "total tax deducted" in label_lower:
            if total > 0:
                emp.tds_deducted = max(emp.tds_deducted, total)
        elif "tax deducted at source" in label_lower:
            pass  # monthly TDS, skip
        elif "total tax payable" in label_lower:
            if total > 0:
                emp.sec10_exemptions["total_tax_payable"] = total

    # Employer name from company header
    if hasattr(emp, "name_company") and emp.name_company and not emp.name:
        emp.name = emp.name_company
