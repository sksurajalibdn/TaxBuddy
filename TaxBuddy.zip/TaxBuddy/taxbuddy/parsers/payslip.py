"""
Parser for Payslip PDF.

Built against real Deloitte payslip format.

Structure (single table per page):
  Header: Employee info (EMP NO, NAME, PAN, UAN, Regime, etc.)
  Earnings/Deductions side-by-side
  Income Tax Calculation section
  Investment Details section
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional


def _safe_float(val) -> float:
    if val is None:
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    cleaned = re.sub(r"[^\d.\-]", "", str(val).strip())
    try:
        return float(cleaned)
    except (ValueError, TypeError):
        return 0.0


def parse_payslip(filepath: str) -> dict:
    """
    Parse a payslip PDF and extract salary components + tax calculation.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Payslip not found: {filepath}")

    try:
        import pdfplumber
    except ImportError:
        raise ImportError("pdfplumber is required: pip install pdfplumber")

    result = {
        "employee_name": "",
        "emp_no": "",
        "pan": "",
        "uan": "",
        "designation": "",
        "location": "",
        "regime": "",
        "month": "",
        "employer_name": "",
        "earnings": {},
        "deductions": {},
        "total_earnings": 0.0,
        "total_deductions": 0.0,
        "net_salary": 0.0,
        "tax_calculation": {},
        "investment_declarations": {},
    }

    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            tables = page.extract_tables() or []

            # Extract month from header text
            month_match = re.search(r"PAYSLIP FOR THE MONTH OF\s+([A-Z]+\s+\d{4})", text, re.IGNORECASE)
            if month_match:
                result["month"] = month_match.group(1).strip()

            # Employer name from first line
            lines = text.strip().split("\n")
            if lines:
                first_line = lines[0].strip()
                if "private limited" in first_line.lower() or "pvt" in first_line.lower():
                    result["employer_name"] = first_line

            for table in tables:
                if not table:
                    continue
                _parse_payslip_table(table, result, text)

    return result


def _parse_payslip_table(table: list, result: dict, full_text: str):
    """Parse the main payslip table."""
    for row in table:
        if not row:
            continue

        row_strs = [str(c).strip() if c else "" for c in row]
        row_joined = " ".join(row_strs).strip()
        row_lower = row_joined.lower()

        # Header metadata
        _extract_metadata(row_strs, result)

        # Earnings
        if row_strs[0] == "BASIC PAY":
            result["earnings"]["basic"] = _safe_float(row_strs[3] if len(row_strs) > 3 else 0)
        elif row_strs[0] == "HOUSE RENT ALLOWANCE":
            result["earnings"]["hra"] = _safe_float(row_strs[3] if len(row_strs) > 3 else 0)
        elif row_strs[0] == "SPECIAL ALLOWANCE":
            result["earnings"]["special_allowance"] = _safe_float(row_strs[3] if len(row_strs) > 3 else 0)
        elif row_strs[0] == "LEAVE TRAVEL ALLOWANCE":
            result["earnings"]["lta"] = _safe_float(row_strs[3] if len(row_strs) > 3 else 0)
        elif row_strs[0] == "SODEXO ENCASHMENT":
            result["earnings"]["sodexo"] = _safe_float(row_strs[3] if len(row_strs) > 3 else 0)
        elif row_strs[0] == "Rewards":
            result["earnings"]["rewards"] = _safe_float(row_strs[3] if len(row_strs) > 3 else 0)

        # Deductions (typically in column index 5+)
        if "PROVIDENT FUND" in row_joined:
            for i, s in enumerate(row_strs):
                if "PROVIDENT FUND" in s:
                    result["deductions"]["pf"] = _safe_float(row_strs[i + 4] if i + 4 < len(row_strs) else
                                                              row_strs[i + 1] if i + 1 < len(row_strs) else 0)
                    break
        if "PROFESSION TAX" in row_joined:
            for i, s in enumerate(row_strs):
                if "PROFESSION TAX" in s:
                    result["deductions"]["professional_tax"] = _safe_float(row_strs[i + 4] if i + 4 < len(row_strs) else
                                                                           row_strs[i + 1] if i + 1 < len(row_strs) else 0)
                    break

        # Total line
        if "Total Earnings" in row_joined:
            m = re.search(r"Total Earnings\s*Rs\.\s*([\d,.]+)", row_joined)
            if m:
                result["total_earnings"] = _safe_float(m.group(1))
        if "Total Deductions" in row_joined:
            m = re.search(r"Total Deductions\s*Rs\.\s*([\d,.]+)", row_joined)
            if m:
                result["total_deductions"] = _safe_float(m.group(1))
        if "Net Salary" in row_joined:
            m = re.search(r"Net Salary\s*Rs\.\s*([\d,.]+)", row_joined)
            if m:
                result["net_salary"] = _safe_float(m.group(1))

        # Tax calculation section
        _extract_tax_calc(row_strs, row_lower, result)

    # Also extract from full text if table parsing missed
    _extract_from_text(full_text, result)


def _extract_metadata(row_strs: list[str], result: dict):
    """Extract employee metadata from row."""
    if not row_strs:
        return

    key = row_strs[0].upper()
    val = row_strs[1] if len(row_strs) > 1 else ""
    if val.startswith(":"):
        val = val[1:].strip()

    if key == "NAME":
        result["employee_name"] = val
    elif key == "EMP NO":
        result["emp_no"] = val
    elif key == "DESIGNATION":
        result["designation"] = val
    elif key == "UAN":
        result["uan"] = val

    # PAN from later columns
    for i, s in enumerate(row_strs):
        if s == "PAN" and i + 1 < len(row_strs):
            pan_val = row_strs[i + 1].replace(":", "").strip()
            pan_match = re.search(r"([A-Z]{5}\d{4}[A-Z])", pan_val)
            if pan_match:
                result["pan"] = pan_match.group(1)

    # Regime
    for i, s in enumerate(row_strs):
        if "Regime Type" in s:
            regime_val = row_strs[i + 1] if i + 1 < len(row_strs) else ""
            regime_val = regime_val.replace(":", "").strip()
            result["regime"] = regime_val

    # Location
    for i, s in enumerate(row_strs):
        if "LOCATION" in s.upper():
            loc_val = row_strs[i + 1] if i + 1 < len(row_strs) else ""
            result["location"] = loc_val.replace(":", "").strip()


def _extract_tax_calc(row_strs: list[str], row_lower: str, result: dict):
    """Extract income tax calculation fields."""
    if not row_strs:
        return

    label = row_strs[0].replace("(cid:9)", "").strip()
    label_lower = label.lower()

    # Find amount — look for the last non-empty numeric cell
    amount = 0.0
    for cell in reversed(row_strs[1:]):
        v = _safe_float(cell)
        if v != 0 or (cell and cell.strip() not in ("", "None")):
            amount = v
            break

    mappings = {
        "total income": "total_income",
        "net taxable income": "net_taxable_income",
        "standard deduction": "standard_deduction",
        "gross taxable income": "gross_taxable_income",
        "income tax payable": "tax_payable",
        "net income tax payable": "net_tax_payable",
        "surcharge": "surcharge",
        "cess": "cess",
        "total income tax": "total_tax",
    }

    for keyword, field in mappings.items():
        if keyword in label_lower:
            result["tax_calculation"][field] = amount
            break

    # Specific pattern matches
    if "basic pay" in label_lower and "cumulative" not in row_lower:
        if len(row_strs) > 2:
            v = _safe_float(row_strs[2])
            if v > 0:
                result["tax_calculation"]["cumulative_basic"] = v

    if "hra rent paid" in row_lower:
        m = re.search(r"(\d[\d,]*\.?\d*)", row_lower.split("hra rent paid")[-1])
        if m:
            result["investment_declarations"]["hra_rent_paid"] = _safe_float(m.group(1))


def _extract_from_text(text: str, result: dict):
    """Extract data from raw text as fallback."""
    # Employer
    if not result["employer_name"]:
        m = re.search(r"^(.+?(?:Private Limited|Pvt\.\s*Ltd))", text, re.IGNORECASE | re.MULTILINE)
        if m:
            result["employer_name"] = m.group(1).strip()

    # PAN
    if not result["pan"]:
        m = re.search(r"PAN\s*[:\s]*([A-Z]{5}\d{4}[A-Z])", text)
        if m:
            result["pan"] = m.group(1)
