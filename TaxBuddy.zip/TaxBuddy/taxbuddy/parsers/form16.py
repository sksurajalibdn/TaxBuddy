"""
Parser for Form 16 (PDF) — Certificate of TDS on Salary u/s 203.

Built against real Form 16 format from the TRACES/employer portal.

Real Form 16 structure (page 1 TEXT format):
  Form 16
  : 2026-27          ← value comes BEFORE label in this PDF
  Assessment Year
  : SALESFORCE.COM INDIA PRIVATE LIMITED
  Employer Name
  : BLRS20885E
  Employer TAN

Part A (page 2-3): Quarter-wise TDS summary
Part B (page 4+): Salary breakup, exemptions, deductions, tax computation
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from taxbuddy.models.taxpayer import EmployerInfo, TaxRegime


def _safe_float(val) -> float:
    if val is None:
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    cleaned = re.sub(r"[^\d.\-]", "", str(val).strip())
    try:
        return float(cleaned)
    except (ValueError, TypeError):
        return 0.0


def parse_form16(filepath: str) -> Optional[EmployerInfo]:
    """Parse a Form 16 PDF using text + table extraction."""
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Form 16 not found: {filepath}")

    try:
        import pdfplumber
    except ImportError:
        raise ImportError("pdfplumber is required: pip install pdfplumber")

    employer = EmployerInfo()
    all_tables = []
    full_text = ""

    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            full_text += (page.extract_text() or "") + "\n"
            for table in (page.extract_tables() or []):
                if table:
                    all_tables.append(table)

    # ── Extract header info from TEXT ─────────────────────────────────
    # Format in this PDF: value appears on line BEFORE the label
    lines = full_text.split("\n")

    for i, line in enumerate(lines):
        stripped = line.strip().rstrip(":")
        # "Employer Name" appears AFTER the employer name value
        if stripped == "Employer Name" and i > 0:
            prev = lines[i - 1].strip().lstrip(":").strip()
            if len(prev) > 3 and not prev.startswith("Form") and "PAN" not in prev:
                employer.name = prev

        # "Employer TAN" appears AFTER the TAN value
        if stripped == "Employer TAN" and i > 0:
            prev = lines[i - 1].strip().lstrip(":").strip()
            tan_m = re.search(r"([A-Z]{4}\d{5}[A-Z])", prev)
            if tan_m:
                employer.tan = tan_m.group(1)

        # "Employee PAN" appears AFTER the PAN value
        if stripped == "Employee PAN" and i > 0:
            prev = lines[i - 1].strip().lstrip(":").strip()
            pan_m = re.search(r"([A-Z]{5}\d{4}[A-Z])", prev)
            if pan_m:
                employer.pan = pan_m.group(1)

    # Also try table-based extraction for employer info (Part A header)
    for table in all_tables:
        for row in table:
            if not row:
                continue
            row_str = " ".join(str(c) for c in row if c)

            # TAN from Part A table
            if not employer.tan:
                tan_m = re.search(r"([A-Z]{4}\d{5}[A-Z])", row_str)
                if tan_m and "PAN" not in row_str:
                    employer.tan = tan_m.group(1)

            # Employee PAN
            if not employer.pan:
                pan_m = re.search(r"PAN of the.*?Employee.*?([A-Z]{5}\d{4}[A-Z])", row_str)
                if pan_m:
                    employer.pan = pan_m.group(1)

            # Employer name from table header
            if not employer.name or employer.name == employer.tan:
                for cell in row:
                    s = str(cell or "").strip()
                    if ("PRIVATE LIMITED" in s or "PVT" in s) and len(s) > 10:
                        employer.name = s.split("\n")[0].strip()
                        break

    # Fallback: extract employer name from full text
    if not employer.name or employer.name == employer.tan:
        name_m = re.search(
            r"Name and address of the Employer.*?\n([A-Z][A-Z\s.]+(?:PRIVATE LIMITED|PVT\.?\s*LTD|LIMITED))",
            full_text, re.DOTALL
        )
        if name_m:
            employer.name = name_m.group(1).strip().split("\n")[0].strip()

    # Period
    period_m = re.search(r"From\s*[:\n]?\s*(\d{2}-\w{3}-\d{4})", full_text)
    if period_m:
        employer.period_from = period_m.group(1)
    period_m2 = re.search(r"To\s*[:\n]?\s*(\d{2}-\w{3}-\d{4})", full_text)
    if period_m2:
        employer.period_to = period_m2.group(1)

    # ── Part A: TDS Summary from quarter table ────────────────────────
    for table in all_tables:
        for row in table:
            if not row:
                continue
            row_str = " ".join(str(c) for c in row if c)

            # Look for "Total (Rs.)" or "Total" row in Part A
            if re.search(r"Total\s*(\(Rs\.\))?", row_str):
                amounts = []
                for cell in row:
                    v = _safe_float(cell)
                    if v > 10000:
                        amounts.append(v)
                if len(amounts) >= 2:
                    # Amounts are [gross_paid, tds_deducted, tds_deposited]
                    amounts.sort(reverse=True)
                    if amounts[0] > 100000 and employer.gross_salary == 0:
                        employer.gross_salary = amounts[0]
                    if len(amounts) >= 2 and amounts[1] > 1000 and employer.tds_deducted == 0:
                        employer.tds_deducted = amounts[1]

    # ── Part B: Detailed salary breakup ───────────────────────────────
    for table in all_tables:
        for row in table:
            if not row or len(row) < 2:
                continue

            label_parts = []
            for cell in row[:2]:
                if cell:
                    label_parts.append(str(cell).strip())
            label = " ".join(label_parts)
            label_lower = label.lower()

            # Regime detection
            if "115bac" in label_lower or "opting out" in label_lower:
                for cell in row:
                    s = str(cell or "").strip().lower()
                    if s == "yes":
                        employer.regime_at_employer = TaxRegime.OLD
                    elif s == "no":
                        employer.regime_at_employer = TaxRegime.NEW

            # Salary 17(1) — use the LAST positive value in the row
            if "17(1)" in label or "section 17(1)" in label_lower:
                v = _last_positive(row[2:])
                if v > 100000:
                    employer.gross_salary = v

            # Basic salary / Basic pay
            if re.search(r"\bbasic\b", label_lower) and "deduction" not in label_lower:
                v = _last_positive(row[2:])
                if v > 10000:
                    employer.basic_salary = v

            # HRA received (component, not exemption)
            if ("house rent" in label_lower and "exempt" not in label_lower and "10(13" not in label_lower) or \
               ("hra" in label_lower and "exempt" not in label_lower and "10(13" not in label_lower):
                v = _last_positive(row[2:])
                if v > 0 and employer.hra_received == 0:
                    employer.hra_received = v

            # Total salary (d) — but NOT the 80C deduction total which also uses (d)
            if _is_item(row, "(d)") and "total" in label_lower and "deduction" not in label_lower and "80c" not in label_lower:
                v = _last_positive(row[2:])
                if v > 100000:
                    employer.gross_salary = v

            # Other employer salary
            if "other employer" in label_lower:
                v = _last_positive(row[2:])
                if v > 0:
                    employer.sec10_exemptions["prev_employer_salary"] = v

            # HRA exemption u/s 10(13A) — NOT the actual HRA component
            if "10(13a)" in label_lower or ("house rent" in label_lower and "allowance" in label_lower and "exempt" in label_lower):
                v = _last_positive(row[2:])
                if v > 0:
                    employer.sec10_exemptions["hra_exempt"] = v

            # Other exemptions u/s 10
            if "total amount of exemption" in label_lower and "section 10" in label_lower:
                v = _last_positive(row[2:])
                if v > 0:
                    employer.sec10_exemptions["total_sec10"] = v

            # Standard deduction 16(ia)
            if "16(ia)" in label_lower or "standard deduction" in label_lower:
                v = _last_positive(row[2:])
                if v > 0:
                    employer.standard_deduction = v

            # Professional tax 16(iii)
            if "16(iii)" in label_lower or "tax on employment" in label_lower:
                v = _last_positive(row[2:])
                if v > 0:
                    employer.professional_tax = v

            # Salary income (line 6)
            if _is_item(row, "6.") and "salaries" in label_lower:
                v = _last_positive(row[2:])
                if v > 0:
                    employer.sec10_exemptions["salary_income"] = v

            # 80C (row has gross and deductible — take deductible = last)
            if "80c" in label_lower and "80ccc" not in label_lower and "80ccd" not in label_lower:
                amounts = [_safe_float(c) for c in row[2:] if _safe_float(c) > 0]
                if amounts:
                    employer.sec10_exemptions["deduction_80C"] = amounts[-1]

            # 80CCD(1B)
            if "80ccd" in label_lower and "(1b)" in label_lower:
                amounts = [_safe_float(c) for c in row[2:] if _safe_float(c) > 0]
                if amounts:
                    employer.sec10_exemptions["deduction_80CCD_1B"] = amounts[-1]

            # 80CCD(2) employer
            if "80ccd" in label_lower and "(2)" in label_lower:
                amounts = [_safe_float(c) for c in row[2:] if _safe_float(c) > 0]
                if amounts:
                    employer.sec10_exemptions["deduction_80CCD_2"] = amounts[-1]

            # 80D
            if "80d" in label_lower and "health" in label_lower:
                amounts = [_safe_float(c) for c in row[2:] if _safe_float(c) > 0]
                if amounts:
                    employer.sec10_exemptions["deduction_80D"] = amounts[-1]

            # Tax on total income (line 13)
            if "tax on total income" in label_lower:
                v = _last_positive(row[2:])
                if v > 0:
                    employer.sec10_exemptions["tax_on_income"] = v

            # Surcharge (line 15)
            if "surcharge" in label_lower:
                v = _last_positive(row[2:])
                if v > 0:
                    employer.sec10_exemptions["surcharge"] = v

            # Net tax payable (line 21)
            if "net tax payable" in label_lower:
                v = _last_positive(row[2:])
                if v > 0:
                    employer.sec10_exemptions["net_tax_payable"] = v

    # Map extracted deductions from sec10_exemptions dict to proper model fields
    exm = employer.sec10_exemptions
    if employer.pf_employee == 0 and exm.get("deduction_80C", 0) > 0:
        employer.pf_employee = exm["deduction_80C"]
    if employer.nps_employer == 0 and exm.get("deduction_80CCD_2", 0) > 0:
        employer.nps_employer = exm["deduction_80CCD_2"]

    return employer


def _is_item(row: list, prefix: str) -> bool:
    """Check if row starts with a given item prefix like '(d)' or '6.'"""
    if row and row[0]:
        return str(row[0]).strip() == prefix
    return False


def _last_positive(cells: list) -> float:
    """Return the last positive numeric value from a list of cells."""
    result = 0.0
    for cell in cells:
        v = _safe_float(cell)
        if v > 0:
            result = v
    return result
