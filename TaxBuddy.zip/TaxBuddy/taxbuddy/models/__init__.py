"""Data models for taxpayer information."""
