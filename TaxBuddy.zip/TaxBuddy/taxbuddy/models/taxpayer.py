"""Data models for taxpayer information and tax computation."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class TaxRegime(Enum):
    OLD = "old"
    NEW = "new"


class ResidentialStatus(Enum):
    RESIDENT = "Resident"
    NON_RESIDENT = "Non-Resident"
    RNOR = "Resident but Not Ordinarily Resident"


class ITRForm(Enum):
    ITR1 = "ITR-1 (Sahaj)"
    ITR2 = "ITR-2"


class City(Enum):
    METRO = "Metro"
    NON_METRO = "Non-Metro"


# For FY 2025-26 (AY 2026-27): Only Delhi, Mumbai, Kolkata, Chennai are metro
# for HRA u/s 10(13A). Bengaluru/Hyderabad were classified as metro only from
# FY 2026-27 (April 2026) per GOI notification.
METRO_CITIES_FY2025_26 = {
    "delhi", "new delhi", "mumbai", "navi mumbai", "thane",
    "kolkata", "chennai",
}

# From FY 2026-27 onwards (for future use)
METRO_CITIES_FY2026_27 = {
    "delhi", "new delhi", "mumbai", "navi mumbai", "thane",
    "kolkata", "chennai",
    "bangalore", "bengaluru", "hyderabad",
}

# Active metro list for current FY 2025-26
METRO_CITIES = METRO_CITIES_FY2025_26


@dataclass
class EmployerInfo:
    name: str = ""
    tan: str = ""
    pan: str = ""
    period_from: str = ""
    period_to: str = ""
    gross_salary: float = 0.0
    basic_salary: float = 0.0
    hra_received: float = 0.0
    lta_received: float = 0.0
    special_allowance: float = 0.0
    other_allowances: float = 0.0
    bonus: float = 0.0
    commission: float = 0.0
    pf_employer: float = 0.0
    pf_employee: float = 0.0
    nps_employer: float = 0.0
    professional_tax: float = 0.0
    standard_deduction: float = 0.0
    tds_deducted: float = 0.0
    gratuity_received: float = 0.0
    leave_encashment: float = 0.0
    perquisites_value: float = 0.0
    sec10_exemptions: dict = field(default_factory=dict)
    regime_at_employer: TaxRegime = TaxRegime.OLD


@dataclass
class HRADetails:
    total_hra_received: float = 0.0
    total_basic_salary: float = 0.0
    rent_paid_annual: float = 0.0
    rent_paid_monthly: float = 0.0
    city: City = City.METRO
    months: int = 12
    hra_exemption: float = 0.0


@dataclass
class MutualFundTransaction:
    fund_name: str = ""
    folio: str = ""
    purchase_date: str = ""
    purchase_nav: float = 0.0
    purchase_units: float = 0.0
    purchase_cost: float = 0.0
    redeem_date: str = ""
    redeem_nav: float = 0.0
    redeem_units: float = 0.0
    redeem_value: float = 0.0
    stcg: float = 0.0
    ltcg: float = 0.0
    gain_type: str = ""  # "STCG" or "LTCG"
    holding_period_days: int = 0


@dataclass
class CapitalGains:
    stcg_111a: float = 0.0  # Equity MF / listed shares (20%)
    stcg_other: float = 0.0  # Other short-term gains (slab rate)
    ltcg_112a: float = 0.0  # Equity MF / listed shares (12.5%)
    ltcg_112: float = 0.0   # Other long-term gains (20% with indexation)
    ltcg_112a_exempt: float = 0.0  # 1.25L exemption
    stcg_quarterly: dict = field(default_factory=dict)
    ltcg_quarterly: dict = field(default_factory=dict)
    transactions: list = field(default_factory=list)


@dataclass
class Deductions:
    """Chapter VI-A deductions."""
    sec_80c: float = 0.0        # PF, PPF, ELSS, LIC, tuition fees (max 1.5L)
    sec_80ccc: float = 0.0      # Pension fund (within 80C limit)
    sec_80ccd_1: float = 0.0    # Employee NPS (within 80C limit)
    sec_80ccd_1b: float = 0.0   # Additional NPS (max 50K)
    sec_80ccd_2: float = 0.0    # Employer NPS (max 10% of basic)
    sec_80d_self: float = 0.0   # Health insurance self/family (max 25K/50K)
    sec_80d_parents: float = 0.0  # Health insurance parents (max 25K/50K)
    sec_80dd: float = 0.0       # Disabled dependent (75K/1.25L)
    sec_80ddb: float = 0.0      # Specified disease treatment (40K/1L)
    sec_80e: float = 0.0        # Education loan interest
    sec_80ee: float = 0.0       # Home loan interest first-time buyer
    sec_80eea: float = 0.0      # Home loan interest affordable housing
    sec_80g: float = 0.0        # Donations
    sec_80gg: float = 0.0       # Rent paid (no HRA)
    sec_80tta: float = 0.0      # Savings interest (max 10K)
    sec_80ttb: float = 0.0      # Senior citizen interest (max 50K)
    sec_80u: float = 0.0        # Self disability (75K/1.25L)

    @property
    def sec_80c_total(self) -> float:
        raw = self.sec_80c + self.sec_80ccc + self.sec_80ccd_1
        return min(raw, 150000)

    @property
    def total_via(self) -> float:
        return (
            self.sec_80c_total + self.sec_80ccd_1b + self.sec_80ccd_2 +
            self.sec_80d_self + self.sec_80d_parents +
            self.sec_80dd + self.sec_80ddb + self.sec_80e +
            self.sec_80ee + self.sec_80eea + self.sec_80g + self.sec_80gg +
            self.sec_80tta + self.sec_80ttb + self.sec_80u
        )


@dataclass
class Section10Exemptions:
    hra: float = 0.0                 # 10(13A)
    lta: float = 0.0                 # 10(5)
    gratuity: float = 0.0           # 10(10)
    leave_encashment: float = 0.0   # 10(10AA)
    children_education: float = 0.0  # 10(14)(ii)
    other_prescribed: float = 0.0   # 10(14)(i) Rule 2BB
    standard_deduction: float = 0.0  # u/s 16
    professional_tax: float = 0.0

    @property
    def total(self) -> float:
        return (self.hra + self.lta + self.gratuity +
                self.leave_encashment + self.children_education +
                self.other_prescribed)


@dataclass
class OtherIncome:
    interest_savings: float = 0.0
    interest_fd: float = 0.0
    interest_other: float = 0.0
    interest_housing_loan: float = 0.0
    dividend: float = 0.0
    rental_income: float = 0.0
    other: float = 0.0

    @property
    def total(self) -> float:
        return (self.interest_savings + self.interest_fd +
                self.interest_other + self.dividend +
                self.rental_income + self.other)


@dataclass
class TDSEntry:
    deductor_name: str = ""
    tan: str = ""
    income_credited: float = 0.0
    tds_deducted: float = 0.0
    section: str = ""  # 192, 194A, etc.


@dataclass
class TaxPayer:
    name: str = ""
    pan: str = ""
    dob: str = ""
    aadhaar: str = ""
    email: str = ""
    phone: str = ""
    address: str = ""
    city: str = ""
    state: str = ""
    pincode: str = ""
    residential_status: ResidentialStatus = ResidentialStatus.RESIDENT
    assessment_year: str = "2026-27"
    financial_year: str = "2025-26"

    employers: list[EmployerInfo] = field(default_factory=list)
    hra_details: Optional[HRADetails] = None
    capital_gains: CapitalGains = field(default_factory=CapitalGains)
    deductions: Deductions = field(default_factory=Deductions)
    exemptions: Section10Exemptions = field(default_factory=Section10Exemptions)
    other_income: OtherIncome = field(default_factory=OtherIncome)
    tds_entries: list[TDSEntry] = field(default_factory=list)

    itr_form: Optional[ITRForm] = None
    recommended_regime: Optional[TaxRegime] = None

    has_foreign_assets: bool = False
    has_foreign_income: bool = False
    is_director: bool = False
    has_unlisted_shares: bool = False
    has_multiple_house_property: bool = False
    has_capital_gains: bool = False
    has_business_income: bool = False

    @property
    def total_gross_salary(self) -> float:
        return sum(e.gross_salary for e in self.employers)

    @property
    def total_basic_salary(self) -> float:
        return sum(e.basic_salary for e in self.employers)

    @property
    def total_hra_received(self) -> float:
        return sum(e.hra_received for e in self.employers)

    @property
    def total_tds(self) -> float:
        return sum(e.tds_deducted for e in self.employers)

    @property
    def is_metro(self) -> bool:
        return self.city.lower().strip() in METRO_CITIES
