"""
Page-by-page ITR Filing Guide for the Income Tax e-Filing Portal.

Built from real-world experience filing ITR-1 and ITR-2, including
common pitfalls, validation errors, and their solutions.

Each page includes a visual mockup of the portal screen.

Source: eportal.incometax.gov.in
"""


def _portal_mockup(fields, title="", breadcrumb=""):
    """Generate HTML that resembles an IT portal page mockup.
    Uses only <div>/<span> — no <input>/<select> which Streamlit sanitizes.
    """
    rows = ""
    for f in fields:
        ftype = f.get("type", "text")
        val = f.get("value", "")
        label = f.get("label", "")
        note = f.get("note", "")
        highlight = f.get("highlight", False)
        hl_style = "border-left:3px solid #2563EB;background:#EFF6FF;" if highlight else ""

        if ftype == "header":
            rows += f'<div style="background:#EFF6FF;padding:6px 12px;border-radius:6px;font-weight:600;color:#1E40AF;font-size:0.78rem;margin:6px 0 2px;">{label}</div>'
            continue
        if ftype == "divider":
            rows += '<div style="border-top:1px solid #E2E8F0;margin:6px 0;"></div>'
            continue

        if ftype == "dropdown":
            inner = (
                f'<div style="padding:5px 10px;border:1px solid #CBD5E1;border-radius:6px;'
                f'background:#fff;font-size:0.78rem;color:#1E293B;display:flex;'
                f'justify-content:space-between;align-items:center;">'
                f'{val} <span style="color:#94A3B8;">▾</span></div>'
            )
        elif ftype == "checkbox":
            chk = "☑" if val else "☐"
            inner = f'<span style="font-size:0.78rem;color:#475569;">{chk} {f.get("check_label", "")}</span>'
        else:
            inner = (
                f'<div style="padding:5px 10px;border:1px solid #CBD5E1;border-radius:6px;'
                f'background:#F8FAFC;font-size:0.78rem;color:#64748B;">{val}</div>'
            )

        note_html = f'<div style="font-size:0.65rem;color:#2563EB;margin-top:2px;">💡 {note}</div>' if note else ""
        rows += (
            f'<div style="display:grid;grid-template-columns:180px 1fr;gap:6px;'
            f'align-items:start;padding:4px 8px;border-radius:6px;{hl_style}">'
            f'<div style="font-size:0.75rem;color:#64748B;padding-top:5px;">{label}</div>'
            f'<div>{inner}{note_html}</div>'
            f'</div>'
        )

    bc_html = f'<div style="font-size:0.65rem;color:#94A3B8;margin-bottom:6px;">{breadcrumb}</div>' if breadcrumb else ""
    title_html = (
        f'<div style="font-size:0.88rem;font-weight:700;color:#1E293B;margin-bottom:8px;'
        f'padding-bottom:5px;border-bottom:2px solid #2563EB;">{title}</div>'
    ) if title else ""

    return (
        f'<div style="border:1px solid #E2E8F0;border-radius:10px;padding:12px;background:#FFFFFF;'
        f'box-shadow:0 1px 4px rgba(0,0,0,0.06);margin:8px 0;position:relative;">'
        f'<div style="position:absolute;top:6px;right:10px;font-size:0.55rem;background:#E2E8F0;'
        f'padding:2px 8px;border-radius:4px;color:#64748B;">Portal Preview</div>'
        f'{bc_html}{title_html}'
        f'<div style="display:flex;flex-direction:column;gap:2px;">{rows}</div>'
        f'</div>'
    )


ITR1_GUIDE = [
    {
        "page": 1,
        "title": "Personal Information",
        "url": "eportal.incometax.gov.in → e-File → Income Tax Returns → File Income Tax Return",
        "steps": [
            "Select Assessment Year: 2026-27",
            "Select ITR Form: ITR-1 (Sahaj)",
            "Filing Type: Original (or Revised if re-filing)",
            "PAN will be auto-filled from your login",
            "Verify Name, DOB, Aadhaar",
            "Residential Status: Select 'Resident'",
        ],
        "mockup": _portal_mockup([
            {"label": "Assessment Year", "type": "dropdown", "value": "2026-27",
             "options": ["2026-27", "2025-26"], "highlight": True},
            {"label": "ITR Form", "type": "dropdown", "value": "ITR-1 (Sahaj)",
             "options": ["ITR-1 (Sahaj)", "ITR-2", "ITR-3", "ITR-4"],
             "note": "Choose ITR-1 only if income < ₹50L and no capital gains"},
            {"label": "Filing Type", "type": "dropdown", "value": "Original",
             "options": ["Original", "Revised u/s 139(5)"]},
            {"label": "PAN", "value": "XXXXX0000X"},
            {"label": "Full Name", "value": "As per PAN card"},
            {"label": "Date of Birth", "value": "DD/MM/YYYY"},
            {"label": "Aadhaar Number", "value": "XXXX XXXX XXXX",
             "note": "Must be linked to PAN before filing"},
            {"label": "Residential Status", "type": "dropdown", "value": "Resident",
             "options": ["Resident", "Non-Resident", "RNOR"], "highlight": True},
        ], title="Part A — General Information",
           breadcrumb="e-File → Income Tax Returns → File Income Tax Return"),
        "tips": [
            "If your income exceeds ₹50L or you have capital gains, STOP — you need ITR-2",
            "Ensure your Aadhaar is linked to PAN before filing",
        ],
    },
    {
        "page": 2,
        "title": "Filing Status",
        "steps": [
            "Return filed under section: 139(1) — if filing before due date (July 31)",
            "If after due date: 139(4) — belated return (or 139(5) for revised)",
            "Are you opting for new tax regime u/s 115BAC? Select YES or NO",
            "If selecting Old Regime, ensure Form 10-IE is NOT filed (or revoke it)",
        ],
        "mockup": _portal_mockup([
            {"label": "Return filed u/s", "type": "dropdown", "value": "139(1) — Original",
             "options": ["139(1) — Original", "139(4) — Belated", "139(5) — Revised"],
             "note": "Use 139(1) if filing before July 31, 2026"},
            {"label": "New Regime u/s 115BAC?", "type": "dropdown", "value": "No",
             "options": ["No — Old Regime", "Yes — New Regime"],
             "highlight": True,
             "note": "Compare on TaxBuddy's Tax Computation page before choosing"},
        ], title="Filing Status", breadcrumb="ITR-1 → Page 2"),
        "tips": [
            "Old Regime: Allows HRA, LTA, 80C, 80D and all deductions",
            "New Regime: Higher standard deduction (₹75K) but almost no other deductions",
            "Compare both regimes BEFORE selecting — TaxBuddy can help compute both",
        ],
    },
    {
        "page": 3,
        "title": "Income Details — Salary",
        "steps": [
            "Gross Salary: Enter total from all employers (Form 16 Part B, Item 1)",
            "If multiple employers: Add each employer separately with TAN and salary",
            "Exemptions u/s 10: Enter HRA, LTA, Gratuity, Leave Encashment amounts",
            "Standard Deduction: Auto-calculated (₹50K old / ₹75K new)",
            "Professional Tax: Enter from Form 16 or payslip (typically ₹2,400/year)",
        ],
        "mockup": _portal_mockup([
            {"label": "Sec 17(1) — Salary", "value": "From Form 16 Part B",
             "note": "Enter TOTAL from all employers", "highlight": True},
            {"label": "Sec 17(2) — Perquisites", "value": "0"},
            {"label": "Sec 17(3) — Profits in lieu", "value": "0"},
            {"label": "Gross Salary (1+2+3)", "value": "Auto-calculated"},
            {"type": "divider"},
            {"type": "header", "label": "Section 10 — Exempt Allowances"},
            {"label": "HRA u/s 10(13A)", "value": "From TaxBuddy calculation",
             "note": "Fill salary breakup FIRST, then enter HRA exemption"},
            {"label": "LTA u/s 10(5)", "value": "From Form 16"},
            {"type": "divider"},
            {"label": "Standard Deduction", "value": "₹50,000 (Old) / ₹75,000 (New)"},
            {"label": "Professional Tax", "value": "₹2,400",
             "note": "From Form 16 Part B or payslip"},
        ], title="Schedule S — Salary Income", breadcrumb="ITR-1 → Page 3 — Income Details"),
        "common_errors": [
            {
                "error": "HRA exemption rejected — validation error",
                "fix": "Fill salary breakup FIRST (Basic, HRA received), then claim exemption. Portal validates exemption against HRA component in salary.",
            },
            {
                "error": "City shown as Non-Metro when it should be Metro",
                "fix": "Manually change to Metro for Delhi, Mumbai, Kolkata, Chennai, Bangalore, Hyderabad",
            },
        ],
    },
    {
        "page": 4,
        "title": "Income Details — House Property",
        "steps": [
            "If self-occupied: Select 'Self Occupied' — annual value is NIL",
            "If let-out: Enter annual rent received, municipal taxes paid",
            "Home loan interest: Enter under 'Interest on borrowed capital'",
            "Self-occupied: Max ₹2L deduction for home loan interest",
        ],
        "tips": [
            "If you pay rent AND have home loan, you can claim both HRA AND home loan interest",
        ],
    },
    {
        "page": 5,
        "title": "Income Details — Other Sources",
        "steps": [
            "Interest from savings accounts — enter total (claim 80TTA deduction later)",
            "Interest from FDs / RDs — enter total (TDS may already be deducted)",
            "Dividend income — enter total (fully taxable since FY 2020-21)",
            "Any other income not covered above",
        ],
        "tips": [
            "Cross-check interest income with AIS — discrepancies trigger notices",
            "FD interest: Ensure TDS shown matches Form 26AS",
        ],
    },
    {
        "page": 6,
        "title": "Deductions — Chapter VI-A",
        "steps": [
            "80C: Enter total (PF + PPF + ELSS + LIC + etc.) — max ₹1,50,000",
            "80CCD(1B): Additional NPS — max ₹50,000",
            "80CCD(2): Employer NPS contribution (verify from payslip/Form 16)",
            "80D: Health insurance — Self ₹25K + Parents ₹25K/₹50K",
            "80TTA: Savings interest — max ₹10,000",
            "Other deductions: 80E, 80G, 80GG etc. as applicable",
        ],
        "mockup": _portal_mockup([
            {"type": "header", "label": "Section 80C / 80CCC / 80CCD(1)"},
            {"label": "80C Total", "value": "₹1,50,000",
             "note": "EPF + PPF + ELSS + LIC + Tuition — combined max ₹1.5L",
             "highlight": True},
            {"type": "header", "label": "Section 80CCD"},
            {"label": "80CCD(1B) — NPS Self", "value": "₹50,000",
             "note": "Additional ₹50K over 80C limit"},
            {"label": "80CCD(2) — Employer NPS", "value": "From Form 16",
             "note": "Available in BOTH regimes. Max 10% of Basic."},
            {"type": "header", "label": "Section 80D — Health Insurance"},
            {"label": "Self / Family", "value": "₹25,000",
             "note": "₹50K if senior citizen"},
            {"label": "Parents", "value": "₹25,000",
             "note": "₹50K if parents are senior citizens"},
            {"type": "header", "label": "Other Deductions"},
            {"label": "80TTA — Savings Interest", "value": "₹10,000",
             "note": "Auto from AIS savings interest"},
            {"label": "80E — Education Loan", "value": "Interest amount"},
            {"label": "80G — Donations", "value": "50% or 100%"},
        ], title="Schedule VI-A — Deductions", breadcrumb="ITR-1 → Page 6"),
        "common_errors": [
            {
                "error": "80C fields greyed out / not editable",
                "fix": "Delete the auto-populated 80C entry, then re-add fresh. Or toggle 'Edit auto-populated values' if available.",
            },
            {
                "error": "80CCD(2) — employer NPS amount doesn't match Form 16",
                "fix": "Use actual amount from PRAN statement, not Form 16. Ensure it's within 10% of Basic salary limit.",
            },
        ],
    },
    {
        "page": 7,
        "title": "Tax Paid — TDS Verification",
        "steps": [
            "TDS 1 (Salary — Sec 192): Verify each employer's TAN, income, and TDS",
            "TDS 2 (Other — Sec 194A etc.): Verify FD interest TDS",
            "Cross-check ALL entries against Form 26AS / AIS",
            "Advance Tax / Self-Assessment Tax: Enter if any paid",
        ],
        "mockup": _portal_mockup([
            {"type": "header", "label": "Schedule TDS1 — Salary (Sec 192)"},
            {"label": "TAN of Employer", "value": "From Form 16 Part A",
             "highlight": True},
            {"label": "Name of Employer", "value": "Auto from TAN"},
            {"label": "Income under Salary", "value": "Must match Form 16"},
            {"label": "TDS Deducted", "value": "Must match 26AS",
             "note": "Even ₹1 mismatch delays processing"},
            {"type": "header", "label": "Schedule TDS2 — Other (Sec 194A etc.)"},
            {"label": "TAN of Deductor", "value": "Bank TAN"},
            {"label": "Income Amount", "value": "FD/RD Interest"},
            {"label": "TDS Deducted", "value": "Check 26AS"},
        ], title="Tax Paid & Verification", breadcrumb="ITR-1 → Page 7"),
        "tips": [
            "Even ₹1 mismatch in TDS can delay processing",
            "AIS sometimes shows TDS split across multiple entries for same employer — total must match Form 16",
            "Property-related TDS (194IA) as buyer is NOT your credit — it's the seller's",
        ],
    },
    {
        "page": 8,
        "title": "Tax Computation & Verification",
        "steps": [
            "Review auto-computed tax liability",
            "Check if refund or tax payable",
            "If tax payable: Pay via Challan 280 before submitting",
            "Verify bank account details for refund (must be pre-validated)",
        ],
        "tips": [
            "Pre-validate your bank account on the portal BEFORE filing",
            "Refunds go to the primary bank account linked to PAN",
        ],
    },
    {
        "page": 9,
        "title": "Verification & Submission",
        "steps": [
            "Choose verification method: Aadhaar OTP (recommended) / Net Banking / DSC",
            "Review the entire return one more time",
            "Submit and note the acknowledgment number",
            "If Aadhaar OTP: Verify within 30 days",
        ],
        "tips": [
            "Download the ITR-V (acknowledgment) for your records",
            "If e-verification fails, you must send signed ITR-V to CPC Bangalore within 120 days",
        ],
    },
]

ITR2_GUIDE = [
    {
        "page": 1,
        "title": "Personal Information",
        "url": "eportal.incometax.gov.in → e-File → Income Tax Returns → File Income Tax Return",
        "steps": [
            "Select Assessment Year: 2026-27",
            "Select ITR Form: ITR-2",
            "Filing Type: Original",
            "Verify PAN, Name, DOB, Aadhaar",
            "Select Residential Status: Resident / Non-Resident / RNOR",
            "Are you opting for new tax regime u/s 115BAC? Select appropriately",
        ],
        "mockup": _portal_mockup([
            {"label": "Assessment Year", "type": "dropdown", "value": "2026-27", "highlight": True},
            {"label": "ITR Form", "type": "dropdown", "value": "ITR-2",
             "options": ["ITR-1 (Sahaj)", "ITR-2", "ITR-3", "ITR-4"],
             "note": "ITR-2 required if you have capital gains, foreign assets, or income > ₹50L"},
            {"label": "Filing Type", "type": "dropdown", "value": "Original"},
            {"label": "PAN", "value": "XXXXX0000X"},
            {"label": "Full Name", "value": "As per PAN card"},
            {"label": "Aadhaar", "value": "XXXX XXXX XXXX"},
            {"label": "Residential Status", "type": "dropdown", "value": "Resident",
             "options": ["Resident", "Non-Resident", "RNOR"]},
            {"label": "New Regime u/s 115BAC?", "type": "dropdown", "value": "No",
             "options": ["No — Old Regime", "Yes — New Regime"], "highlight": True},
        ], title="Part A — General Information", breadcrumb="ITR-2 → Page 1"),
        "tips": [
            "ITR-2 has MORE pages than ITR-1 — allocate 45-60 minutes",
            "Keep Form 16, AIS, Form 26AS, and MF statement ready",
        ],
        "common_errors": [
            {
                "error": "Secondary address validation error",
                "fix": "Select 'Yes' for 'Is secondary address same as primary address?' in Part A General",
            },
        ],
    },
    {
        "page": 2,
        "title": "Filing Status & Applicability",
        "steps": [
            "Return u/s: 139(1) if before due date",
            "Are you a director in any company? Yes/No",
            "Do you hold unlisted equity shares? Yes/No",
            "Do you have any foreign assets? Yes/No",
            "Have you held any foreign bank account? Yes/No",
        ],
        "tips": [
            "Answer these TRUTHFULLY — false declaration is a serious offence",
            "If you have RSUs/ESOPs from a foreign parent company (e.g., US-listed), foreign assets = YES",
        ],
    },
    {
        "page": 3,
        "title": "Schedule S — Salary Income",
        "steps": [
            "Add each employer separately with Name, TAN, and salary amount",
            "Section 17(1): Salary as per provisions",
            "Section 17(2): Value of perquisites (Form 12BA)",
            "Section 17(3): Profits in lieu of salary",
            "Section 3 — Exemptions u/s 10: Add ONLY what you're claiming",
        ],
        "common_errors": [
            {
                "error": "Zero-value rows in Section 3 causing 'Nature of Exempt Allowance' validation errors",
                "fix": "DELETE all ₹0 rows in Section 3 that don't have a Nature dropdown selected. Keep only entries with actual amounts: Gratuity 10(10), Leave 10(10AA), HRA 10(13A), LTA 10(5)",
            },
            {
                "error": "Gratuity exemption validation error",
                "fix": "Add Gratuity as a SEPARATE salary component under Section 17(1) in the employer details. Portal needs to see gratuity received before it accepts 10(10) exemption.",
            },
            {
                "error": "HRA exemption error — 'Amount exceeds HRA received'",
                "fix": "Enter salary breakup with Basic and HRA as separate components in employer details BEFORE claiming HRA exemption in Section 3",
            },
            {
                "error": "Driver/Vehicle/Fuel allowance rejected under 10(14)(i)",
                "fix": "These are Rule 3(2) car perquisite items, not genuinely exempt under 10(14)(i) for private sector. Either skip this claim or check if total income is safely below ₹50L without it.",
            },
        ],
        "important_lesson": (
            "When switching jobs mid-year: if you were on New Regime at previous employer, "
            "exemptions not claimed there (HRA, LTA) CAN be claimed in ITR if filing under Old Regime. "
            "Consolidate salary from both employers carefully."
        ),
    },
    {
        "page": 4,
        "title": "Schedule HP — House Property",
        "steps": [
            "Same as ITR-1 house property section",
            "ITR-2 supports multiple house properties",
        ],
    },
    {
        "page": 5,
        "title": "Schedule CG — Capital Gains",
        "steps": [
            "STCG u/s 111A: Enter sale consideration, cost of acquisition, and gain for listed equity/equity MF",
            "LTCG u/s 112A: Enter same for long-term equity gains",
            "LTCG exemption: ₹1,25,000 auto-applied",
            "Table F: Enter PERIOD-WISE breakup of capital gains",
        ],
        "mockup": _portal_mockup([
            {"type": "header", "label": "A — Short Term Capital Gains (STCG)"},
            {"label": "Sec 111A — Listed Equity/MF", "value": "₹ from MF Report",
             "note": "Tax @ 20%", "highlight": True},
            {"type": "header", "label": "B — Long Term Capital Gains (LTCG)"},
            {"label": "Sec 112A — Listed Equity/MF", "value": "₹ from MF Report",
             "note": "Tax @ 12.5% after ₹1.25L exemption", "highlight": True},
            {"label": "Exemption u/s 112A", "value": "₹1,25,000 (auto)"},
            {"type": "header", "label": "Table F — Period-wise Breakup"},
            {"label": "(i) Up to 15 Jun", "value": "₹"},
            {"label": "(ii) 16 Jun – 15 Sep", "value": "₹"},
            {"label": "(iii) 16 Sep – 15 Dec", "value": "₹"},
            {"label": "(iv) 16 Dec – 15 Mar", "value": "₹"},
            {"label": "(v) 16 Mar – 31 Mar", "value": "₹",
             "note": "Sum must EXACTLY match BFLA item 3iii"},
        ], title="Schedule CG — Capital Gains", breadcrumb="ITR-2 → Page 5"),
        "common_errors": [
            {
                "error": "Table F breakup doesn't match Schedule BFLA item 3iii",
                "fix": "Table F uses SPECIFIC date ranges, NOT calendar quarters: (i) Up to 15/6, (ii) 16/6 to 15/9, (iii) 16/9 to 15/12, (iv) 16/12 to 15/3, (v) 16/3 to 31/3. Sum must EXACTLY match BFLA total — adjust rounding if needed.",
            },
        ],
        "important_lesson": (
            "Use the exact redemption dates from your MF capital gains report to categorize "
            "gains into Table F periods. Even ₹1 mismatch causes a validation error. "
            "TaxBuddy auto-computes this breakup from your MF transaction sheet."
        ),
    },
    {
        "page": 6,
        "title": "Schedule OS — Other Sources",
        "steps": [
            "Interest from savings / FD / RD",
            "Dividend income",
            "Any other income",
        ],
    },
    {
        "page": 7,
        "title": "Schedule VI-A — Deductions",
        "steps": [
            "Same deductions as ITR-1 (80C, 80D, etc.)",
            "80CCD(2): Employer NPS — verify from PRAN statement",
            "80DDB: Medical treatment for specified disease (self/dependent)",
            "80DD: Maintenance of disabled dependent — requires Form 10-IA or UDID number",
        ],
        "common_errors": [
            {
                "error": "80DD requires Form 10-IA acknowledgment or UDID number",
                "fix": "You MUST have either Form 10-IA certificate filed with IT dept OR a valid UDID card. Cannot claim 80DD without documentation.",
            },
            {
                "error": "80C fields greyed out",
                "fix": "Same fix as ITR-1: delete and re-add, or look for 'Edit auto-populated values' toggle",
            },
        ],
    },
    {
        "page": 8,
        "title": "Schedule BFLA — Brought Forward Losses & Set-Off",
        "steps": [
            "Auto-populated based on CG and other income entries",
            "Verify STCG and LTCG amounts match your entries",
            "BFLA adjusts capital gains against any brought-forward losses",
        ],
    },
    {
        "page": 9,
        "title": "Schedule AMT — Alternative Minimum Tax",
        "steps": [
            "Usually ₹0 for salaried individuals",
            "Click Confirm if AMT is not applicable",
        ],
    },
    {
        "page": 10,
        "title": "Tax Paid — TDS/TCS/Advance Tax",
        "steps": [
            "TDS 1 (Sec 192 — Salary): Verify each employer",
            "TDS 2 (Other sections): Verify FD interest TDS, etc.",
            "TCS: Usually empty for salaried individuals",
            "Advance Tax / Self-Assessment Tax: Enter challan details if paid",
        ],
        "tips": [
            "Property TDS (194IA) as a buyer is NOT your credit",
            "AIS may split employer TDS into multiple entries — total must match Form 16",
        ],
    },
    {
        "page": 11,
        "title": "Tax Computation & Summary",
        "steps": [
            "Review auto-computed total income",
            "Verify tax liability computation",
            "Check surcharge: 10% applies if total income > ₹50L",
            "Check refund amount or tax payable",
        ],
        "tips": [
            "If total income is just above ₹50L, go back and maximize deductions to drop below",
            "Even ₹1 above ₹50L triggers 10% surcharge on ENTIRE tax — this can mean ₹2-3L extra tax",
            "Marginal relief may apply but still worth optimizing",
        ],
        "important_lesson": (
            "The ₹50L surcharge threshold is the MOST IMPORTANT number for high-income salaried "
            "individuals. If you're within ₹2-3L of ₹50L, aggressively use: HRA (maximize rent), "
            "80CCD(1B) (₹50K NPS), 80CCD(2) (employer NPS), 80D (₹75K health), 80DDB (₹1L senior "
            "citizen), LTA, and any other legitimate deduction to bring income below ₹50L."
        ),
    },
    {
        "page": 12,
        "title": "Verification & Submission",
        "steps": [
            "Verify all schedules one final time",
            "Select verification method: Aadhaar OTP recommended",
            "Submit the return",
            "Download ITR-V acknowledgment",
            "Note acknowledgment number for reference",
        ],
    },
]


def get_guide(itr_form: str) -> list[dict]:
    """Get the filing guide for the specified ITR form."""
    if itr_form.upper() in ("ITR-1", "ITR1", "SAHAJ"):
        return ITR1_GUIDE
    return ITR2_GUIDE


def get_page_guide(itr_form: str, page_number: int):
    """Get guide for a specific page."""
    guide = get_guide(itr_form)
    for page in guide:
        if page["page"] == page_number:
            return page
    return None


def get_common_errors(itr_form: str) -> list[dict]:
    """Get all common errors and fixes for an ITR form."""
    guide = get_guide(itr_form)
    errors = []
    for page in guide:
        for err in page.get("common_errors", []):
            errors.append({
                "page": page["page"],
                "title": page["title"],
                **err,
            })
    return errors
