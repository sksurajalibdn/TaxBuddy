"""
Portal Pre-fill Engine — generates exact values the user must enter
on the Income Tax e-Filing Portal, section by section.

Works for both ITR-1 and ITR-2.  Every value comes from the parsed
documents and tax computations done on earlier screens.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PortalField:
    label: str
    value: str
    portal_path: str = ""
    note: str = ""
    highlight: bool = False


@dataclass
class PortalSection:
    id: str
    title: str
    icon: str
    fields: list[PortalField] = field(default_factory=list)
    sub_sections: list = field(default_factory=list)


def _fmt(v: float) -> str:
    if v == 0:
        return "0"
    return f"{v:,.0f}"


def _fmtv(v: float) -> str:
    """Format for portal — no commas, just rounded int as portals expect."""
    return str(round(v))


# ─── Schedule applicability (which checkboxes to tick) ───────────

def get_applicable_schedules(taxpayer, regime_data: dict, itr_form: str) -> list[dict]:
    """
    Determine which schedules / sub-sections the user must SELECT
    (tick the checkbox) on the IT portal based on their data.

    Returns list of {schedule, select, reason}.
    """
    tp = taxpayer
    sal = regime_data.get("salary", {})
    cg = regime_data.get("capital_gains", {})
    ded = regime_data.get("deductions", {})
    is_itr2 = "2" in itr_form

    schedules = []

    schedules.append({
        "schedule": "Part A — General Information",
        "select": True,
        "reason": "Always required — personal details, PAN, Aadhaar.",
    })

    schedules.append({
        "schedule": "Schedule S — Salary",
        "select": sal.get("gross_salary", 0) > 0,
        "reason": f"Salary income detected: ₹{_fmt(sal.get('gross_salary', 0))}",
    })

    has_hp = tp.other_income.rental_income > 0
    schedules.append({
        "schedule": "Schedule HP — House Property",
        "select": has_hp,
        "reason": "Rental income detected" if has_hp else "No house property income — skip.",
    })

    if is_itr2:
        has_cg = (cg.get("stcg_111a", 0) > 0 or cg.get("ltcg_112a", 0) > 0
                  or cg.get("stcg_other", 0) > 0 or cg.get("ltcg_112", 0) > 0)
        schedules.append({
            "schedule": "Schedule CG — Capital Gains",
            "select": has_cg,
            "reason": f"Capital gains detected — STCG: ₹{_fmt(cg.get('stcg_111a', 0))}, LTCG: ₹{_fmt(cg.get('ltcg_112a', 0))}" if has_cg else "No capital gains — skip.",
        })

    has_os = tp.other_income.total > 0
    schedules.append({
        "schedule": "Schedule OS — Other Sources",
        "select": has_os,
        "reason": f"Other income detected: ₹{_fmt(tp.other_income.total)}" if has_os else "No other income — skip.",
    })

    regime = regime_data.get("regime", "old")
    has_via = regime_data.get("total_deductions", 0) > 0

    if regime == "old":
        schedules.append({
            "schedule": "Schedule VI-A — Deductions (Chapter VI-A)",
            "select": True,
            "reason": f"Total deductions: ₹{_fmt(regime_data.get('total_deductions', 0))}. Select ALL that apply below.",
        })

        ded_checks = [
            ("80C / 80CCC / 80CCD(1)", tp.deductions.sec_80c_total > 0,
             f"EPF/PPF/ELSS: ₹{_fmt(tp.deductions.sec_80c_total)}"),
            ("80CCD(1B) — Additional NPS", tp.deductions.sec_80ccd_1b > 0,
             f"NPS: ₹{_fmt(tp.deductions.sec_80ccd_1b)}"),
            ("80CCD(2) — Employer NPS", tp.deductions.sec_80ccd_2 > 0,
             f"Employer NPS: ₹{_fmt(tp.deductions.sec_80ccd_2)}"),
            ("80D — Health Insurance", (tp.deductions.sec_80d_self + tp.deductions.sec_80d_parents) > 0,
             f"Self: ₹{_fmt(tp.deductions.sec_80d_self)}, Parents: ₹{_fmt(tp.deductions.sec_80d_parents)}"),
            ("80DD — Disabled Dependent", tp.deductions.sec_80dd > 0,
             f"₹{_fmt(tp.deductions.sec_80dd)}"),
            ("80DDB — Medical Treatment", tp.deductions.sec_80ddb > 0,
             f"₹{_fmt(tp.deductions.sec_80ddb)}"),
            ("80E — Education Loan Interest", tp.deductions.sec_80e > 0,
             f"₹{_fmt(tp.deductions.sec_80e)}"),
            ("80G — Donations", tp.deductions.sec_80g > 0,
             f"₹{_fmt(tp.deductions.sec_80g)}"),
            ("80GG — Rent (no HRA component)", tp.deductions.sec_80gg > 0,
             f"₹{_fmt(tp.deductions.sec_80gg)}"),
            ("80TTA — Savings Interest", tp.deductions.sec_80tta > 0,
             f"₹{_fmt(tp.deductions.sec_80tta)} (max ₹10,000)"),
            ("80U — Self Disability", tp.deductions.sec_80u > 0,
             f"₹{_fmt(tp.deductions.sec_80u)}"),
        ]
        for name, applicable, detail in ded_checks:
            schedules.append({
                "schedule": f"  ↳ {name}",
                "select": applicable,
                "reason": detail if applicable else "Not applicable — skip.",
                "indent": True,
            })
    else:
        schedules.append({
            "schedule": "Schedule VI-A — Deductions",
            "select": tp.deductions.sec_80ccd_2 > 0,
            "reason": "New Regime: only 80CCD(2) employer NPS is allowed." if tp.deductions.sec_80ccd_2 > 0 else "New Regime: no deductions applicable — skip.",
        })

    schedules.append({
        "schedule": "Schedule TDS1 — Salary TDS (Sec 192)",
        "select": tp.total_tds > 0,
        "reason": f"{len(tp.employers)} employer(s), total TDS: ₹{_fmt(tp.total_tds)}",
    })

    has_other_tds = len(tp.tds_entries) > 0
    schedules.append({
        "schedule": "Schedule TDS2 — Other TDS (Sec 194A etc.)",
        "select": has_other_tds,
        "reason": f"{len(tp.tds_entries)} TDS entries from banks/others" if has_other_tds else "No other TDS — skip.",
    })

    if is_itr2:
        schedules.append({
            "schedule": "Schedule BFLA — Set-off of Losses",
            "select": (cg.get("stcg_111a", 0) > 0 or cg.get("ltcg_112a", 0) > 0),
            "reason": "Auto-populated from Schedule CG." if (cg.get("stcg_111a", 0) > 0 or cg.get("ltcg_112a", 0) > 0) else "No losses to set off — skip.",
        })
        schedules.append({
            "schedule": "Schedule AMT — Alternative Minimum Tax",
            "select": False,
            "reason": "Usually ₹0 for salaried individuals. Confirm & skip.",
        })
        schedules.append({
            "schedule": "Schedule FA — Foreign Assets",
            "select": tp.has_foreign_assets,
            "reason": "Foreign assets/income detected — must declare." if tp.has_foreign_assets else "No foreign assets — skip.",
        })
        schedules.append({
            "schedule": "Schedule 112A — LTCG on Listed Securities",
            "select": cg.get("ltcg_112a", 0) > 0,
            "reason": f"LTCG 112A: ₹{_fmt(cg.get('ltcg_112a', 0))}" if cg.get("ltcg_112a", 0) > 0 else "No LTCG — skip.",
        })
        schedules.append({
            "schedule": "Schedule 115AD — Non-Resident / FPI",
            "select": False,
            "reason": "Not applicable for resident individuals.",
        })

    return schedules


# ─── Pre-filled portal values ────────────────────────────────────

def generate_prefill_values(taxpayer, regime_data: dict, itr_form: str) -> list[PortalSection]:
    """
    Generate exact values to copy-paste into each portal field.

    Uses the computed regime_data (from compare_regimes) and the
    taxpayer model to produce section-wise, field-by-field values.
    """
    tp = taxpayer
    sal = regime_data.get("salary", {})
    cg = regime_data.get("capital_gains", {})
    tax = regime_data.get("tax_computation", {})
    is_itr2 = "2" in itr_form
    regime = regime_data.get("regime", "old")

    sections = []

    # ── 1. Personal Information ──
    sections.append(PortalSection(
        id="personal",
        title="Part A — General Information",
        icon="👤",
        fields=[
            PortalField("Assessment Year", "2026-27", note="Select from dropdown"),
            PortalField("ITR Form", itr_form, note="Select from dropdown"),
            PortalField("PAN", tp.pan or "Auto-filled from login", highlight=True),
            PortalField("Name", tp.name or "As per PAN card"),
            PortalField("Date of Birth", tp.dob or "DD/MM/YYYY"),
            PortalField("Aadhaar", tp.aadhaar or "XXXX XXXX XXXX"),
            PortalField("Residential Status", "Resident"),
        ],
    ))

    # ── 2. Filing Status ──
    regime_label = "No — Old Regime" if regime == "old" else "Yes — New Regime"
    sections.append(PortalSection(
        id="filing_status",
        title="Filing Status",
        icon="📋",
        fields=[
            PortalField("Return filed u/s", "139(1) — Original",
                         note="Use 139(1) if filing before July 31, 2026"),
            PortalField("New Tax Regime u/s 115BAC?", regime_label, highlight=True,
                         note="Based on TaxBuddy's recommendation"),
        ],
    ))

    # ── 3. Schedule S — Salary ──
    sec10 = sal.get("sec10_exemptions", {})
    sec16 = sal.get("sec16_deductions", {})
    emp_fields = []
    for i, emp in enumerate(tp.employers):
        prefix = f"Employer {i+1}" if len(tp.employers) > 1 else "Employer"
        emp_fields.extend([
            PortalField(f"{prefix} — Name", emp.name or "N/A"),
            PortalField(f"{prefix} — TAN", emp.tan or "N/A", highlight=True),
            PortalField(f"{prefix} — Sec 17(1) Salary",
                         _fmtv(emp.gross_salary),
                         note="From Form 16 Part B"),
            PortalField(f"{prefix} — Sec 17(2) Perquisites",
                         _fmtv(emp.perquisites_value)),
            PortalField(f"{prefix} — Sec 17(3) Profits in lieu", "0"),
        ])

    salary_fields = emp_fields + [
        PortalField("Gross Salary (total)", _fmtv(sal.get("gross_salary", 0)),
                     highlight=True, note="Sum of all employers"),
    ]

    if regime == "old":
        salary_fields.extend([
            PortalField("HRA Exemption u/s 10(13A)",
                         _fmtv(sec10.get("hra_10_13a", 0)),
                         note="Fill salary breakup (Basic, HRA) FIRST, then this"),
            PortalField("LTA u/s 10(5)", _fmtv(sec10.get("lta_10_5", 0))),
            PortalField("Gratuity u/s 10(10)", _fmtv(sec10.get("gratuity_10_10", 0))),
            PortalField("Leave Encashment u/s 10(10AA)",
                         _fmtv(sec10.get("leave_encash_10_10aa", 0))),
            PortalField("Total Sec 10 Exemptions", _fmtv(sec10.get("total", 0)),
                         highlight=True),
        ])

    salary_fields.extend([
        PortalField("Standard Deduction u/s 16(ia)",
                     _fmtv(sec16.get("standard_deduction", 0)),
                     note=f"{'₹75,000 (New)' if regime == 'new' else '₹50,000 (Old)'}"),
        PortalField("Professional Tax u/s 16(iii)",
                     _fmtv(sec16.get("professional_tax", 0))),
        PortalField("Income under head Salary",
                     _fmtv(sal.get("salary_income", 0)),
                     highlight=True, note="Auto-calculated on portal"),
    ])

    sections.append(PortalSection(
        id="salary", title="Schedule S — Salary Income", icon="💰",
        fields=salary_fields,
    ))

    # ── 4. Schedule OS — Other Sources ──
    oi = tp.other_income
    if oi.total > 0:
        os_fields = []
        if oi.interest_savings > 0:
            os_fields.append(PortalField("Interest from Savings Account",
                                          _fmtv(oi.interest_savings),
                                          note="From AIS — claim 80TTA deduction"))
        if oi.interest_fd > 0:
            os_fields.append(PortalField("Interest from Deposits (FD/RD)",
                                          _fmtv(oi.interest_fd),
                                          note="Taxable at slab rate. TDS may be deducted."))
        if oi.interest_other > 0:
            os_fields.append(PortalField("Interest — Other",
                                          _fmtv(oi.interest_other)))
        if oi.dividend > 0:
            os_fields.append(PortalField("Dividend Income",
                                          _fmtv(oi.dividend),
                                          note="Fully taxable since FY 2020-21"))
        if oi.other > 0:
            os_fields.append(PortalField("Any Other Income",
                                          _fmtv(oi.other)))
        os_fields.append(PortalField("Total Other Sources",
                                      _fmtv(oi.total), highlight=True))
        sections.append(PortalSection(
            id="other_sources", title="Schedule OS — Other Sources", icon="🏦",
            fields=os_fields,
        ))

    # ── 5. Schedule CG — Capital Gains (ITR-2 only) ──
    if is_itr2 and cg.get("total", 0) > 0:
        cg_fields = []

        if cg.get("stcg_111a", 0) > 0:
            cg_fields.extend([
                PortalField("STCG u/s 111A — Listed Equity/MF",
                             _fmtv(cg["stcg_111a"]),
                             highlight=True, note="Tax @ 20%"),
            ])

        if cg.get("stcg_other", 0) > 0:
            cg_fields.append(PortalField("STCG — Other (slab rate)",
                                          _fmtv(cg["stcg_other"])))

        if cg.get("ltcg_112a", 0) > 0:
            cg_fields.extend([
                PortalField("LTCG u/s 112A — Listed Equity/MF (Full)",
                             _fmtv(cg["ltcg_112a"]),
                             highlight=True, note="Tax @ 12.5% after ₹1.25L exemption"),
                PortalField("Exemption u/s 112A",
                             _fmtv(cg.get("ltcg_112a_exempt", 125000)),
                             note="Auto-applied: ₹1,25,000"),
                PortalField("LTCG Taxable (after exemption)",
                             _fmtv(cg.get("ltcg_taxable", 0)),
                             highlight=True),
            ])

        if cg.get("ltcg_112", 0) > 0:
            cg_fields.append(PortalField("LTCG u/s 112 — Other",
                                          _fmtv(cg["ltcg_112"])))

        # Table F — Period-wise breakup
        q_stcg = cg.get("quarterly_stcg", {})
        q_ltcg = cg.get("quarterly_ltcg", {})
        periods = [
            ("q1", "(i) Up to 15 Jun"),
            ("q2", "(ii) 16 Jun – 15 Sep"),
            ("q3", "(iii) 16 Sep – 15 Dec"),
            ("q4", "(iv) 16 Dec – 15 Mar"),
            ("q5", "(v) 16 Mar – 31 Mar"),
        ]
        has_quarterly = any(q_stcg.get(k, 0) > 0 or q_ltcg.get(k, 0) > 0 for k, _ in periods)
        if has_quarterly:
            cg_fields.append(PortalField("── Table F: STCG Period Breakup ──", "",
                                          note="Sum must match Schedule BFLA"))
            for k, label in periods:
                v = q_stcg.get(k, 0)
                cg_fields.append(PortalField(f"  STCG {label}", _fmtv(v)))

            cg_fields.append(PortalField("── Table F: LTCG Period Breakup ──", "",
                                          note="Sum must match Schedule BFLA"))
            for k, label in periods:
                v = q_ltcg.get(k, 0)
                cg_fields.append(PortalField(f"  LTCG {label}", _fmtv(v)))

        sections.append(PortalSection(
            id="capital_gains", title="Schedule CG — Capital Gains", icon="📈",
            fields=cg_fields,
        ))

    # ── 6. Schedule VI-A — Deductions ──
    ded = tp.deductions
    via_fields = []

    if regime == "old":
        if ded.sec_80c_total > 0:
            via_fields.append(PortalField("80C / 80CCC / 80CCD(1)",
                                           _fmtv(ded.sec_80c_total),
                                           highlight=True,
                                           note=f"EPF + PPF + ELSS + LIC (max ₹1,50,000)"))
        if ded.sec_80ccd_1b > 0:
            via_fields.append(PortalField("80CCD(1B) — Additional NPS",
                                           _fmtv(ded.sec_80ccd_1b),
                                           note="Additional ₹50K beyond 80C"))
        if ded.sec_80ccd_2 > 0:
            via_fields.append(PortalField("80CCD(2) — Employer NPS",
                                           _fmtv(ded.sec_80ccd_2),
                                           highlight=True,
                                           note="Available in BOTH regimes"))
        if ded.sec_80d_self > 0:
            via_fields.append(PortalField("80D — Self/Family Health Insurance",
                                           _fmtv(ded.sec_80d_self)))
        if ded.sec_80d_parents > 0:
            via_fields.append(PortalField("80D — Parents Health Insurance",
                                           _fmtv(ded.sec_80d_parents)))
        if ded.sec_80dd > 0:
            via_fields.append(PortalField("80DD — Disabled Dependent",
                                           _fmtv(ded.sec_80dd),
                                           note="Needs Form 10-IA or UDID"))
        if ded.sec_80ddb > 0:
            via_fields.append(PortalField("80DDB — Medical Treatment",
                                           _fmtv(ded.sec_80ddb),
                                           note="Needs Form 10-I from specialist"))
        if ded.sec_80e > 0:
            via_fields.append(PortalField("80E — Education Loan Interest",
                                           _fmtv(ded.sec_80e)))
        if ded.sec_80g > 0:
            via_fields.append(PortalField("80G — Donations",
                                           _fmtv(ded.sec_80g),
                                           note="Keep receipts with donee PAN"))
        if ded.sec_80gg > 0:
            via_fields.append(PortalField("80GG — Rent (no HRA)",
                                           _fmtv(ded.sec_80gg)))
        if ded.sec_80tta > 0:
            via_fields.append(PortalField("80TTA — Savings Interest Deduction",
                                           _fmtv(ded.sec_80tta),
                                           note="Max ₹10,000 — auto from AIS"))
        if ded.sec_80u > 0:
            via_fields.append(PortalField("80U — Self Disability",
                                           _fmtv(ded.sec_80u)))

        via_fields.append(PortalField("Total Chapter VI-A Deductions",
                                       _fmtv(regime_data.get("total_deductions", 0)),
                                       highlight=True))
    else:
        if ded.sec_80ccd_2 > 0:
            via_fields.append(PortalField("80CCD(2) — Employer NPS",
                                           _fmtv(ded.sec_80ccd_2),
                                           highlight=True,
                                           note="Only deduction allowed under New Regime"))
            via_fields.append(PortalField("Total Chapter VI-A",
                                           _fmtv(ded.sec_80ccd_2)))
        else:
            via_fields.append(PortalField("No deductions under New Regime", "0",
                                           note="New regime: skip this section"))

    sections.append(PortalSection(
        id="deductions", title="Schedule VI-A — Deductions", icon="🛡️",
        fields=via_fields,
    ))

    # ── 7. Schedule TDS1 — Salary TDS ──
    tds1_fields = []
    for i, emp in enumerate(tp.employers):
        prefix = f"Employer {i+1}" if len(tp.employers) > 1 else "Employer"
        tds1_fields.extend([
            PortalField(f"{prefix} — TAN", emp.tan or "N/A", highlight=True),
            PortalField(f"{prefix} — Name of Deductor", emp.name or "N/A"),
            PortalField(f"{prefix} — Income under Salary",
                         _fmtv(emp.gross_salary),
                         note="Must match Form 16"),
            PortalField(f"{prefix} — TDS Deducted",
                         _fmtv(emp.tds_deducted),
                         highlight=True, note="Must match Form 26AS exactly"),
        ])
    sections.append(PortalSection(
        id="tds1", title="Schedule TDS1 — Salary TDS (Sec 192)", icon="🏛️",
        fields=tds1_fields,
    ))

    # ── 8. Schedule TDS2 — Other TDS ──
    if tp.tds_entries:
        tds2_fields = []
        for i, entry in enumerate(tp.tds_entries):
            prefix = f"Entry {i+1}" if len(tp.tds_entries) > 1 else "Entry"
            tds2_fields.extend([
                PortalField(f"{prefix} — TAN", entry.tan or "N/A"),
                PortalField(f"{prefix} — Deductor", entry.deductor_name or "N/A"),
                PortalField(f"{prefix} — Income", _fmtv(entry.income_credited)),
                PortalField(f"{prefix} — TDS Deducted", _fmtv(entry.tds_deducted),
                             highlight=True),
                PortalField(f"{prefix} — Section", entry.section or "194A"),
            ])
        sections.append(PortalSection(
            id="tds2", title="Schedule TDS2 — Other TDS", icon="🏦",
            fields=tds2_fields,
        ))

    # ── 9. Tax Computation Summary ──
    tc_fields = [
        PortalField("Gross Total Income",
                     _fmtv(regime_data.get("gross_total_income", 0)), highlight=True),
        PortalField("Total Deductions",
                     _fmtv(regime_data.get("total_deductions", 0))),
        PortalField("Total Taxable Income",
                     _fmtv(regime_data.get("taxable_income", 0)), highlight=True),
        PortalField("Tax on Normal Income",
                     _fmtv(tax.get("tax_on_normal", 0))),
    ]
    if tax.get("tax_on_stcg_111a", 0) > 0:
        tc_fields.append(PortalField("Tax on STCG 111A @ 20%",
                                      _fmtv(tax["tax_on_stcg_111a"])))
    if tax.get("tax_on_ltcg_112a", 0) > 0:
        tc_fields.append(PortalField("Tax on LTCG 112A @ 12.5%",
                                      _fmtv(tax["tax_on_ltcg_112a"])))
    if tax.get("surcharge", 0) > 0:
        tc_fields.append(PortalField("Surcharge",
                                      _fmtv(tax["surcharge"])))
    tc_fields.extend([
        PortalField("Health & Education Cess @ 4%",
                     _fmtv(tax.get("cess", 0))),
        PortalField("Total Tax Liability",
                     _fmtv(tax.get("total_tax", 0)), highlight=True),
        PortalField("Total TDS Already Paid",
                     _fmtv(regime_data.get("total_tds", 0))),
    ])

    payable = regime_data.get("tax_payable", 0)
    is_refund = regime_data.get("is_refund", False)
    if is_refund:
        tc_fields.append(PortalField("REFUND DUE", _fmtv(payable),
                                      highlight=True, note="Will be credited to pre-validated bank account"))
    else:
        tc_fields.append(PortalField("Tax Payable (Self-Assessment)",
                                      _fmtv(payable),
                                      highlight=True,
                                      note="Pay via Challan 280 BEFORE submitting"))

    sections.append(PortalSection(
        id="tax_summary", title="Tax Computation — Summary", icon="🧮",
        fields=tc_fields,
    ))

    # ── 10. Verification ──
    sections.append(PortalSection(
        id="verification", title="Verification & Submission", icon="✅",
        fields=[
            PortalField("Verification Method", "Aadhaar OTP (Recommended)",
                         note="Fastest — OTP sent to Aadhaar-linked mobile"),
            PortalField("Bank Account for Refund", "Pre-validated account linked to PAN",
                         note="Pre-validate on portal BEFORE filing"),
        ],
    ))

    return sections
