"""
TaxBuddy CLI — Interactive Income Tax Filing Assistant.

A terminal-based conversational agent that guides users through
Indian Income Tax filing for ITR-1 and ITR-2.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt, Confirm
from rich.markdown import Markdown
from rich.text import Text
from rich.rule import Rule
from rich import box

from taxbuddy.models.taxpayer import (
    TaxPayer, EmployerInfo, HRADetails, City,
    Deductions, OtherIncome, CapitalGains,
    TaxRegime, ResidentialStatus, METRO_CITIES,
)
from taxbuddy.engine.itr_selector import select_itr_form, get_itr_selection_questions
from taxbuddy.engine.salary import compute_hra_exemption, compute_salary_income
from taxbuddy.engine.tax_calculator import compute_total_income, compare_regimes
from taxbuddy.knowledge.rules import PORTAL_LESSONS, MULTIPLE_EMPLOYER_RULES
from taxbuddy.knowledge.itr_guide import DOCUMENTS_CHECKLIST, PRE_FILING_CHECKLIST
from taxbuddy.guides.itr_filing_guide import get_guide, get_common_errors


console = Console()
taxpayer = TaxPayer()


def banner():
    console.print()
    console.print(Panel.fit(
        "[bold cyan]TaxBuddy v1.0[/bold cyan]\n"
        "[dim]Your AI-powered Indian Income Tax Filing Assistant[/dim]\n"
        "[dim]Supports ITR-1 (Sahaj) & ITR-2 | FY 2025-26 (AY 2026-27)[/dim]\n\n"
        "[yellow]Disclaimer:[/yellow] TaxBuddy assists with tax computation and filing guidance.\n"
        "It is NOT a substitute for professional CA advice. Always verify computations\n"
        "against official IT portal values. All references cite the Income Tax Act, 1961\n"
        "and CBDT notifications — no assumptions are made.",
        title="[bold green]Welcome to TaxBuddy[/bold green]",
        border_style="green",
    ))
    console.print()


def show_documents_checklist():
    console.print(Rule("[bold]Documents Checklist[/bold]"))

    table = Table(title="Essential Documents", box=box.ROUNDED, show_lines=True)
    table.add_column("Document", style="bold cyan", width=30)
    table.add_column("Description", width=50)
    table.add_column("Where to Get", width=35)

    for doc in DOCUMENTS_CHECKLIST["essential"]:
        table.add_row(doc["name"], doc["description"], doc["where_to_get"])
    console.print(table)

    table2 = Table(title="If Applicable", box=box.ROUNDED, show_lines=True)
    table2.add_column("Document", style="bold yellow", width=30)
    table2.add_column("Description", width=50)
    table2.add_column("Where to Get", width=35)

    for doc in DOCUMENTS_CHECKLIST["if_applicable"]:
        table2.add_row(doc["name"], doc["description"], doc["where_to_get"])
    console.print(table2)


def show_pre_filing_checklist():
    console.print(Rule("[bold]Pre-Filing Checklist[/bold]"))
    for i, item in enumerate(PRE_FILING_CHECKLIST, 1):
        console.print(f"  [cyan]{i:2d}.[/cyan] {item}")
    console.print()


def upload_documents():
    """Guide user to provide document paths for parsing."""
    console.print(Rule("[bold]Upload Documents[/bold]"))
    console.print(
        "[dim]Provide file paths to your tax documents. "
        "TaxBuddy will parse and extract relevant data.[/dim]\n"
    )

    documents = {}

    # Form 16
    console.print("[bold cyan]1. Form 16[/bold cyan] (PDF from employer)")
    form16_paths = []
    while True:
        path = Prompt.ask(
            "  Enter Form 16 path (or 'skip' / 'done')",
            default="skip"
        )
        if path.lower() in ("skip", "done", "s", "d", ""):
            break
        path = os.path.expanduser(path.strip().strip("'\""))
        if Path(path).exists():
            form16_paths.append(path)
            console.print(f"  [green]Added:[/green] {Path(path).name}")
            if Confirm.ask("  Add another Form 16 (multiple employers)?", default=False):
                continue
            break
        else:
            console.print(f"  [red]File not found:[/red] {path}")

    if form16_paths:
        documents["form16"] = form16_paths
        _parse_form16_files(form16_paths)

    # AIS
    console.print("\n[bold cyan]2. AIS (Annual Information Statement)[/bold cyan] (PDF)")
    ais_path = Prompt.ask("  Enter AIS path (or 'skip')", default="skip")
    if ais_path.lower() not in ("skip", "s", ""):
        ais_path = os.path.expanduser(ais_path.strip().strip("'\""))
        if Path(ais_path).exists():
            documents["ais"] = ais_path
            _parse_ais_file(ais_path)
        else:
            console.print(f"  [red]File not found:[/red] {ais_path}")

    # Form 26AS
    console.print("\n[bold cyan]3. Form 26AS[/bold cyan] (PDF)")
    f26_path = Prompt.ask("  Enter Form 26AS path (or 'skip')", default="skip")
    if f26_path.lower() not in ("skip", "s", ""):
        f26_path = os.path.expanduser(f26_path.strip().strip("'\""))
        if Path(f26_path).exists():
            documents["form26as"] = f26_path
            _parse_form26as_file(f26_path)
        else:
            console.print(f"  [red]File not found:[/red] {f26_path}")

    # Mutual Fund Statement
    console.print("\n[bold cyan]4. Mutual Fund Capital Gains Report[/bold cyan] (Excel .xlsx)")
    mf_path = Prompt.ask("  Enter MF report path (or 'skip')", default="skip")
    if mf_path.lower() not in ("skip", "s", ""):
        mf_path = os.path.expanduser(mf_path.strip().strip("'\""))
        if Path(mf_path).exists():
            documents["mutual_funds"] = mf_path
            _parse_mf_file(mf_path)
        else:
            console.print(f"  [red]File not found:[/red] {mf_path}")

    # Payslip (optional)
    console.print("\n[bold cyan]5. Payslip[/bold cyan] (PDF — optional, for detailed salary breakup)")
    ps_path = Prompt.ask("  Enter payslip path (or 'skip')", default="skip")
    if ps_path.lower() not in ("skip", "s", ""):
        ps_path = os.path.expanduser(ps_path.strip().strip("'\""))
        if Path(ps_path).exists():
            documents["payslip"] = ps_path
            _parse_payslip_file(ps_path)
        else:
            console.print(f"  [red]File not found:[/red] {ps_path}")

    return documents


def _parse_form16_files(paths: list[str]):
    """Parse Form 16 files and populate taxpayer data."""
    from taxbuddy.parsers.form16 import parse_form16

    for path in paths:
        try:
            console.print(f"\n  [dim]Parsing {Path(path).name}...[/dim]")
            emp = parse_form16(path)
            if emp:
                taxpayer.employers.append(emp)
                console.print(f"  [green]Parsed:[/green] {emp.name or 'Employer'} — "
                              f"Gross: ₹{emp.gross_salary:,.0f}, TDS: ₹{emp.tds_deducted:,.0f}")
        except Exception as e:
            console.print(f"  [red]Error parsing {Path(path).name}:[/red] {e}")
            console.print("  [yellow]You can enter salary details manually later.[/yellow]")


def _parse_ais_file(path: str):
    """Parse AIS and extract additional information."""
    from taxbuddy.parsers.ais import parse_ais

    try:
        console.print(f"\n  [dim]Parsing AIS...[/dim]")
        ais_data = parse_ais(path)
        if ais_data["pan"]:
            taxpayer.pan = ais_data["pan"]
        if ais_data["name"]:
            taxpayer.name = ais_data["name"]
        if ais_data["interest_income"] > 0:
            taxpayer.other_income.interest_savings = ais_data["interest_income"]
        if ais_data["dividend_income"] > 0:
            taxpayer.other_income.dividend = ais_data["dividend_income"]

        console.print(f"  [green]Parsed AIS[/green] — "
                      f"TDS entries: {len(ais_data['tds_entries'])}, "
                      f"Interest: ₹{ais_data['interest_income']:,.0f}, "
                      f"Dividend: ₹{ais_data['dividend_income']:,.0f}")
    except Exception as e:
        console.print(f"  [red]Error parsing AIS:[/red] {e}")


def _parse_form26as_file(path: str):
    """Parse Form 26AS for TDS verification."""
    from taxbuddy.parsers.form26as import parse_form26as

    try:
        console.print(f"\n  [dim]Parsing Form 26AS...[/dim]")
        data = parse_form26as(path)
        for entry in data["tds_salary"] + data["tds_other"]:
            taxpayer.tds_entries.append(entry)

        console.print(f"  [green]Parsed Form 26AS[/green] — "
                      f"Total TDS: ₹{data['total_tds']:,.0f}")
    except Exception as e:
        console.print(f"  [red]Error parsing Form 26AS:[/red] {e}")


def _parse_mf_file(path: str):
    """Parse Mutual Fund capital gains report."""
    from taxbuddy.parsers.mutual_funds import parse_mutual_fund_sheet

    try:
        console.print(f"\n  [dim]Parsing MF Capital Gains Report...[/dim]")
        cg = parse_mutual_fund_sheet(path)
        taxpayer.capital_gains = cg
        taxpayer.has_capital_gains = (cg.stcg_111a != 0 or cg.ltcg_112a != 0)

        console.print(f"  [green]Parsed MF Report[/green] — "
                      f"STCG: ₹{cg.stcg_111a:,.0f}, LTCG: ₹{cg.ltcg_112a:,.0f}, "
                      f"Transactions: {len(cg.transactions)}")

        if cg.stcg_quarterly or cg.ltcg_quarterly:
            console.print("  [green]Table F quarterly breakup computed automatically[/green]")
    except Exception as e:
        console.print(f"  [red]Error parsing MF report:[/red] {e}")


def _parse_payslip_file(path: str):
    """Parse payslip for salary component breakup."""
    from taxbuddy.parsers.payslip import parse_payslip

    try:
        console.print(f"\n  [dim]Parsing Payslip...[/dim]")
        data = parse_payslip(path)
        console.print(f"  [green]Parsed Payslip[/green] — "
                      f"Basic: ₹{data['basic']:,.0f}/month, "
                      f"HRA: ₹{data['hra']:,.0f}/month, "
                      f"Gross: ₹{data['gross']:,.0f}/month")
    except Exception as e:
        console.print(f"  [red]Error parsing Payslip:[/red] {e}")


def collect_manual_info():
    """Collect information that couldn't be parsed from documents."""
    console.print(Rule("[bold]Additional Information[/bold]"))
    console.print("[dim]Let me ask a few questions to complete your profile.[/dim]\n")

    # Personal info
    if not taxpayer.name:
        taxpayer.name = Prompt.ask("Your full name (as per PAN)")
    if not taxpayer.pan:
        taxpayer.pan = Prompt.ask("Your PAN number")

    taxpayer.city = Prompt.ask(
        "City of residence",
        default="Bangalore"
    )

    # Employment
    if not taxpayer.employers:
        console.print("\n[yellow]No salary data found from documents. Let's enter manually.[/yellow]")
        _collect_employer_info()
    else:
        console.print(f"\n[green]Found {len(taxpayer.employers)} employer(s) from documents.[/green]")
        for i, emp in enumerate(taxpayer.employers, 1):
            console.print(f"  {i}. {emp.name} — Gross: ₹{emp.gross_salary:,.0f}")

        if Confirm.ask("Do you want to edit/add employer details?", default=False):
            _collect_employer_info()

    # HRA
    console.print()
    if Confirm.ask("Are you paying rent? (for HRA exemption)", default=True):
        rent_monthly = float(Prompt.ask("Monthly rent amount (₹)", default="0"))
        if rent_monthly > 0:
            taxpayer.hra_details = HRADetails(
                rent_paid_monthly=rent_monthly,
                rent_paid_annual=rent_monthly * 12,
                city=City.METRO if taxpayer.is_metro else City.NON_METRO,
            )

    # LTA
    console.print()
    if Confirm.ask("Do you want to claim LTA (Leave Travel Allowance)?", default=False):
        lta_amount = float(Prompt.ask("LTA amount to claim (₹)", default="0"))
        taxpayer.exemptions.lta = lta_amount

    # Deductions
    console.print("\n[bold]Deductions (Chapter VI-A):[/bold]")

    pf = float(Prompt.ask("  80C — Total (PF + PPF + ELSS + LIC + etc.) [max ₹1.5L]", default="150000"))
    taxpayer.deductions.sec_80c = min(pf, 150000)

    nps_1b = float(Prompt.ask("  80CCD(1B) — Additional NPS [max ₹50K]", default="0"))
    taxpayer.deductions.sec_80ccd_1b = min(nps_1b, 50000)

    nps_2 = float(Prompt.ask("  80CCD(2) — Employer NPS contribution", default="0"))
    taxpayer.deductions.sec_80ccd_2 = nps_2

    d_self = float(Prompt.ask("  80D — Health insurance (self/family) [max ₹25K]", default="25000"))
    taxpayer.deductions.sec_80d_self = min(d_self, 25000)

    d_parents = float(Prompt.ask("  80D — Health insurance (parents) [max ₹25K/₹50K senior]", default="0"))
    taxpayer.deductions.sec_80d_parents = d_parents

    if Confirm.ask("  Do you have other deductions (80DDB, 80DD, 80E, 80G, etc.)?", default=False):
        taxpayer.deductions.sec_80ddb = float(Prompt.ask("    80DDB — Specified disease treatment", default="0"))
        taxpayer.deductions.sec_80dd = float(Prompt.ask("    80DD — Disabled dependent", default="0"))
        taxpayer.deductions.sec_80e = float(Prompt.ask("    80E — Education loan interest", default="0"))
        taxpayer.deductions.sec_80g = float(Prompt.ask("    80G — Donations", default="0"))

    # Other income
    console.print("\n[bold]Other Income:[/bold]")
    if taxpayer.other_income.interest_savings == 0:
        taxpayer.other_income.interest_savings = float(
            Prompt.ask("  Interest from savings accounts", default="0")
        )
    taxpayer.deductions.sec_80tta = min(taxpayer.other_income.interest_savings, 10000)

    if taxpayer.other_income.interest_fd == 0:
        taxpayer.other_income.interest_fd = float(
            Prompt.ask("  Interest from FDs / RDs", default="0")
        )
    if taxpayer.other_income.dividend == 0:
        taxpayer.other_income.dividend = float(
            Prompt.ask("  Dividend income", default="0")
        )

    # ITR-2 specific questions
    console.print("\n[bold]Additional Questions (for ITR form selection):[/bold]")

    questions = get_itr_selection_questions()
    for q in questions:
        if q["id"] == "capital_gains" and taxpayer.has_capital_gains:
            continue
        if q["id"] == "total_income" and taxpayer.total_gross_salary > 5000000:
            continue

        answer = Confirm.ask(f"  {q['question']}", default=False)
        if q["id"] == "capital_gains":
            taxpayer.has_capital_gains = answer
        elif q["id"] == "house_property":
            taxpayer.has_multiple_house_property = answer
        elif q["id"] == "foreign_assets":
            taxpayer.has_foreign_assets = answer
            taxpayer.has_foreign_income = answer
        elif q["id"] == "director":
            taxpayer.is_director = answer
        elif q["id"] == "unlisted_shares":
            taxpayer.has_unlisted_shares = answer


def _collect_employer_info():
    """Collect employer information manually."""
    num_employers = int(Prompt.ask("Number of employers in FY 2025-26", default="1"))

    for i in range(num_employers):
        console.print(f"\n[bold]Employer {i + 1}:[/bold]")
        emp = EmployerInfo()
        emp.name = Prompt.ask("  Employer name")
        emp.gross_salary = float(Prompt.ask("  Gross salary (₹)"))
        emp.basic_salary = float(Prompt.ask("  Basic salary - annual (₹)"))
        emp.hra_received = float(Prompt.ask("  HRA received - annual (₹)", default="0"))
        emp.lta_received = float(Prompt.ask("  LTA received - annual (₹)", default="0"))
        emp.pf_employee = float(Prompt.ask("  PF (employee contribution) - annual (₹)", default="0"))
        emp.nps_employer = float(Prompt.ask("  NPS (employer contribution) - annual (₹)", default="0"))
        emp.professional_tax = float(Prompt.ask("  Professional tax (₹)", default="2400"))
        emp.tds_deducted = float(Prompt.ask("  TDS deducted (₹)"))
        emp.gratuity_received = float(Prompt.ask("  Gratuity received (₹)", default="0"))
        emp.leave_encashment = float(Prompt.ask("  Leave encashment received (₹)", default="0"))

        taxpayer.employers.append(emp)

    if num_employers > 1:
        console.print(Panel(
            "\n".join(MULTIPLE_EMPLOYER_RULES["key_points"]),
            title="[yellow]Multiple Employer Notes[/yellow]",
            border_style="yellow",
        ))


def show_itr_recommendation():
    """Show ITR form recommendation with reasons."""
    console.print(Rule("[bold]ITR Form Recommendation[/bold]"))

    result = select_itr_form(taxpayer)
    taxpayer.itr_form = result["form"]

    color = "green" if result["can_use_itr1"] else "cyan"
    console.print(Panel(
        f"[bold {color}]{result['form_name']}[/bold {color}]",
        title="Recommended ITR Form",
        border_style=color,
    ))

    if result["reasons"]:
        console.print("\n[bold]Reasons:[/bold]")
        for r in result["reasons"]:
            console.print(f"  [cyan]>[/cyan] {r}")

    if result["warnings"]:
        console.print("\n[bold yellow]Warnings:[/bold yellow]")
        for w in result["warnings"]:
            console.print(f"  [yellow]![/yellow] {w}")

    console.print()


def show_tax_computation():
    """Show complete tax computation with regime comparison."""
    console.print(Rule("[bold]Tax Computation[/bold]"))

    comparison = compare_regimes(taxpayer)

    for regime_key, label in [("old_regime", "Old Regime"), ("new_regime", "New Regime")]:
        data = comparison[regime_key]
        salary = data["salary"]

        table = Table(
            title=f"[bold]{label}[/bold]",
            box=box.ROUNDED,
            show_lines=True,
            min_width=60,
        )
        table.add_column("Particulars", style="bold", width=45)
        table.add_column("Amount (₹)", justify="right", width=15)

        # Salary
        table.add_row("[bold]Schedule S — Salary[/bold]", "")
        table.add_row("  Gross Salary (all employers)", f"{salary['gross_salary']:,.0f}")
        table.add_row("  Less: Exemptions u/s 10", f"({salary['sec10_exemptions']['total']:,.0f})")

        for key, val in salary["sec10_exemptions"].items():
            if key != "total" and val > 0:
                label_map = {
                    "hra_10_13a": "    HRA u/s 10(13A)",
                    "lta_10_5": "    LTA u/s 10(5)",
                    "gratuity_10_10": "    Gratuity u/s 10(10)",
                    "leave_encash_10_10aa": "    Leave Encashment u/s 10(10AA)",
                    "children_edu_10_14_ii": "    CEA u/s 10(14)(ii)",
                    "other_10_14_i": "    Other u/s 10(14)(i)",
                }
                table.add_row(label_map.get(key, f"    {key}"), f"{val:,.0f}")

        table.add_row("  Net Salary", f"{salary['net_salary_after_sec10']:,.0f}")
        table.add_row("  Less: Standard Deduction", f"({salary['sec16_deductions']['standard_deduction']:,.0f})")
        table.add_row("  Less: Professional Tax", f"({salary['sec16_deductions']['professional_tax']:,.0f})")
        table.add_row("[bold]  Income under Salary[/bold]", f"[bold]{salary['salary_income']:,.0f}[/bold]")

        # Other Income
        if data["other_income"] > 0:
            table.add_row("", "")
            table.add_row("[bold]Other Income[/bold]", f"{data['other_income']:,.0f}")

        # Capital Gains
        cg = data["capital_gains"]
        if cg["total"] > 0:
            table.add_row("", "")
            table.add_row("[bold]Capital Gains[/bold]", "")
            if cg["stcg_111a"] > 0:
                table.add_row("  STCG u/s 111A (equity MF)", f"{cg['stcg_111a']:,.0f}")
            if cg["ltcg_112a"] > 0:
                table.add_row("  LTCG u/s 112A (equity MF)", f"{cg['ltcg_112a']:,.0f}")
                table.add_row("  Less: Exemption u/s 112A", f"({cg['ltcg_112a_exempt']:,.0f})")

        # GTI
        table.add_row("", "")
        table.add_row("[bold]Gross Total Income[/bold]", f"[bold]{data['gross_total_income']:,.0f}[/bold]")

        # Deductions
        if data["deductions"]:
            table.add_row("", "")
            table.add_row("[bold]Deductions — Chapter VI-A[/bold]", "")
            for ded_name, ded_val in data["deductions"].items():
                table.add_row(f"  {ded_name}", f"({ded_val:,.0f})")
            table.add_row("[bold]  Total Deductions[/bold]", f"[bold]({data['total_deductions']:,.0f})[/bold]")

        # Taxable Income
        table.add_row("", "")
        table.add_row("[bold cyan]Total Taxable Income[/bold cyan]", f"[bold cyan]{data['taxable_income']:,.0f}[/bold cyan]")

        # Tax
        tax = data["tax_computation"]
        table.add_row("", "")
        table.add_row("[bold]Tax Computation[/bold]", "")
        table.add_row("  Tax on normal income", f"{tax['tax_on_normal']:,.0f}")
        if tax["tax_on_stcg_111a"] > 0:
            table.add_row("  Tax on STCG @20%", f"{tax['tax_on_stcg_111a']:,.0f}")
        if tax["tax_on_ltcg_112a"] > 0:
            table.add_row("  Tax on LTCG @12.5%", f"{tax['tax_on_ltcg_112a']:,.0f}")
        if tax["surcharge"] > 0:
            table.add_row("  Surcharge", f"{tax['surcharge']:,.0f}")
        table.add_row("  Health & Education Cess @4%", f"{tax['cess']:,.0f}")
        table.add_row("[bold]  Total Tax[/bold]", f"[bold]{tax['total_tax']:,.0f}[/bold]")

        # TDS and result
        table.add_row("", "")
        table.add_row("TDS Already Paid", f"{data['total_tds']:,.0f}")
        if data["is_refund"]:
            table.add_row("[bold green]REFUND[/bold green]", f"[bold green]{data['tax_payable']:,.0f}[/bold green]")
        else:
            table.add_row("[bold red]Tax Payable[/bold red]", f"[bold red]{data['tax_payable']:,.0f}[/bold red]")

        # Surcharge warning
        if data.get("surcharge_warning"):
            table.add_row("", "")
            table.add_row(
                "[bold yellow]SURCHARGE WARNING[/bold yellow]",
                "[bold yellow]Near ₹50L![/bold yellow]"
            )

        console.print(table)
        console.print()

    # Recommendation
    rec = comparison["recommended"]
    savings = comparison["savings"]

    rec_color = "green"
    rec_text = f"[bold {rec_color}]{rec.upper()} REGIME[/bold {rec_color}]"

    panel_text = f"Recommended: {rec_text}\n\n"
    panel_text += f"Tax Savings: [bold]₹{savings:,.0f}[/bold]\n\n"
    panel_text += "Reasons:\n"
    for r in comparison["reasons"]:
        panel_text += f"  > {r}\n"

    console.print(Panel(
        panel_text,
        title="[bold]Regime Recommendation[/bold]",
        border_style=rec_color,
    ))


def show_capital_gains_breakup():
    """Show Table F quarterly breakup for Schedule CG."""
    cg = taxpayer.capital_gains
    if not cg.stcg_quarterly and not cg.ltcg_quarterly:
        return

    console.print(Rule("[bold]Schedule CG — Table F Quarterly Breakup[/bold]"))
    console.print("[dim]Use these exact values in the ITR portal's Table F section.[/dim]\n")

    periods = [
        ("i", "Up to 15/6"),
        ("ii", "16/6 to 15/9"),
        ("iii", "16/9 to 15/12"),
        ("iv", "16/12 to 15/3"),
        ("v", "16/3 to 31/3"),
    ]

    if cg.stcg_111a != 0:
        table = Table(title="STCG u/s 111A (Row 1 — taxable at 20%)", box=box.ROUNDED)
        table.add_column("Period", style="bold", width=20)
        table.add_column("Amount (₹)", justify="right", width=15)

        total = 0
        for key, label in periods:
            val = cg.stcg_quarterly.get(key, 0)
            total += val
            if val != 0:
                table.add_row(f"({key}) {label}", f"{val:,.0f}")
            else:
                table.add_row(f"({key}) {label}", "0")
        table.add_row("[bold]Total[/bold]", f"[bold]{total:,.0f}[/bold]")
        console.print(table)
        console.print()

    if cg.ltcg_112a != 0:
        table = Table(title="LTCG u/s 112A (Row 5 — taxable at 12.5%)", box=box.ROUNDED)
        table.add_column("Period", style="bold", width=20)
        table.add_column("Amount (₹)", justify="right", width=15)

        total = 0
        for key, label in periods:
            val = cg.ltcg_quarterly.get(key, 0)
            total += val
            if val != 0:
                table.add_row(f"({key}) {label}", f"{val:,.0f}")
            else:
                table.add_row(f"({key}) {label}", "0")
        table.add_row("[bold]Total[/bold]", f"[bold]{total:,.0f}[/bold]")
        console.print(table)

    console.print()
    console.print(Panel(
        "Table F totals MUST exactly match Schedule BFLA item 3iii.\n"
        "Even ₹1 mismatch causes a validation error.\n"
        "TaxBuddy has already adjusted rounding to ensure exact match.",
        title="[yellow]Important[/yellow]",
        border_style="yellow",
    ))


def show_filing_guide():
    """Show page-by-page ITR filing guide."""
    form_name = "ITR-2" if taxpayer.itr_form and "2" in taxpayer.itr_form.value else "ITR-1"

    console.print(Rule(f"[bold]Page-by-Page {form_name} Filing Guide[/bold]"))

    guide = get_guide(form_name)

    for page in guide:
        console.print(f"\n[bold cyan]Page {page['page']}: {page['title']}[/bold cyan]")

        if "steps" in page:
            for step in page["steps"]:
                console.print(f"  [dim]>[/dim] {step}")

        if "tips" in page:
            for tip in page["tips"]:
                console.print(f"  [green]TIP:[/green] {tip}")

        if "common_errors" in page:
            for err in page["common_errors"]:
                console.print(f"  [red]ERROR:[/red] {err['error']}")
                console.print(f"  [green]FIX:[/green] {err['fix']}")

        if "important_lesson" in page:
            console.print(f"  [yellow]LESSON:[/yellow] {page['important_lesson']}")

    console.print()


def show_portal_lessons():
    """Show common portal issues and fixes."""
    console.print(Rule("[bold]Common Portal Issues & Fixes[/bold]"))
    console.print("[dim]Based on real ITR filing experience.[/dim]\n")

    for i, lesson in enumerate(PORTAL_LESSONS, 1):
        console.print(f"[bold red]{i}. {lesson['issue']}[/bold red]")
        console.print(f"   [yellow]Cause:[/yellow] {lesson['cause']}")
        console.print(f"   [green]Fix:[/green] {lesson['fix']}")
        console.print()


def show_surcharge_optimization():
    """Show surcharge optimization suggestions."""
    old = compute_total_income(taxpayer, "old")
    taxable = old["taxable_income"]

    if 4500000 < taxable < 5200000:
        console.print(Rule("[bold yellow]Surcharge Optimization[/bold yellow]"))

        gap = taxable - 5000000
        if gap > 0:
            console.print(Panel(
                f"Your taxable income is [bold]₹{taxable:,.0f}[/bold] — "
                f"[bold red]₹{gap:,.0f} ABOVE[/bold red] the ₹50L surcharge threshold.\n\n"
                f"This triggers a [bold]10% surcharge[/bold] on your entire tax, "
                f"costing approximately [bold red]₹{old['tax_computation']['surcharge']:,.0f}[/bold red] extra.\n\n"
                "Suggestions to bring below ₹50L:",
                title="[bold red]SURCHARGE ALERT[/bold red]",
                border_style="red",
            ))

            suggestions = _get_optimization_suggestions(gap)
            for s in suggestions:
                console.print(f"  [cyan]>[/cyan] {s}")
        else:
            console.print(Panel(
                f"Your taxable income is [bold]₹{taxable:,.0f}[/bold] — "
                f"₹{abs(gap):,.0f} below the ₹50L surcharge threshold.\n\n"
                "[green]You're safe from the 10% surcharge.[/green]",
                title="[bold green]Surcharge Safe Zone[/bold green]",
                border_style="green",
            ))
        console.print()


def _get_optimization_suggestions(gap: float) -> list[str]:
    """Generate deduction suggestions to bridge the surcharge gap."""
    suggestions = []
    remaining = gap
    ded = taxpayer.deductions

    if ded.sec_80c < 150000:
        can_add = 150000 - ded.sec_80c
        suggestions.append(f"80C: Increase to ₹1.5L — potential saving ₹{min(can_add, remaining):,.0f}")
        remaining -= can_add

    if ded.sec_80ccd_1b < 50000 and remaining > 0:
        can_add = 50000 - ded.sec_80ccd_1b
        suggestions.append(f"80CCD(1B): Invest ₹{can_add:,.0f} in NPS")
        remaining -= can_add

    if ded.sec_80d_parents == 0 and remaining > 0:
        suggestions.append("80D: Claim parents' health insurance (₹25K/₹50K)")
        remaining -= 25000

    if ded.sec_80ddb == 0 and remaining > 0:
        suggestions.append("80DDB: Medical treatment for specified disease — up to ₹40K (₹1L for senior citizen)")
        remaining -= 100000

    if taxpayer.exemptions.lta == 0 and remaining > 0:
        suggestions.append("LTA: Claim leave travel allowance (need domestic travel bills)")

    if remaining > 0:
        suggestions.append("Consider increasing rent for higher HRA exemption (need rent receipts + landlord PAN)")

    return suggestions


def interactive_menu():
    """Main interactive menu loop."""
    while True:
        console.print()
        console.print(Rule("[bold]What would you like to do?[/bold]"))
        console.print("  [cyan]1.[/cyan] View/Upload Documents")
        console.print("  [cyan]2.[/cyan] View Tax Computation (Old vs New Regime)")
        console.print("  [cyan]3.[/cyan] View ITR Form Recommendation")
        console.print("  [cyan]4.[/cyan] View Filing Guide (Page-by-Page)")
        console.print("  [cyan]5.[/cyan] View Capital Gains Table F Breakup")
        console.print("  [cyan]6.[/cyan] View Surcharge Optimization Tips")
        console.print("  [cyan]7.[/cyan] View Common Portal Errors & Fixes")
        console.print("  [cyan]8.[/cyan] View Documents Checklist")
        console.print("  [cyan]9.[/cyan] Recalculate (after editing inputs)")
        console.print("  [cyan]0.[/cyan] Exit")
        console.print()

        choice = Prompt.ask("Enter your choice", default="2")

        if choice == "1":
            upload_documents()
            collect_manual_info()
        elif choice == "2":
            show_tax_computation()
        elif choice == "3":
            show_itr_recommendation()
        elif choice == "4":
            show_filing_guide()
        elif choice == "5":
            show_capital_gains_breakup()
        elif choice == "6":
            show_surcharge_optimization()
        elif choice == "7":
            show_portal_lessons()
        elif choice == "8":
            show_documents_checklist()
            show_pre_filing_checklist()
        elif choice == "9":
            collect_manual_info()
        elif choice == "0":
            console.print("\n[bold green]Thank you for using TaxBuddy![/bold green]")
            console.print("[dim]Remember to verify all computations on the IT portal.[/dim]\n")
            break
        else:
            console.print("[red]Invalid choice. Please try again.[/red]")


def main():
    """Main entry point for TaxBuddy CLI."""
    try:
        banner()
        show_documents_checklist()
        show_pre_filing_checklist()

        console.print()
        if Confirm.ask("Ready to start? Let's upload your documents", default=True):
            upload_documents()

        console.print()
        collect_manual_info()

        # Show results
        show_itr_recommendation()
        show_tax_computation()
        show_capital_gains_breakup()
        show_surcharge_optimization()

        # Enter interactive mode
        interactive_menu()

    except KeyboardInterrupt:
        console.print("\n\n[bold yellow]Interrupted. Goodbye![/bold yellow]")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n[bold red]Error:[/bold red] {e}")
        console.print("[dim]Please report this issue.[/dim]")
        raise


if __name__ == "__main__":
    main()
