"""
ITR Form Selector — determines whether ITR-1 or ITR-2 is appropriate.

Based on Rule 12 of the Income Tax Rules, 1962 and CBDT notifications.

IMPORTANT: This module NEVER makes assumptions. If information is
insufficient, it asks the user for clarification.
"""
from __future__ import annotations

from taxbuddy.models.taxpayer import TaxPayer, ITRForm
from taxbuddy.knowledge.rules import ITR_SELECTION_RULES


def select_itr_form(taxpayer: TaxPayer) -> dict:
    """
    Determine the correct ITR form based on taxpayer's profile.

    Returns:
        dict with:
          - form: ITRForm enum
          - reasons: list of reasons for the selection
          - warnings: list of things to verify
          - reference: legal reference for the selection
    """
    must_use_itr2 = []
    can_use_itr1 = True
    warnings = []

    # Rule 1: Total income > 50 Lakhs → ITR-2
    total_income_estimate = taxpayer.total_gross_salary + taxpayer.other_income.total
    if total_income_estimate > 5000000:
        must_use_itr2.append(
            f"Total income exceeds ₹50 Lakhs (estimated ₹{total_income_estimate:,.0f}) — "
            f"ITR-1 limit is ₹50L [Rule 12(1)(b)(i)]"
        )
        can_use_itr1 = False

    # Rule 2: Capital gains → ITR-2
    has_cg = (
        taxpayer.capital_gains.stcg_111a != 0 or
        taxpayer.capital_gains.stcg_other != 0 or
        taxpayer.capital_gains.ltcg_112a != 0 or
        taxpayer.capital_gains.ltcg_112 != 0 or
        taxpayer.has_capital_gains
    )
    if has_cg:
        must_use_itr2.append(
            "Has capital gains (STCG/LTCG from shares or mutual funds) — "
            "ITR-1 does not support capital gains [Sec 111A / 112A]"
        )
        can_use_itr1 = False

    # Rule 3: Multiple house property → ITR-2
    if taxpayer.has_multiple_house_property:
        must_use_itr2.append(
            "Income from more than one house property — "
            "ITR-1 supports only one house property"
        )
        can_use_itr1 = False

    # Rule 4: Foreign assets or income → ITR-2
    if taxpayer.has_foreign_assets or taxpayer.has_foreign_income:
        must_use_itr2.append(
            "Has foreign assets or foreign income — "
            "ITR-1 does not support Schedule FA [Rule 12(1)(b)(i)]"
        )
        can_use_itr1 = False

    # Rule 5: Director in a company → ITR-2
    if taxpayer.is_director:
        must_use_itr2.append(
            "Director in a company — ITR-1 is not applicable"
        )
        can_use_itr1 = False

    # Rule 6: Unlisted equity shares → ITR-2
    if taxpayer.has_unlisted_shares:
        must_use_itr2.append(
            "Holds unlisted equity shares — ITR-1 does not support this"
        )
        can_use_itr1 = False

    # Rule 7: Non-resident → ITR-2
    from taxbuddy.models.taxpayer import ResidentialStatus
    if taxpayer.residential_status != ResidentialStatus.RESIDENT:
        must_use_itr2.append(
            f"Residential status is {taxpayer.residential_status.value} — "
            "ITR-1 is only for Resident Individuals"
        )
        can_use_itr1 = False

    # Rule 8: Business income → Neither ITR-1 nor ITR-2
    if taxpayer.has_business_income:
        warnings.append(
            "WARNING: Business/profession income detected. "
            "You need ITR-3 or ITR-4, not ITR-1/ITR-2. "
            "TaxBuddy currently supports only ITR-1 and ITR-2."
        )

    # Rule 9: Multiple employers
    if len(taxpayer.employers) > 1:
        warnings.append(
            "Multiple employers detected. Salary from all employers will be "
            "consolidated. Ensure exemptions not claimed at previous employer "
            "(due to different regime) are claimed in ITR. "
            "[Sec 192(2) read with Rule 26B]"
        )

    # Determine form
    if can_use_itr1 and not must_use_itr2:
        form = ITRForm.ITR1
        reasons = ["All conditions for ITR-1 (Sahaj) are satisfied"]
        if taxpayer.other_income.total > 0:
            reasons.append("Other income (interest, dividend) can be reported in ITR-1")
    else:
        form = ITRForm.ITR2
        reasons = must_use_itr2

    # Additional checks for ESOP / RSU (common for tech employees)
    for emp in taxpayer.employers:
        if emp.perquisites_value > 0:
            warnings.append(
                f"Perquisites of ₹{emp.perquisites_value:,.0f} detected from {emp.name}. "
                "If these include ESOPs/RSUs, ensure they are reported correctly "
                "in Schedule S under Section 17(2)."
            )

    return {
        "form": form,
        "form_name": form.value,
        "reasons": reasons,
        "warnings": warnings,
        "reference": ITR_SELECTION_RULES.get(
            "ITR-1" if form == ITRForm.ITR1 else "ITR-2", {}
        ),
        "can_use_itr1": can_use_itr1,
    }


def get_itr_selection_questions() -> list[dict]:
    """
    Return questions to ask the user if we don't have enough info
    to determine the correct ITR form.
    """
    return [
        {
            "id": "capital_gains",
            "question": "Did you sell any shares, mutual funds, or property during FY 2025-26?",
            "impact": "If yes → ITR-2 required (ITR-1 doesn't support capital gains)",
        },
        {
            "id": "house_property",
            "question": "Do you own more than one house property?",
            "impact": "If yes → ITR-2 required",
        },
        {
            "id": "foreign_assets",
            "question": "Do you hold any foreign assets (bank accounts, shares, property abroad)?",
            "impact": "If yes → ITR-2 required (Schedule FA mandatory)",
        },
        {
            "id": "director",
            "question": "Are you a director in any company?",
            "impact": "If yes → ITR-2 required",
        },
        {
            "id": "unlisted_shares",
            "question": "Do you hold any unlisted equity shares (e.g., ESOPs in a private company)?",
            "impact": "If yes → ITR-2 required",
        },
        {
            "id": "total_income",
            "question": "Is your total income (before deductions) above ₹50 Lakhs?",
            "impact": "If yes → ITR-2 required (ITR-1 has ₹50L limit)",
        },
        {
            "id": "residential_status",
            "question": "Are you a Resident Indian for tax purposes in FY 2025-26? (stayed in India for 182+ days)",
            "impact": "Non-residents must use ITR-2",
        },
    ]
