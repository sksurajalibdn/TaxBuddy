"""
Smart Exemption & Deduction Calculator.

Minimizes user input by:
  - Auto-extracting what's available from Form 16, AIS, payslip
  - Asking only the essential missing inputs
  - Computing all exemptions/deductions to their optimal values
  - Pre-filling the ITR with the best values

Each section returns a dict with:
  {inputs_needed, computed, breakup, legal_ref, tips}
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from taxbuddy.models.taxpayer import (
    TaxPayer, EmployerInfo, HRADetails, City,
    Deductions, METRO_CITIES,
)
from taxbuddy.knowledge.tax_slabs import (
    HRA_METRO_PERCENT, HRA_NON_METRO_PERCENT,
    SECTION_80C_LIMIT, SECTION_80CCD_1B_LIMIT,
    SECTION_80D_SELF_LIMIT, SECTION_80D_PARENTS_LIMIT,
    SECTION_80D_SELF_SENIOR_LIMIT, SECTION_80D_PARENTS_SENIOR_LIMIT,
    SECTION_80TTA_LIMIT,
)


@dataclass
class ExemptionResult:
    section: str
    title: str
    exemption: float
    breakup: dict = field(default_factory=dict)
    formula: str = ""
    auto_filled: bool = False
    legal_ref: str = ""
    tips: list = field(default_factory=list)


def compute_all_exemptions(
    taxpayer: TaxPayer,
    rent_monthly: float = 0,
    city: str = "",
    has_health_ins_self: bool = True,
    health_premium_self: float = 0,
    health_premium_parents: float = 0,
    parents_senior: bool = False,
    self_senior: bool = False,
    nps_self: float = 0,
    education_loan_interest: float = 0,
    donations_80g: float = 0,
    medical_80ddb: float = 0,
    children_count: int = 0,
    lta_claimed: float = 0,
) -> dict:
    """
    Compute all exemptions and deductions with minimal user input.

    Most values are auto-extracted from Form 16 / AIS / payslip.
    Only a few essential inputs are needed from the user.
    """
    results = {}

    total_basic = taxpayer.total_basic_salary
    total_hra_received = taxpayer.total_hra_received
    total_gross = taxpayer.total_gross_salary
    is_metro = city.lower().strip() in METRO_CITIES if city else taxpayer.is_metro

    results["hra"] = _compute_hra(
        total_basic, total_hra_received, rent_monthly, is_metro, city
    )

    results["standard_deduction"] = ExemptionResult(
        section="Sec 16(ia)",
        title="Standard Deduction",
        exemption=50000,
        breakup={"old_regime": 50000, "new_regime": 75000},
        auto_filled=True,
        legal_ref="Section 16(ia) — flat deduction from salary",
        tips=["No documents needed. Automatically applied."],
    )

    prof_tax = sum(e.professional_tax for e in taxpayer.employers)
    results["professional_tax"] = ExemptionResult(
        section="Sec 16(iii)",
        title="Professional Tax",
        exemption=prof_tax,
        breakup={"from_form16": prof_tax},
        auto_filled=True,
        legal_ref="Section 16(iii) — deduction for employment tax",
        tips=["Auto-extracted from Form 16. Typically ₹2,400/year (₹200/month)."],
    )

    results["sec_80c"] = _compute_80c(taxpayer)

    results["sec_80ccd_1b"] = _compute_80ccd_1b(nps_self)

    nps_employer = sum(e.nps_employer for e in taxpayer.employers)
    results["sec_80ccd_2"] = ExemptionResult(
        section="Sec 80CCD(2)",
        title="Employer NPS Contribution",
        exemption=min(nps_employer, total_basic * 0.14),
        breakup={
            "employer_nps": nps_employer,
            "limit_14pct_basic": round(total_basic * 0.14),
            "allowed": min(nps_employer, total_basic * 0.14),
        },
        auto_filled=True,
        legal_ref="Section 80CCD(2) — employer contribution, max 14% of basic (Govt) / 10% (Private)",
        tips=[
            "Available in BOTH Old and New regime.",
            "Auto-extracted from Form 16.",
            "If you also contribute to NPS, claim it under 80CCD(1B) separately.",
        ],
    )

    results["sec_80d"] = _compute_80d(
        health_premium_self, health_premium_parents,
        self_senior, parents_senior, has_health_ins_self,
    )

    savings_interest = taxpayer.other_income.interest_savings
    results["sec_80tta"] = ExemptionResult(
        section="Sec 80TTA",
        title="Savings Account Interest Deduction",
        exemption=min(savings_interest, SECTION_80TTA_LIMIT),
        breakup={
            "savings_interest_from_ais": savings_interest,
            "limit": SECTION_80TTA_LIMIT,
            "deduction": min(savings_interest, SECTION_80TTA_LIMIT),
        },
        auto_filled=True,
        legal_ref="Section 80TTA — max ₹10,000 on savings interest (non-senior)",
        tips=[
            "Auto-extracted from AIS.",
            "Only savings account interest qualifies — not FD/RD.",
            "Senior citizens (60+) should use 80TTB instead (₹50K limit).",
        ],
    )

    if education_loan_interest > 0:
        results["sec_80e"] = ExemptionResult(
            section="Sec 80E",
            title="Education Loan Interest",
            exemption=education_loan_interest,
            breakup={"interest_paid": education_loan_interest},
            legal_ref="Section 80E — no upper limit, full interest deductible for 8 years",
            tips=["Get certificate from bank showing interest component.",
                  "Available for self, spouse, or children's education."],
        )

    if donations_80g > 0:
        results["sec_80g"] = ExemptionResult(
            section="Sec 80G",
            title="Donations",
            exemption=donations_80g,
            breakup={"donations": donations_80g},
            legal_ref="Section 80G — 50% or 100% deduction based on fund",
            tips=["Keep donation receipts with PAN of institution.",
                  "Some donations qualify for 100% deduction (PM Relief Fund)."],
        )

    if medical_80ddb > 0:
        limit = 100000 if self_senior else 40000
        results["sec_80ddb"] = ExemptionResult(
            section="Sec 80DDB",
            title="Medical Treatment (Specified Disease)",
            exemption=min(medical_80ddb, limit),
            breakup={"amount": medical_80ddb, "limit": limit,
                      "deduction": min(medical_80ddb, limit)},
            legal_ref="Section 80DDB — specified diseases (cancer, neurological, etc.)",
            tips=["Requires Form 10-I from specialist doctor.",
                  f"Limit: ₹{limit:,} ({'senior citizen' if self_senior else 'below 60'})."],
        )

    results["lta"] = _compute_lta(taxpayer, lta_claimed)

    gratuity = sum(e.gratuity_received for e in taxpayer.employers)
    if gratuity > 0:
        exempt = min(gratuity, 2000000)
        results["gratuity"] = ExemptionResult(
            section="Sec 10(10)",
            title="Gratuity Exemption",
            exemption=exempt,
            breakup={"received": gratuity, "exempt": exempt,
                      "taxable": max(gratuity - exempt, 0)},
            auto_filled=True,
            legal_ref="Section 10(10) — max ₹20L exemption (non-govt)",
        )

    leave_enc = sum(e.leave_encashment for e in taxpayer.employers)
    if leave_enc > 0:
        exempt = min(leave_enc, 2500000)
        results["leave_encashment"] = ExemptionResult(
            section="Sec 10(10AA)",
            title="Leave Encashment Exemption",
            exemption=exempt,
            breakup={"received": leave_enc, "exempt": exempt},
            auto_filled=True,
            legal_ref="Section 10(10AA) — max ₹25L exemption",
        )

    results["summary"] = _build_summary(results)
    return results


def _compute_hra(basic, hra_received, rent_monthly, is_metro, city_name):
    """HRA u/s 10(13A) — all 3 criteria auto-computed."""
    rent_annual = rent_monthly * 12
    metro_pct = HRA_METRO_PERCENT if is_metro else HRA_NON_METRO_PERCENT
    city_label = "Metro (50%)" if is_metro else "Non-Metro (40%)"

    if rent_annual <= 0 or hra_received <= 0 or basic <= 0:
        return ExemptionResult(
            section="Sec 10(13A)",
            title="HRA Exemption",
            exemption=0,
            breakup={
                "criteria_a_actual_hra": hra_received,
                "criteria_b_rent_minus_10pct": 0,
                "criteria_c_pct_of_basic": 0,
                "minimum_exemption": 0,
            },
            formula="Not applicable — no rent or HRA",
            legal_ref="Section 10(13A) read with Rule 2A",
            tips=[
                "Enter monthly rent to auto-calculate HRA exemption.",
                "If not paying rent, HRA is fully taxable.",
            ],
        )

    a = hra_received
    b = max(rent_annual - (0.10 * basic), 0)
    c = metro_pct * basic
    exemption = min(a, b, c)

    winning = "A" if exemption == a else ("B" if exemption == b else "C")

    return ExemptionResult(
        section="Sec 10(13A)",
        title="HRA Exemption",
        exemption=round(exemption),
        breakup={
            "basic_salary_annual": round(basic),
            "hra_received_annual": round(a),
            "rent_paid_annual": round(rent_annual),
            "city_type": city_label,
            "criteria_a_actual_hra": round(a),
            "criteria_b_rent_minus_10pct": round(b),
            "criteria_c_pct_of_basic": round(c),
            "minimum_exemption": round(exemption),
            "winning_criteria": winning,
        },
        formula=(
            f"Min of: (A) HRA ₹{a:,.0f}, "
            f"(B) Rent−10% ₹{b:,.0f}, "
            f"(C) {int(metro_pct*100)}% Basic ₹{c:,.0f} "
            f"→ Criteria {winning} wins"
        ),
        auto_filled=False,
        legal_ref="Section 10(13A) read with Rule 2A of IT Rules",
        tips=[
            "Rent receipts mandatory if rent > ₹1L/year.",
            "Landlord PAN mandatory if rent > ₹1L/year.",
            f"City: {city_name or 'Unknown'} → {city_label}.",
            "Available only under Old Regime.",
            f"Taxable HRA = ₹{round(a - exemption):,} (HRA − exemption).",
        ],
    )


def _compute_80c(taxpayer):
    """80C auto from EPF + Form 16 declared amounts."""
    epf = sum(e.pf_employee for e in taxpayer.employers)

    form16_80c = 0
    for emp in taxpayer.employers:
        form16_80c = max(form16_80c, emp.sec10_exemptions.get("deduction_80C", 0))

    auto_80c = max(epf, form16_80c)
    if auto_80c == 0:
        auto_80c = epf

    allowed = min(auto_80c, SECTION_80C_LIMIT) if auto_80c > 0 else SECTION_80C_LIMIT

    return ExemptionResult(
        section="Sec 80C/80CCC/80CCD(1)",
        title="Section 80C Deduction",
        exemption=allowed,
        breakup={
            "epf_from_form16": round(epf),
            "form16_declared_80c": round(form16_80c),
            "auto_computed": round(auto_80c),
            "limit": SECTION_80C_LIMIT,
            "remaining_for_elss_ppf_lic": max(SECTION_80C_LIMIT - auto_80c, 0),
        },
        auto_filled=True,
        legal_ref="Section 80C — combined limit ₹1,50,000",
        tips=[
            f"EPF contribution (auto): ₹{epf:,.0f}",
            f"Remaining 80C headroom: ₹{max(SECTION_80C_LIMIT - auto_80c, 0):,}",
            "Add PPF, ELSS, LIC, tuition fees, tax-saver FD to maximize.",
            "Available only under Old Regime.",
        ],
    )


def _compute_80ccd_1b(nps_self):
    """80CCD(1B) — additional NPS deduction."""
    allowed = min(nps_self, SECTION_80CCD_1B_LIMIT)
    return ExemptionResult(
        section="Sec 80CCD(1B)",
        title="Additional NPS (Self)",
        exemption=allowed,
        breakup={"nps_contribution": nps_self, "limit": SECTION_80CCD_1B_LIMIT,
                 "deduction": allowed},
        legal_ref="Section 80CCD(1B) — additional ₹50,000 over 80C limit",
        tips=[
            "This is OVER AND ABOVE the 80C limit.",
            "Available only under Old Regime.",
            "Check your NPS (PRAN) statement for contribution amount.",
        ],
    )


def _compute_80d(prem_self, prem_parents, self_senior, parents_senior, has_ins):
    """80D — auto-calculate based on premiums and age."""
    self_limit = SECTION_80D_SELF_SENIOR_LIMIT if self_senior else SECTION_80D_SELF_LIMIT
    parent_limit = SECTION_80D_PARENTS_SENIOR_LIMIT if parents_senior else SECTION_80D_PARENTS_LIMIT

    self_ded = min(prem_self, self_limit)
    parent_ded = min(prem_parents, parent_limit)
    total = self_ded + parent_ded

    breakup = {
        "self_premium": prem_self,
        "self_limit": self_limit,
        "self_deduction": self_ded,
        "parents_premium": prem_parents,
        "parents_limit": parent_limit,
        "parents_deduction": parent_ded,
        "total_deduction": total,
        "preventive_health_checkup": "Included within limit (₹5,000)",
    }

    tips = [
        f"Self/Family limit: ₹{self_limit:,} ({'senior' if self_senior else 'below 60'}).",
        f"Parents limit: ₹{parent_limit:,} ({'senior' if parents_senior else 'below 60'}).",
        "Preventive health checkup ₹5,000 is within the overall limit.",
        "Available only under Old Regime.",
    ]

    if prem_self == 0 and has_ins:
        tips.insert(0, "Enter your health insurance premium to claim 80D.")

    return ExemptionResult(
        section="Sec 80D",
        title="Health Insurance Premium",
        exemption=total,
        breakup=breakup,
        legal_ref="Section 80D — medical insurance premium deduction",
        tips=tips,
    )


def _compute_lta(taxpayer, lta_claimed):
    """LTA u/s 10(5) — auto from Form 16 or user claim."""
    form16_lta = sum(e.lta_received for e in taxpayer.employers)
    lta_exempt = sum(
        e.sec10_exemptions.get("lta_exempt", 0) for e in taxpayer.employers
    )

    actual = lta_claimed if lta_claimed > 0 else lta_exempt
    exempt = min(actual, form16_lta) if form16_lta > 0 else actual

    return ExemptionResult(
        section="Sec 10(5)",
        title="Leave Travel Allowance",
        exemption=round(exempt),
        breakup={
            "lta_received": round(form16_lta),
            "claimed": round(actual),
            "exempt": round(exempt),
        },
        auto_filled=lta_exempt > 0,
        legal_ref="Section 10(5) read with Rule 2B",
        tips=[
            "Only domestic travel qualifies.",
            "Economy air or AC-1 rail fare only.",
            "2 journeys per block of 4 years (current: 2022-2025).",
            "Keep travel tickets as proof.",
        ],
    )


def _build_summary(results):
    """Build a summary of total exemptions and deductions."""
    sec10_total = 0
    sec16_total = 0
    vi_a_total = 0

    sec10_keys = ["hra", "lta", "gratuity", "leave_encashment"]
    sec16_keys = ["standard_deduction", "professional_tax"]
    vi_a_keys = ["sec_80c", "sec_80ccd_1b", "sec_80ccd_2", "sec_80d",
                 "sec_80tta", "sec_80e", "sec_80g", "sec_80ddb"]

    for k in sec10_keys:
        if k in results:
            sec10_total += results[k].exemption

    for k in sec16_keys:
        if k in results:
            sec16_total += results[k].exemption

    for k in vi_a_keys:
        if k in results:
            vi_a_total += results[k].exemption

    return {
        "sec10_exemptions": round(sec10_total),
        "sec16_deductions": round(sec16_total),
        "chapter_vi_a": round(vi_a_total),
        "total_tax_benefit": round(sec10_total + sec16_total + vi_a_total),
    }


def apply_exemptions_to_taxpayer(taxpayer: TaxPayer, results: dict):
    """Apply computed exemptions back to the taxpayer model."""
    hra = results.get("hra")
    if hra and hra.exemption > 0:
        breakup = hra.breakup
        taxpayer.hra_details = HRADetails(
            total_hra_received=breakup.get("hra_received_annual", 0),
            total_basic_salary=breakup.get("basic_salary_annual", 0),
            rent_paid_annual=breakup.get("rent_paid_annual", 0),
            rent_paid_monthly=breakup.get("rent_paid_annual", 0) / 12,
            city=City.METRO if "Metro" in breakup.get("city_type", "") else City.NON_METRO,
            hra_exemption=hra.exemption,
        )
        taxpayer.exemptions.hra = hra.exemption

    lta = results.get("lta")
    if lta:
        taxpayer.exemptions.lta = lta.exemption

    d = taxpayer.deductions
    c80 = results.get("sec_80c")
    if c80:
        d.sec_80c = c80.exemption

    c1b = results.get("sec_80ccd_1b")
    if c1b:
        d.sec_80ccd_1b = c1b.exemption

    c2 = results.get("sec_80ccd_2")
    if c2:
        d.sec_80ccd_2 = c2.exemption

    d80 = results.get("sec_80d")
    if d80:
        d.sec_80d_self = d80.breakup.get("self_deduction", 0)
        d.sec_80d_parents = d80.breakup.get("parents_deduction", 0)

    tta = results.get("sec_80tta")
    if tta:
        d.sec_80tta = tta.exemption

    e80 = results.get("sec_80e")
    if e80:
        d.sec_80e = e80.exemption

    g80 = results.get("sec_80g")
    if g80:
        d.sec_80g = g80.exemption

    ddb = results.get("sec_80ddb")
    if ddb:
        d.sec_80ddb = ddb.exemption
