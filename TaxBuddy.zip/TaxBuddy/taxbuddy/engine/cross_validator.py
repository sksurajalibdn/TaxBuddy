"""
Cross-validation engine — compares data across Form 16, AIS, and Form 26AS
to flag discrepancies BEFORE the user starts filing.

Also auto-fills missing employer TDS from AIS when Form 16 is not available
for all employers (e.g., job change scenario).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from taxbuddy.models.taxpayer import TDSEntry


@dataclass
class ValidationAlert:
    severity: str  # "critical", "warning", "info"
    title: str
    detail: str
    action: str


def cross_validate(
    form16_employers: list,
    ais_data: dict = None,
    form26as_data: dict = None,
    taxpayer=None,
) -> list[ValidationAlert]:
    """
    Cross-validate parsed data from all documents.

    When AIS shows more employers than Form 16s provided, this function:
      1. Flags the discrepancy as a warning
      2. Auto-adds the missing employer's salary and TDS from AIS to taxpayer
         so total TDS is accurate in the computation

    Returns list of ValidationAlert sorted by severity.
    """
    alerts: list[ValidationAlert] = []
    has_ais = (
        ais_data is not None
        and isinstance(ais_data, dict)
        and (ais_data.get("salary_tds") or ais_data.get("pan") or ais_data.get("raw_text"))
    )

    if has_ais:
        ais_employer_count = ais_data.get("employer_count", 0)
        ais_tans = set(ais_data.get("employer_tans", []))
        form16_count = len(form16_employers)
        form16_tans = set()

        if ais_employer_count == 0 and form16_employers:
            f16_names = [e.name or e.tan for e in form16_employers]
            alerts.append(ValidationAlert(
                severity="info",
                title="AIS UPLOADED — No salary TDS entries found in AIS",
                detail=(
                    "Your AIS was parsed but no TDS-192 (salary) entries were found.\n\n"
                    "- This may happen if the AIS PDF format changed or parsing hit an edge case\n"
                    "- Your Form 16 data from **"
                    + ", ".join(f16_names)
                    + "** is still being used for salary computation\n"
                    "- Other AIS data (interest, dividends, MF) was extracted if available\n"
                ),
                action="If you have 2+ employers, verify manually on the IT portal AIS page.",
            ))

        for emp in form16_employers:
            if emp.tan:
                form16_tans.add(emp.tan)

        # --- Check 1: Missing Form 16 + auto-fill TDS from AIS ---
        if ais_employer_count > form16_count:
            missing_tans = ais_tans - form16_tans
            missing_entries = []
            for entry in ais_data.get("salary_tds", []):
                if entry.tan in missing_tans:
                    missing_entries.append(entry)

            f16_names = [e.name or e.tan for e in form16_employers]
            missing_details = []
            total_missing_salary = 0.0
            total_missing_tds = 0.0
            for entry in missing_entries:
                name = entry.deductor_name or entry.tan
                sal = entry.income_credited
                tds = entry.tds_deducted
                total_missing_salary += sal
                total_missing_tds += tds
                missing_details.append(
                    f"- **{name}** (TAN: `{entry.tan}`)\n"
                    f"  - Salary credited: ₹{sal:,.0f}\n"
                    f"  - TDS deducted: ₹{tds:,.0f}"
                )

            alerts.append(ValidationAlert(
                severity="critical",
                title=(
                    f"MISSING FORM 16 — AIS shows {ais_employer_count} employers, "
                    f"you uploaded {form16_count}"
                ),
                detail=(
                    f"You uploaded Form 16 from: **{', '.join(f16_names)}**\n\n"
                    f"But your AIS shows salary from **{ais_employer_count} employers**. "
                    f"The following employer(s) are **missing Form 16**:\n\n"
                    + "\n".join(missing_details) + "\n\n"
                    "---\n\n"
                    "**✅ Auto-included from AIS:**\n\n"
                    f"- Total salary auto-added: ₹{total_missing_salary:,.0f}\n"
                    f"- Total TDS auto-added: ₹{total_missing_tds:,.0f}\n\n"
                    "TaxBuddy has automatically included this salary and TDS in your "
                    "tax computation so your total income and TDS credit are accurate."
                ),
                action=(
                    f"Ideally, get Form 16 from "
                    f"**{', '.join(e.deductor_name or e.tan for e in missing_entries)}** "
                    f"for complete salary breakup (Basic, HRA etc.). "
                    "However, TaxBuddy has already picked up the salary and TDS from AIS, "
                    "so your tax computation will still be correct."
                ),
            ))

            # Auto-add missing employer data to taxpayer if provided
            if taxpayer is not None:
                from taxbuddy.models.taxpayer import EmployerInfo, TaxRegime
                for entry in missing_entries:
                    already_exists = any(
                        e.tan == entry.tan for e in taxpayer.employers
                    )
                    if not already_exists:
                        emp = EmployerInfo(
                            name=entry.deductor_name or f"Employer ({entry.tan})",
                            tan=entry.tan,
                            gross_salary=entry.income_credited,
                            tds_deducted=entry.tds_deducted,
                            regime_at_employer=TaxRegime.NEW,
                        )
                        taxpayer.employers.append(emp)

        # --- Check 2: TDS / Salary mismatch per employer ---
        for emp in form16_employers:
            if not emp.tan:
                continue
            emp_label = emp.name or emp.tan
            for ais_entry in ais_data.get("salary_tds", []):
                if ais_entry.tan != emp.tan:
                    continue

                f16_tds = emp.tds_deducted
                ais_tds = ais_entry.tds_deducted
                if f16_tds > 0 and ais_tds > 0:
                    diff = abs(f16_tds - ais_tds)
                    if diff > 100:
                        alerts.append(ValidationAlert(
                            severity="warning",
                            title=f"TDS MISMATCH — {emp_label}",
                            detail=(
                                f"**{emp_label}** (TAN: `{emp.tan}`)\n\n"
                                f"- Form 16 TDS: ₹{f16_tds:,.0f}\n"
                                f"- AIS TDS: ₹{ais_tds:,.0f}\n"
                                f"- Difference: ₹{diff:,.0f}\n"
                            ),
                            action=(
                                f"Use Form 16 TDS amount for **{emp_label}** (employer's certificate is authoritative). "
                                "AIS sometimes splits TDS across multiple entries. "
                                "Cross-check with Form 26AS for final TDS credit."
                            ),
                        ))

                f16_salary = emp.gross_salary
                ais_salary = ais_entry.income_credited
                if f16_salary > 0 and ais_salary > 0:
                    sal_diff = abs(f16_salary - ais_salary)
                    if sal_diff > 1000:
                        alerts.append(ValidationAlert(
                            severity="warning",
                            title=f"SALARY MISMATCH — {emp_label}",
                            detail=(
                                f"**{emp_label}** (TAN: `{emp.tan}`)\n\n"
                                f"- Form 16 Salary: ₹{f16_salary:,.0f}\n"
                                f"- AIS Salary: ₹{ais_salary:,.0f}\n"
                                f"- Difference: ₹{sal_diff:,.0f}\n"
                            ),
                            action=(
                                f"AIS may include previous employer salary under **{emp_label}**. "
                                "Use Form 16 for accurate salary breakup."
                            ),
                        ))

        # --- Check 3: Interest income ---
        ais_savings = ais_data.get("interest_savings", 0)
        ais_fd = ais_data.get("interest_fd", 0)
        ais_interest = ais_savings + ais_fd
        if ais_interest > 500:
            alerts.append(ValidationAlert(
                severity="info",
                title=f"INTEREST INCOME DETECTED — ₹{ais_interest:,.0f}",
                detail=(
                    "AIS reports the following interest income:\n\n"
                    f"- Savings account interest: **₹{ais_savings:,.0f}**\n"
                    f"- FD / Term deposit interest: **₹{ais_fd:,.0f}**\n\n"
                    "Auto-included under **Income from Other Sources**."
                ),
                action=(
                    "80TTA deduction (max ₹10,000) auto-applied on savings interest. "
                    "FD interest is fully taxable at slab rate."
                ),
            ))

        # --- Check 4: Dividend income ---
        ais_dividend = ais_data.get("dividend_income", 0)
        if ais_dividend > 0:
            alerts.append(ValidationAlert(
                severity="info",
                title=f"DIVIDEND INCOME DETECTED — ₹{ais_dividend:,.0f}",
                detail=(
                    f"AIS shows dividend income of **₹{ais_dividend:,.0f}**.\n\n"
                    "- Dividends are **fully taxable** since FY 2020-21\n"
                    "- Auto-included under **Income from Other Sources**\n"
                    "- No deduction is available on dividends\n"
                ),
                action="Report under 'Other Sources' in the ITR. No deduction available.",
            ))

        # --- Check 5: MF sale in AIS but no CG declared ---
        ais_mf = ais_data.get("mf_sale_total", 0)
        if ais_mf > 0:
            tp_cg = 0
            if taxpayer:
                tp_cg = taxpayer.capital_gains.stcg_111a + taxpayer.capital_gains.ltcg_112a
            if tp_cg == 0 and taxpayer and not taxpayer.has_capital_gains:
                alerts.append(ValidationAlert(
                    severity="warning",
                    title=f"MF REDEMPTIONS DETECTED — ₹{ais_mf:,.0f}",
                    detail=(
                        f"AIS shows mutual fund redemption proceeds of **₹{ais_mf:,.0f}** "
                        "but no capital gains are declared.\n\n"
                        "- This means you may need to file **ITR-2** instead of ITR-1\n"
                        "- Upload **MF Capital Gains Report** from CAMS / KFintech for accurate STCG/LTCG computation\n"
                        "- Without this, IT department may flag under-reporting\n"
                    ),
                    action="Upload MF Capital Gains Report (CAMS / KFintech Excel) on the Upload page.",
                ))

    # --- Check 6: Form 16 but no AIS ---
    if form16_employers and not has_ais:
        emp_names = [e.name or e.tan for e in form16_employers]
        alerts.append(ValidationAlert(
            severity="warning",
            title="AIS NOT UPLOADED",
            detail=(
                "Without AIS, TaxBuddy cannot:\n\n"
                "- Detect if you have **additional employers** beyond "
                f"the {len(form16_employers)} Form 16(s) uploaded "
                f"({', '.join(emp_names)})\n"
                "- Verify interest / dividend income reported by banks\n"
                "- Run IT department-style automated audit checks\n"
                "- Flag mutual fund capital gains for ITR-2\n"
            ),
            action=(
                "Download AIS from eportal.incometax.gov.in → Services → AIS → "
                "FY 2025-26 → Download PDF. Strongly recommended."
            ),
        ))

    # --- Check 7: No Form 16 at all ---
    if not form16_employers:
        if has_ais and ais_data.get("salary_tds"):
            ais_emp_names = [
                e.deductor_name or e.tan for e in ais_data["salary_tds"]
            ]
            alerts.append(ValidationAlert(
                severity="warning",
                title="NO FORM 16 UPLOADED — Using AIS salary data",
                detail=(
                    "No Form 16 was uploaded. TaxBuddy is using salary and TDS "
                    "data from your AIS.\n\n"
                    "**Employers detected from AIS:**\n\n"
                    + "\n".join(f"- **{n}**" for n in ais_emp_names) + "\n\n"
                    "This is sufficient for filing, but Form 16 provides:\n\n"
                    "- Accurate salary breakup (Basic, HRA, Special Allowance)\n"
                    "- HRA exemption calculation inputs\n"
                    "- Section 10 exemption details\n"
                ),
                action=(
                    f"Get Form 16 from **{', '.join(ais_emp_names)}** for detailed "
                    "salary breakup and HRA calculation."
                ),
            ))

            if taxpayer is not None:
                from taxbuddy.models.taxpayer import EmployerInfo, TaxRegime
                for entry in ais_data.get("salary_tds", []):
                    already = any(e.tan == entry.tan for e in taxpayer.employers)
                    if not already:
                        taxpayer.employers.append(EmployerInfo(
                            name=entry.deductor_name or f"Employer ({entry.tan})",
                            tan=entry.tan,
                            gross_salary=entry.income_credited,
                            tds_deducted=entry.tds_deducted,
                            regime_at_employer=TaxRegime.NEW,
                        ))
        else:
            alerts.append(ValidationAlert(
                severity="critical",
                title="NO FORM 16 PROVIDED",
                detail="No Form 16 uploaded and no AIS salary data available.",
                action="Upload Form 16 from your employer's HR department.",
            ))

    severity_order = {"critical": 0, "warning": 1, "info": 2}
    alerts.sort(key=lambda a: severity_order.get(a.severity, 3))
    return alerts
