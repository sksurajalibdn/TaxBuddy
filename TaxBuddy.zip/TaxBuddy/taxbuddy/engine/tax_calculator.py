"""
Complete tax computation engine.

Computes:
  - Gross Total Income
  - Chapter VI-A Deductions
  - Total Taxable Income
  - Tax on normal income + special rate income
  - Surcharge + Cess
  - Tax payable / Refund
  - Old vs New regime comparison
"""
from __future__ import annotations

from taxbuddy.models.taxpayer import TaxPayer, TaxRegime
from taxbuddy.engine.salary import compute_salary_income
from taxbuddy.knowledge.tax_slabs import (
    compute_full_tax,
    SECTION_80C_LIMIT, SECTION_80CCD_1B_LIMIT,
    SECTION_80D_SELF_LIMIT, SECTION_80D_SELF_SENIOR_LIMIT,
    SECTION_80D_PARENTS_LIMIT, SECTION_80D_PARENTS_SENIOR_LIMIT,
    SECTION_80TTA_LIMIT, SECTION_80TTB_LIMIT,
    LTCG_EXEMPTION_112A,
)


def _cap_80c(deductions) -> float:
    raw = deductions.sec_80c + deductions.sec_80ccc + deductions.sec_80ccd_1
    return min(raw, SECTION_80C_LIMIT)


def compute_total_income(taxpayer: TaxPayer, regime: str = "old") -> dict:
    """
    Compute complete tax return breakdown.

    Returns comprehensive dict with all schedules for ITR filing.
    """
    # Schedule S — Salary
    salary = compute_salary_income(taxpayer, regime)

    # Income from Other Sources
    other_income = taxpayer.other_income.total

    # Capital Gains
    stcg_111a = taxpayer.capital_gains.stcg_111a
    stcg_other = taxpayer.capital_gains.stcg_other
    ltcg_112a = taxpayer.capital_gains.ltcg_112a
    ltcg_112 = taxpayer.capital_gains.ltcg_112

    total_cg = stcg_111a + stcg_other + ltcg_112a + ltcg_112

    # Gross Total Income
    gti = salary["salary_income"] + other_income + total_cg

    # Chapter VI-A Deductions (only under Old Regime)
    ded = taxpayer.deductions
    total_deductions = 0.0
    deduction_breakdown = {}

    if regime == "old":
        sec80c = _cap_80c(ded)
        sec80ccd1b = min(ded.sec_80ccd_1b, SECTION_80CCD_1B_LIMIT)
        sec80ccd2 = ded.sec_80ccd_2  # No upper cap (10% of basic validated separately)
        sec80d_self = min(ded.sec_80d_self, SECTION_80D_SELF_LIMIT)
        sec80d_parents = min(ded.sec_80d_parents, SECTION_80D_PARENTS_LIMIT)
        sec80tta = min(ded.sec_80tta, SECTION_80TTA_LIMIT)

        total_deductions = (
            sec80c + sec80ccd1b + sec80ccd2 +
            sec80d_self + sec80d_parents +
            ded.sec_80dd + ded.sec_80ddb + ded.sec_80e +
            ded.sec_80ee + ded.sec_80eea + ded.sec_80g + ded.sec_80gg +
            sec80tta + ded.sec_80u
        )

        deduction_breakdown = {
            "80C (PF/PPF/ELSS/LIC)": round(sec80c),
            "80CCD(1B) (NPS additional)": round(sec80ccd1b),
            "80CCD(2) (Employer NPS)": round(sec80ccd2),
            "80D (Health Insurance - Self)": round(sec80d_self),
            "80D (Health Insurance - Parents)": round(sec80d_parents),
            "80DD (Disabled Dependent)": round(ded.sec_80dd),
            "80DDB (Medical Treatment)": round(ded.sec_80ddb),
            "80E (Education Loan)": round(ded.sec_80e),
            "80G (Donations)": round(ded.sec_80g),
            "80GG (Rent - no HRA)": round(ded.sec_80gg),
            "80TTA (Savings Interest)": round(sec80tta),
            "80U (Self Disability)": round(ded.sec_80u),
        }
        deduction_breakdown = {k: v for k, v in deduction_breakdown.items() if v > 0}
    else:
        # New regime: only 80CCD(2) allowed
        sec80ccd2 = ded.sec_80ccd_2
        if sec80ccd2 > 0:
            total_deductions = sec80ccd2
            deduction_breakdown = {"80CCD(2) (Employer NPS)": round(sec80ccd2)}

    # Total Taxable Income
    taxable_income = max(gti - total_deductions, 0)

    # LTCG exemption u/s 112A
    ltcg_taxable = max(ltcg_112a - LTCG_EXEMPTION_112A, 0)

    # Compute Tax
    tax_result = compute_full_tax(
        taxable_income=taxable_income,
        regime=regime,
        ltcg_112a=ltcg_112a,
        stcg_111a=stcg_111a,
    )

    # TDS already paid
    total_tds = taxpayer.total_tds
    for entry in taxpayer.tds_entries:
        total_tds += entry.tds_deducted

    # Tax payable or refund
    tax_payable = tax_result["total_tax"] - total_tds
    is_refund = tax_payable < 0

    return {
        "regime": regime,
        "salary": salary,
        "other_income": round(other_income),
        "capital_gains": {
            "stcg_111a": round(stcg_111a),
            "stcg_other": round(stcg_other),
            "ltcg_112a": round(ltcg_112a),
            "ltcg_112a_exempt": round(min(ltcg_112a, LTCG_EXEMPTION_112A)),
            "ltcg_taxable": round(ltcg_taxable),
            "ltcg_112": round(ltcg_112),
            "total": round(total_cg),
            "quarterly_stcg": taxpayer.capital_gains.stcg_quarterly,
            "quarterly_ltcg": taxpayer.capital_gains.ltcg_quarterly,
        },
        "gross_total_income": round(gti),
        "deductions": deduction_breakdown,
        "total_deductions": round(total_deductions),
        "taxable_income": round(taxable_income),
        "tax_computation": tax_result,
        "total_tds": round(total_tds),
        "tax_payable": round(abs(tax_payable)),
        "is_refund": is_refund,
        "surcharge_warning": taxable_income > 4900000 and taxable_income < 5100000,
    }


def compare_regimes(taxpayer: TaxPayer) -> dict:
    """
    Compare Old vs New regime and recommend the better option.

    Returns comparison with savings and recommendation.
    """
    old = compute_total_income(taxpayer, "old")
    new = compute_total_income(taxpayer, "new")

    old_tax = old["tax_computation"]["total_tax"]
    new_tax = new["tax_computation"]["total_tax"]

    savings = abs(old_tax - new_tax)
    recommended = "old" if old_tax <= new_tax else "new"

    reasons = []
    if recommended == "old":
        if old["total_deductions"] > 200000:
            reasons.append(f"Significant deductions of ₹{old['total_deductions']:,.0f} under Chapter VI-A")
        hra = old["salary"]["sec10_exemptions"]["hra_10_13a"]
        if hra > 0:
            reasons.append(f"HRA exemption of ₹{hra:,.0f} available")
        if old.get("surcharge_warning"):
            reasons.append("Income near ₹50L surcharge threshold — deductions help stay below")
    else:
        reasons.append("Higher standard deduction of ₹75,000 under new regime")
        reasons.append("Lower slab rates offset the loss of deductions")
        if old["total_deductions"] < 150000:
            reasons.append("Limited deductions make new regime more beneficial")

    return {
        "old_regime": old,
        "new_regime": new,
        "old_tax": old_tax,
        "new_tax": new_tax,
        "savings": savings,
        "recommended": recommended,
        "reasons": reasons,
    }
