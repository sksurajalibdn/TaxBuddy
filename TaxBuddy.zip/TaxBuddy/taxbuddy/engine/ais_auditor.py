"""
AIS Audit Engine — replicates the IT Department's automated cross-checking.

The CPC (Centralised Processing Centre) in Bengaluru runs rule-based audits
against AIS data when processing ITRs.  This module simulates those checks
so users can fix issues BEFORE filing, not after getting a notice.

Key checks (mirrors IT Dept scrutiny):
 1. Income matching — salary, interest, dividends, MF proceeds
 2. TDS credit verification — claimed vs deposited
 3. High-value transaction flags (SFT data)
 4. Under-reporting detection
 5. Capital gains cross-check with SFT-18-EMF
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class AuditFinding:
    rule_id: str
    severity: str       # "critical", "warning", "info"
    category: str       # e.g. "Income Match", "TDS Credit", "High Value"
    title: str
    itr_value: float
    ais_value: float
    difference: float
    section: str        # IT Act section
    detail: str
    action: str
    notice_risk: str    # "High", "Medium", "Low"


def run_ais_audit(
    taxpayer,
    ais_data: Optional[dict] = None,
    form26as_data: Optional[dict] = None,
) -> list[AuditFinding]:
    """
    Run a full AIS-style audit against the taxpayer's declared data.
    Returns findings sorted by severity.
    """
    if not ais_data:
        return []

    findings: list[AuditFinding] = []

    _check_salary_income(findings, taxpayer, ais_data)
    _check_tds_credits(findings, taxpayer, ais_data, form26as_data)
    _check_interest_income(findings, taxpayer, ais_data)
    _check_dividend_income(findings, taxpayer, ais_data)
    _check_mf_capital_gains(findings, taxpayer, ais_data)
    _check_high_value_transactions(findings, taxpayer, ais_data)
    _check_under_reporting(findings, taxpayer, ais_data)

    severity_order = {"critical": 0, "warning": 1, "info": 2}
    findings.sort(key=lambda f: severity_order.get(f.severity, 3))
    return findings


def _check_salary_income(findings, taxpayer, ais_data):
    """Rule A1: Total salary reported must match AIS aggregate."""
    ais_salary_entries = ais_data.get("salary_tds", [])
    ais_total_salary = sum(e.income_credited for e in ais_salary_entries)
    itr_total_salary = taxpayer.total_gross_salary

    if ais_total_salary > 0 and itr_total_salary > 0:
        diff = ais_total_salary - itr_total_salary
        if abs(diff) > 5000:
            findings.append(AuditFinding(
                rule_id="A1-SALARY",
                severity="critical" if abs(diff) > 50000 else "warning",
                category="Income Match",
                title="Salary Income Mismatch",
                itr_value=itr_total_salary,
                ais_value=ais_total_salary,
                difference=diff,
                section="Sec 192 / Sec 143(1)(a)(ii)",
                detail=(
                    f"Your declared salary: ₹{itr_total_salary:,.0f}\n"
                    f"AIS aggregate salary: ₹{ais_total_salary:,.0f}\n"
                    f"Variance: ₹{abs(diff):,.0f}\n\n"
                    "CPC will add the unreported amount to your income and "
                    "compute additional tax + interest u/s 234A/234B/234C."
                ),
                action=(
                    "If difference is due to a previous employer whose salary was "
                    "already included by current employer in Form 16, this is fine. "
                    "Otherwise, obtain missing Form 16 and include the salary."
                ),
                notice_risk="High" if abs(diff) > 50000 else "Medium",
            ))

    ais_emp_count = ais_data.get("employer_count", 0)
    f16_count = len(taxpayer.employers)
    if ais_emp_count > f16_count and ais_emp_count > 0:
        findings.append(AuditFinding(
            rule_id="A1-MULTI-EMP",
            severity="critical",
            category="Income Match",
            title=f"AIS shows {ais_emp_count} employers, only {f16_count} Form 16(s) provided",
            itr_value=f16_count,
            ais_value=ais_emp_count,
            difference=ais_emp_count - f16_count,
            section="Sec 192(2) / Rule 26B",
            detail=(
                "The IT department sees salary from each deductor independently. "
                "If you don't report all employers, CPC will add the unreported "
                "salary and raise a demand."
            ),
            action="Obtain Form 16 from the missing employer(s) and add their salary.",
            notice_risk="High",
        ))


def _check_tds_credits(findings, taxpayer, ais_data, form26as_data):
    """Rule A2: TDS claimed must not exceed TDS deposited per 26AS."""
    ais_entries = ais_data.get("salary_tds", [])
    for emp in taxpayer.employers:
        if not emp.tan:
            continue
        for ais_entry in ais_entries:
            if ais_entry.tan != emp.tan:
                continue
            if emp.tds_deducted > 0 and ais_entry.tds_deducted > 0:
                diff = emp.tds_deducted - ais_entry.tds_deducted
                if diff > 500:
                    findings.append(AuditFinding(
                        rule_id="A2-TDS-EXCESS",
                        severity="critical",
                        category="TDS Credit",
                        title=f"TDS Claimed > AIS/26AS — {emp.name or emp.tan}",
                        itr_value=emp.tds_deducted,
                        ais_value=ais_entry.tds_deducted,
                        difference=diff,
                        section="Sec 199 / Rule 37BA",
                        detail=(
                            "You're claiming more TDS credit than what's reported deposited. "
                            "CPC will reduce TDS credit to the 26AS amount and raise a demand."
                        ),
                        action=(
                            "Verify Form 26AS for actual TDS deposited. If employer deducted "
                            "more but hasn't deposited yet, follow up with employer."
                        ),
                        notice_risk="High",
                    ))
                elif diff < -500:
                    findings.append(AuditFinding(
                        rule_id="A2-TDS-UNDER",
                        severity="info",
                        category="TDS Credit",
                        title=f"TDS under-claimed — {emp.name or emp.tan}",
                        itr_value=emp.tds_deducted,
                        ais_value=ais_entry.tds_deducted,
                        difference=diff,
                        section="Sec 199",
                        detail="You may be entitled to more TDS credit than claimed.",
                        action="Check Form 26AS and claim full TDS credit.",
                        notice_risk="Low",
                    ))


def _check_interest_income(findings, taxpayer, ais_data):
    """Rule A3: Interest income reported vs AIS SFT data."""
    ais_savings = ais_data.get("interest_savings", 0)
    ais_fd = ais_data.get("interest_fd", 0)
    ais_total_interest = ais_savings + ais_fd

    itr_interest = taxpayer.other_income.interest_savings + taxpayer.other_income.interest_fd

    if ais_total_interest > 0:
        diff = ais_total_interest - itr_interest
        if diff > 1000:
            findings.append(AuditFinding(
                rule_id="A3-INTEREST",
                severity="warning" if diff < 10000 else "critical",
                category="Income Match",
                title="Interest Income Under-Reported",
                itr_value=itr_interest,
                ais_value=ais_total_interest,
                difference=diff,
                section="Sec 56(2)(id) / SFT-016",
                detail=(
                    f"Declared: ₹{itr_interest:,.0f} | AIS: ₹{ais_total_interest:,.0f}\n"
                    f"Under-reported by: ₹{diff:,.0f}\n\n"
                    "Banks report interest via SFT to IT dept. CPC will add "
                    "unreported interest and compute tax at slab rate."
                ),
                action=(
                    "Report the full interest amount. Savings interest qualifies "
                    "for 80TTA deduction (max ₹10,000). FD interest is fully taxable."
                ),
                notice_risk="Medium" if diff < 10000 else "High",
            ))


def _check_dividend_income(findings, taxpayer, ais_data):
    """Rule A4: Dividend income from AIS vs declared."""
    ais_div = ais_data.get("dividend_income", 0)
    itr_div = taxpayer.other_income.dividend

    if ais_div > 0 and abs(ais_div - itr_div) > 100:
        diff = ais_div - itr_div
        findings.append(AuditFinding(
            rule_id="A4-DIVIDEND",
            severity="warning",
            category="Income Match",
            title="Dividend Income Mismatch",
            itr_value=itr_div,
            ais_value=ais_div,
            difference=diff,
            section="Sec 56(2)(i) / Sec 194",
            detail=(
                f"Declared: ₹{itr_div:,.0f} | AIS: ₹{ais_div:,.0f}\n"
                "Dividends are fully taxable since FY 2020-21."
            ),
            action="Report the AIS dividend amount under 'Other Sources'.",
            notice_risk="Medium",
        ))


def _check_mf_capital_gains(findings, taxpayer, ais_data):
    """Rule A5: MF sale proceeds in AIS vs reported capital gains."""
    ais_mf_sale = ais_data.get("mf_sale_total", 0)
    if ais_mf_sale > 0:
        declared_cg = (
            taxpayer.capital_gains.stcg_111a +
            taxpayer.capital_gains.ltcg_112a
        )
        if declared_cg == 0 and not taxpayer.has_capital_gains:
            findings.append(AuditFinding(
                rule_id="A5-MF-CG",
                severity="critical",
                category="Capital Gains",
                title="MF Redemptions in AIS but No Capital Gains Declared",
                itr_value=0,
                ais_value=ais_mf_sale,
                difference=ais_mf_sale,
                section="Sec 111A / 112A / SFT-18-EMF",
                detail=(
                    f"AIS reports MF redemption proceeds of ₹{ais_mf_sale:,.0f} "
                    "but no capital gains declared.\n\n"
                    "NOTE: This requires ITR-2, not ITR-1. CPC WILL flag this."
                ),
                action=(
                    "Upload your Mutual Fund Capital Gains Report (CAMS/KFintech). "
                    "Even if you had a net loss, you must report in Schedule CG of ITR-2."
                ),
                notice_risk="High",
            ))
        elif ais_mf_sale > 0 and declared_cg > 0:
            findings.append(AuditFinding(
                rule_id="A5-MF-OK",
                severity="info",
                category="Capital Gains",
                title="MF Redemptions Detected — Capital Gains Declared",
                itr_value=declared_cg,
                ais_value=ais_mf_sale,
                difference=0,
                section="Sec 111A / 112A",
                detail=(
                    f"AIS MF Sale Proceeds: ₹{ais_mf_sale:,.0f}\n"
                    f"Declared CG (STCG+LTCG): ₹{declared_cg:,.0f}\n"
                    "Note: Sale proceeds ≠ Gains. Gains = Proceeds − Cost."
                ),
                action="Verify gains match your MF capital gains report.",
                notice_risk="Low",
            ))


def _check_high_value_transactions(findings, taxpayer, ais_data):
    """Rule A6: Flag high-value transactions that trigger scrutiny."""
    total_salary = taxpayer.total_gross_salary
    interest = taxpayer.other_income.interest_savings + taxpayer.other_income.interest_fd

    if interest > 500000:
        findings.append(AuditFinding(
            rule_id="A6-HIGH-INTEREST",
            severity="warning",
            category="High Value",
            title="High Interest Income — SFT Reporting Threshold",
            itr_value=interest,
            ais_value=interest,
            difference=0,
            section="Rule 114E / SFT",
            detail=(
                f"Interest income of ₹{interest:,.0f} exceeds ₹5L.\n"
                "Banks mandatorily report interest above ₹5L via SFT. "
                "This is automatically cross-checked."
            ),
            action="Ensure full interest is reported. Tax will be at slab rate.",
            notice_risk="Medium",
        ))

    ais_mf = ais_data.get("mf_sale_total", 0)
    if ais_mf > 1000000:
        findings.append(AuditFinding(
            rule_id="A6-HIGH-MF",
            severity="info",
            category="High Value",
            title="MF Redemptions > ₹10L — High-Value SFT",
            itr_value=ais_mf,
            ais_value=ais_mf,
            difference=0,
            section="Rule 114E(4)",
            detail=f"MF sale proceeds of ₹{ais_mf:,.0f} trigger SFT reporting.",
            action="Ensure capital gains are accurately reported in Schedule CG.",
            notice_risk="Medium",
        ))


def _check_under_reporting(findings, taxpayer, ais_data):
    """
    Rule A7: Section 270A — penalty for under-reporting.
    IT dept compares total income from all AIS sources vs ITR declared income.
    If under-reported by >₹50,000 or >10%, penalty = 50% of under-reported tax.
    """
    ais_salary = sum(e.income_credited for e in ais_data.get("salary_tds", []))
    ais_interest = ais_data.get("interest_savings", 0) + ais_data.get("interest_fd", 0)
    ais_dividend = ais_data.get("dividend_income", 0)

    ais_total_known = ais_salary + ais_interest + ais_dividend

    itr_total = (
        taxpayer.total_gross_salary +
        taxpayer.other_income.interest_savings +
        taxpayer.other_income.interest_fd +
        taxpayer.other_income.dividend
    )

    if ais_total_known > 0 and itr_total > 0:
        diff = ais_total_known - itr_total
        pct = (diff / ais_total_known) * 100 if ais_total_known > 0 else 0

        if diff > 50000 and pct > 10:
            findings.append(AuditFinding(
                rule_id="A7-UNDER-REPORT",
                severity="critical",
                category="Under-Reporting",
                title="Potential Under-Reporting — Sec 270A Penalty Risk",
                itr_value=itr_total,
                ais_value=ais_total_known,
                difference=diff,
                section="Sec 270A",
                detail=(
                    f"AIS Total Known Income: ₹{ais_total_known:,.0f}\n"
                    f"ITR Declared Income:    ₹{itr_total:,.0f}\n"
                    f"Under-reported:         ₹{diff:,.0f} ({pct:.1f}%)\n\n"
                    "Section 270A imposes a penalty of 50% of tax on "
                    "under-reported income if variance exceeds limits."
                ),
                action="Review all income sources and ensure full reporting.",
                notice_risk="High",
            ))
