"""
Salary income computation — Section 15, 16, 17 of the Income Tax Act.

Handles:
  - Multiple employer consolidation
  - Component-wise salary breakup
  - Section 10 exemptions (HRA, LTA, Gratuity, Leave Encashment)
  - Section 16 deductions (Standard Deduction, Professional Tax)
"""
from __future__ import annotations

from taxbuddy.models.taxpayer import (
    TaxPayer, EmployerInfo, HRADetails, City,
    Section10Exemptions, METRO_CITIES,
)
from taxbuddy.knowledge.tax_slabs import (
    OLD_REGIME_STANDARD_DEDUCTION, NEW_REGIME_STANDARD_DEDUCTION,
    GRATUITY_EXEMPT_LIMIT, LEAVE_ENCASHMENT_EXEMPT_LIMIT,
    HRA_METRO_PERCENT, HRA_NON_METRO_PERCENT,
)


def compute_hra_exemption(
    basic_salary_annual: float,
    hra_received_annual: float,
    rent_paid_annual: float,
    is_metro: bool,
    months: int = 12,
) -> dict:
    """
    Compute HRA exemption u/s 10(13A) read with Rule 2A.

    Exemption = Minimum of:
      (a) Actual HRA received
      (b) Rent paid - 10% of salary
      (c) 50% of salary (metro) or 40% (non-metro)

    'Salary' = Basic + DA (if part of retirement benefits).

    Returns dict with breakdown and final exemption amount.
    """
    if rent_paid_annual <= 0 or hra_received_annual <= 0:
        return {
            "actual_hra": hra_received_annual,
            "rent_minus_10pct": 0,
            "metro_pct_of_salary": 0,
            "exemption": 0,
            "taxable_hra": hra_received_annual,
            "reason": "No rent paid or no HRA received",
        }

    metro_pct = HRA_METRO_PERCENT if is_metro else HRA_NON_METRO_PERCENT

    a = hra_received_annual
    b = rent_paid_annual - (0.10 * basic_salary_annual)
    c = metro_pct * basic_salary_annual

    b = max(b, 0)
    exemption = min(a, b, c)

    return {
        "actual_hra": round(a),
        "rent_minus_10pct": round(b),
        "metro_pct_of_salary": round(c),
        "exemption": round(exemption),
        "taxable_hra": round(a - exemption),
        "formula_used": f"Min of: (a) HRA ₹{a:,.0f}, (b) Rent-10% ₹{b:,.0f}, (c) {'50' if is_metro else '40'}% basic ₹{c:,.0f}",
    }


def compute_salary_income(taxpayer: TaxPayer, regime: str = "old") -> dict:
    """
    Compute total salary income after exemptions and deductions.

    Returns comprehensive breakdown for ITR filing.
    """
    # Consolidate from all employers
    total_gross = 0.0
    total_basic = 0.0
    total_hra_received = 0.0
    total_lta_received = 0.0
    total_pf_employee = 0.0
    total_nps_employer = 0.0
    total_professional_tax = 0.0
    total_tds = 0.0
    total_gratuity = 0.0
    total_leave_encash = 0.0
    total_perquisites = 0.0

    employer_details = []

    for emp in taxpayer.employers:
        total_gross += emp.gross_salary
        total_basic += emp.basic_salary
        total_hra_received += emp.hra_received
        total_lta_received += emp.lta_received
        total_pf_employee += emp.pf_employee
        total_nps_employer += emp.nps_employer
        total_professional_tax += emp.professional_tax
        total_tds += emp.tds_deducted
        total_gratuity += emp.gratuity_received
        total_leave_encash += emp.leave_encashment
        total_perquisites += emp.perquisites_value

        employer_details.append({
            "name": emp.name,
            "gross": emp.gross_salary,
            "tds": emp.tds_deducted,
            "period": f"{emp.period_from} to {emp.period_to}",
        })

    # Section 10 Exemptions (available only under Old Regime)
    exemptions = Section10Exemptions()

    if regime == "old":
        # HRA Exemption
        if taxpayer.hra_details:
            hra_result = compute_hra_exemption(
                basic_salary_annual=total_basic,
                hra_received_annual=total_hra_received,
                rent_paid_annual=taxpayer.hra_details.rent_paid_annual,
                is_metro=taxpayer.is_metro,
            )
            exemptions.hra = hra_result["exemption"]
        elif total_hra_received > 0 and taxpayer.exemptions.hra > 0:
            exemptions.hra = taxpayer.exemptions.hra

        # LTA Exemption
        exemptions.lta = taxpayer.exemptions.lta

        # Gratuity Exemption u/s 10(10)
        exemptions.gratuity = min(total_gratuity, GRATUITY_EXEMPT_LIMIT)

        # Leave Encashment u/s 10(10AA)
        exemptions.leave_encashment = min(total_leave_encash, LEAVE_ENCASHMENT_EXEMPT_LIMIT)

        # Children Education Allowance u/s 10(14)(ii)
        exemptions.children_education = taxpayer.exemptions.children_education

        # Other prescribed allowances u/s 10(14)(i) Rule 2BB
        exemptions.other_prescribed = taxpayer.exemptions.other_prescribed

        # Standard Deduction u/s 16
        exemptions.standard_deduction = OLD_REGIME_STANDARD_DEDUCTION
    else:
        # New regime: only standard deduction and employer NPS deduction available
        exemptions.standard_deduction = NEW_REGIME_STANDARD_DEDUCTION
        # Gratuity and leave encashment exemptions available in both regimes
        exemptions.gratuity = min(total_gratuity, GRATUITY_EXEMPT_LIMIT)
        exemptions.leave_encashment = min(total_leave_encash, LEAVE_ENCASHMENT_EXEMPT_LIMIT)

    exemptions.professional_tax = total_professional_tax

    # Compute net salary
    total_sec10 = exemptions.total
    net_after_sec10 = total_gross - total_sec10
    sec16_deductions = exemptions.standard_deduction + exemptions.professional_tax
    salary_income = net_after_sec10 - sec16_deductions

    return {
        "gross_salary": round(total_gross),
        "total_basic": round(total_basic),
        "total_hra_received": round(total_hra_received),
        "total_lta_received": round(total_lta_received),
        "employer_details": employer_details,
        "sec10_exemptions": {
            "hra_10_13a": round(exemptions.hra),
            "lta_10_5": round(exemptions.lta),
            "gratuity_10_10": round(exemptions.gratuity),
            "leave_encash_10_10aa": round(exemptions.leave_encashment),
            "children_edu_10_14_ii": round(exemptions.children_education),
            "other_10_14_i": round(exemptions.other_prescribed),
            "total": round(total_sec10),
        },
        "sec16_deductions": {
            "standard_deduction": round(exemptions.standard_deduction),
            "professional_tax": round(exemptions.professional_tax),
            "total": round(sec16_deductions),
        },
        "net_salary_after_sec10": round(net_after_sec10),
        "salary_income": round(salary_income),
        "total_tds_salary": round(total_tds),
        "regime": regime,
    }
