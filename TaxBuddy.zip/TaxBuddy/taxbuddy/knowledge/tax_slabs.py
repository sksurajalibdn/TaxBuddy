"""
Indian Income Tax Slabs for FY 2025-26 (AY 2026-27).

Source: Finance Act 2025 / Finance Act 2024 (for new regime updates).
All amounts in INR.
"""

# ---------- NEW TAX REGIME (Default from FY 2023-24 onwards) ----------
# Updated per Union Budget 2025 — Sec 115BAC(1A)
NEW_REGIME_SLABS_FY2025_26 = [
    (0,       400000,  0.00),
    (400000,  800000,  0.05),
    (800000,  1200000, 0.10),
    (1200000, 1600000, 0.15),
    (1600000, 2000000, 0.20),
    (2000000, 2400000, 0.25),
    (2400000, float("inf"), 0.30),
]

NEW_REGIME_STANDARD_DEDUCTION = 75000
NEW_REGIME_REBATE_LIMIT = 1200000  # Rebate u/s 87A — no tax up to 12L
NEW_REGIME_MARGINAL_RELIEF_LIMIT = 1260000  # Marginal relief up to ~12.6L

# ---------- OLD TAX REGIME ----------
OLD_REGIME_SLABS_BELOW_60 = [
    (0,       250000,  0.00),
    (250000,  500000,  0.05),
    (500000,  1000000, 0.20),
    (1000000, float("inf"), 0.30),
]

OLD_REGIME_SLABS_60_TO_80 = [
    (0,       300000,  0.00),
    (300000,  500000,  0.05),
    (500000,  1000000, 0.20),
    (1000000, float("inf"), 0.30),
]

OLD_REGIME_SLABS_ABOVE_80 = [
    (0,       500000,  0.00),
    (500000,  1000000, 0.20),
    (1000000, float("inf"), 0.30),
]

OLD_REGIME_STANDARD_DEDUCTION = 50000
OLD_REGIME_REBATE_LIMIT = 500000  # Rebate u/s 87A — no tax up to 5L (old)

# ---------- SURCHARGE RATES (Both Regimes) ----------
SURCHARGE_SLABS_OLD = [
    (0,        5000000,  0.00),
    (5000000,  10000000, 0.10),
    (10000000, 20000000, 0.15),
    (20000000, 50000000, 0.25),
    (50000000, float("inf"), 0.37),
]

SURCHARGE_SLABS_NEW = [
    (0,        5000000,  0.00),
    (5000000,  10000000, 0.10),
    (10000000, 20000000, 0.15),
    (20000000, float("inf"), 0.25),  # Capped at 25% in new regime
]

SURCHARGE_CAP_ON_CG_112A = 0.15  # Max 15% surcharge on LTCG u/s 112A

HEALTH_AND_EDUCATION_CESS = 0.04  # 4% on tax + surcharge

# ---------- CAPITAL GAINS TAX RATES (Post July 23, 2024 Budget) ----------
STCG_RATE_111A = 0.20     # Listed equity / equity MF (was 15%, now 20%)
LTCG_RATE_112A = 0.125    # Listed equity / equity MF (was 10%, now 12.5%)
LTCG_EXEMPTION_112A = 125000  # Annual exemption (was 1L, now 1.25L)
LTCG_RATE_112 = 0.125     # Other assets without indexation (was 20% with indexation)

# Holding period thresholds for equity MF
EQUITY_MF_LTCG_HOLDING_MONTHS = 12  # >12 months = LTCG
DEBT_MF_LTCG_HOLDING_MONTHS = 24    # >24 months = LTCG (but taxed at slab)

# ---------- KEY LIMITS ----------
SECTION_80C_LIMIT = 150000
SECTION_80CCD_1B_LIMIT = 50000
SECTION_80D_SELF_LIMIT = 25000
SECTION_80D_SELF_SENIOR_LIMIT = 50000
SECTION_80D_PARENTS_LIMIT = 25000
SECTION_80D_PARENTS_SENIOR_LIMIT = 50000
SECTION_80D_PREVENTIVE_HEALTH = 5000  # Within overall 80D limit
SECTION_80DD_LIMIT = 75000
SECTION_80DD_SEVERE_LIMIT = 125000
SECTION_80DDB_LIMIT = 40000
SECTION_80DDB_SENIOR_LIMIT = 100000
SECTION_80E_NO_LIMIT = True
SECTION_80EEA_LIMIT = 150000
SECTION_80G_QUALIFYING_LIMIT_PERCENT = 0.10  # 10% of adjusted GTI
SECTION_80GG_LIMIT = 60000  # 5000/month
SECTION_80TTA_LIMIT = 10000
SECTION_80TTB_LIMIT = 50000  # Senior citizens only

HRA_METRO_PERCENT = 0.50  # 50% of basic for metro cities
HRA_NON_METRO_PERCENT = 0.40  # 40% of basic for non-metro cities

GRATUITY_EXEMPT_LIMIT = 2000000  # 20L (non-govt employees)
LEAVE_ENCASHMENT_EXEMPT_LIMIT = 2500000  # 25L

LTA_BLOCK_YEARS = "2022-2025"  # Current block year period


def compute_tax_on_slabs(taxable_income: float, slabs: list) -> float:
    """Compute tax using progressive slab rates."""
    tax = 0.0
    for lower, upper, rate in slabs:
        if taxable_income <= lower:
            break
        taxable_in_slab = min(taxable_income, upper) - lower
        tax += taxable_in_slab * rate
    return tax


def compute_surcharge(tax: float, total_income: float, slabs: list) -> float:
    """Compute surcharge on tax based on total income."""
    for lower, upper, rate in slabs:
        if lower < total_income <= upper:
            surcharge = tax * rate
            if rate > 0:
                marginal_income = total_income - lower
                marginal_tax = tax + marginal_income
                surcharge = min(surcharge, marginal_income)
            return tax * rate
    return 0.0


def compute_full_tax(
    taxable_income: float,
    regime: str = "old",
    age: int = 30,
    ltcg_112a: float = 0.0,
    stcg_111a: float = 0.0,
) -> dict:
    """
    Compute complete tax liability including surcharge and cess.

    Returns dict with breakdown:
      - tax_on_normal_income
      - tax_on_stcg_111a
      - tax_on_ltcg_112a
      - total_tax_before_surcharge
      - surcharge
      - cess
      - total_tax
    """
    normal_income = taxable_income - ltcg_112a - stcg_111a
    normal_income = max(normal_income, 0)

    if regime == "new":
        slabs = NEW_REGIME_SLABS_FY2025_26
        rebate_limit = NEW_REGIME_REBATE_LIMIT
        surcharge_slabs = SURCHARGE_SLABS_NEW
    else:
        if age >= 80:
            slabs = OLD_REGIME_SLABS_ABOVE_80
        elif age >= 60:
            slabs = OLD_REGIME_SLABS_60_TO_80
        else:
            slabs = OLD_REGIME_SLABS_BELOW_60
        rebate_limit = OLD_REGIME_REBATE_LIMIT
        surcharge_slabs = SURCHARGE_SLABS_OLD

    tax_normal = compute_tax_on_slabs(normal_income, slabs)
    tax_stcg = stcg_111a * STCG_RATE_111A
    ltcg_taxable = max(ltcg_112a - LTCG_EXEMPTION_112A, 0)
    tax_ltcg = ltcg_taxable * LTCG_RATE_112A

    total_tax = tax_normal + tax_stcg + tax_ltcg

    # Rebate u/s 87A (not on special rate incomes in new regime context)
    if regime == "new" and taxable_income <= rebate_limit:
        rebate = min(total_tax, 60000)
        total_tax -= rebate
    elif regime == "old" and taxable_income <= rebate_limit:
        rebate = min(total_tax, 12500)
        total_tax -= rebate

    total_tax = max(total_tax, 0)

    surcharge = compute_surcharge(total_tax, taxable_income, surcharge_slabs)
    cess = (total_tax + surcharge) * HEALTH_AND_EDUCATION_CESS

    return {
        "normal_income": normal_income,
        "tax_on_normal": round(tax_normal),
        "tax_on_stcg_111a": round(tax_stcg),
        "ltcg_taxable": round(ltcg_taxable),
        "tax_on_ltcg_112a": round(tax_ltcg),
        "total_tax_before_surcharge": round(total_tax),
        "surcharge": round(surcharge),
        "cess": round(cess),
        "total_tax": round(total_tax + surcharge + cess),
    }
