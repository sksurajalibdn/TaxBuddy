"""Indian income tax knowledge base - rules, slabs, and references."""
