"""
Quick reference for ITR filing — documents checklist and pre-filing steps.
"""

DOCUMENTS_CHECKLIST = {
    "essential": [
        {
            "name": "Form 16",
            "description": "TDS Certificate from employer(s) — Part A (TDS details) + Part B (Salary computation)",
            "where_to_get": "From your employer's HR/Payroll department",
            "format": "PDF",
            "why_needed": "Primary salary income proof, TDS credit, and employer-computed deductions",
        },
        {
            "name": "AIS (Annual Information Statement)",
            "description": "Comprehensive financial information reported to IT dept by banks, employers, MF houses, etc.",
            "where_to_get": "eportal.incometax.gov.in → AIS/TIS → View AIS",
            "format": "PDF",
            "why_needed": "Cross-verify all income sources — IT dept uses this for scrutiny",
        },
        {
            "name": "Form 26AS (Annual Tax Statement)",
            "description": "TDS/TCS/Advance Tax details as reported by deductors",
            "where_to_get": "TRACES portal (traces.gov.in) or through e-filing portal",
            "format": "PDF",
            "why_needed": "TDS credit verification — must match what you claim in ITR",
        },
    ],
    "if_applicable": [
        {
            "name": "Mutual Fund Capital Gains Report",
            "description": "Transaction-wise STCG/LTCG from MF redemptions during the FY",
            "where_to_get": "CAMS (camsonline.com) or KFinTech (kfintech.com) → Capital Gains Statement",
            "format": "Excel (.xlsx)",
            "why_needed": "Required for Schedule CG in ITR-2, including Table F quarterly breakup",
        },
        {
            "name": "Payslips (Monthly)",
            "description": "Component-wise salary breakup showing Basic, HRA, Special Allowance, etc.",
            "where_to_get": "From employer's HRMS portal",
            "format": "PDF",
            "why_needed": "Needed when Form 16 doesn't have detailed salary component breakup (esp. for HRA calculation)",
        },
        {
            "name": "Rent Receipts / Rental Agreement",
            "description": "Proof of rent paid for HRA exemption claim",
            "where_to_get": "From landlord",
            "format": "PDF/Physical",
            "why_needed": "Required if rent > ₹1L/year. Landlord PAN mandatory if rent > ₹1L/year",
        },
        {
            "name": "Home Loan Statement",
            "description": "Interest certificate from bank showing principal + interest breakup",
            "where_to_get": "From your home loan bank",
            "format": "PDF",
            "why_needed": "For claiming Sec 24(b) interest deduction and 80C principal deduction",
        },
        {
            "name": "80D — Health Insurance Premium Receipts",
            "description": "Premium paid for self/family and parents health insurance",
            "where_to_get": "From insurance company",
            "format": "PDF",
            "why_needed": "Sec 80D deduction — up to ₹25K self + ₹50K parents (senior)",
        },
        {
            "name": "80G — Donation Receipts",
            "description": "Receipts for donations to eligible funds/institutions",
            "where_to_get": "From the organization you donated to",
            "format": "PDF",
            "why_needed": "50% or 100% deduction under Sec 80G depending on the fund",
        },
        {
            "name": "NPS Statement (PRAN)",
            "description": "Annual contribution statement showing employer and employee contributions",
            "where_to_get": "npstrust.org.in → PRAN login",
            "format": "PDF",
            "why_needed": "For 80CCD(1B) and 80CCD(2) deductions",
        },
        {
            "name": "Share Trading Statement",
            "description": "P&L report from your broker (Zerodha, Groww, etc.)",
            "where_to_get": "Broker platform → Tax P&L report",
            "format": "Excel/PDF",
            "why_needed": "For capital gains reporting in Schedule CG",
        },
    ],
}

PRE_FILING_CHECKLIST = [
    "Link Aadhaar to PAN (mandatory for filing)",
    "Pre-validate bank account on e-filing portal (for refund)",
    "Download AIS and verify all income entries",
    "Download Form 26AS and cross-check TDS credits",
    "Collect Form 16 from all employers (if job change during year)",
    "Get MF capital gains report if you redeemed any mutual funds",
    "Calculate HRA exemption if paying rent",
    "Compare Old vs New regime tax liability BEFORE starting",
    "Keep rent receipts ready if claiming HRA (landlord PAN if rent > ₹1L/year)",
    "Note: Due date for FY 2025-26 is July 31, 2026 (unless extended)",
]
