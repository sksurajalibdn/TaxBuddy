"""
Indian Income Tax Rules Reference — sourced from the Income Tax Act, 1961
and CBDT notifications / circulars.

This module provides authoritative rule references so that TaxBuddy never
makes assumptions — it cites the exact section, rule, or notification.

Updated for FY 2025-26 (AY 2026-27).
"""

# ── ITR Form Selection Rules ─────────────────────────────────────────
ITR_SELECTION_RULES = {
    "ITR-1": {
        "section": "Rule 12(1)(b)(i)",
        "description": "Sahaj — for Resident Individuals only",
        "conditions": [
            "Total income up to Rs 50 Lakhs",
            "Income from Salary / Pension",
            "Income from One House Property (not brought-forward loss)",
            "Income from Other Sources (interest, dividends, etc.)",
            "Agricultural income up to Rs 5,000",
        ],
        "cannot_use_if": [
            "Non-resident or RNOR",
            "Total income exceeds Rs 50 Lakhs",
            "Has capital gains of any kind",
            "Has income from more than one house property",
            "Has income from business or profession",
            "Has foreign assets or foreign income",
            "Is a director in any company",
            "Holds unlisted equity shares",
            "Has brought forward / carry forward losses",
            "Claims deduction u/s 57 other than family pension",
            "Has agricultural income exceeding Rs 5,000",
            "Has income from LTCG / STCG",
        ],
    },
    "ITR-2": {
        "section": "Rule 12(1)(b)(ii)",
        "description": "For Individuals / HUFs not having business/profession income",
        "conditions": [
            "Total income above Rs 50 Lakhs (or below with CG)",
            "Has capital gains",
            "Has income from more than one house property",
            "Has foreign assets or foreign income",
            "Non-resident filing",
            "Director in a company",
            "Holds unlisted equity shares",
        ],
    },
}

# ── HRA Exemption Rules ──────────────────────────────────────────────
HRA_RULES = {
    "section": "Section 10(13A) read with Rule 2A",
    "notification": "CBDT Notification No. SO 1724(E) dated 28.05.2018",
    "exemption_formula": "Minimum of: (a) Actual HRA received, (b) Rent paid minus 10% of salary, (c) 50% of salary (metro) or 40% (non-metro)",
    "salary_definition": "Basic salary + DA (if forming part of retirement benefits) + commission (if fixed % of turnover)",
    "metro_cities": "Delhi, Mumbai, Kolkata, Chennai for FY 2025-26. Bengaluru & Hyderabad classified metro only from FY 2026-27 (April 2026) per GOI notification.",
    "important_notes": [
        "Rent receipts required if rent > Rs 1 lakh/year",
        "PAN of landlord required if rent > Rs 1 lakh/year",
        "Not available if living in own house or not paying rent",
        "Available under OLD regime only (Sec 115BAC disallows under New)",
        "Can be claimed even if employer didn't provide HRA exemption (e.g., when employee was on New regime at employer)",
    ],
    "lesson_learned": "When filing ITR, salary breakup must be entered BEFORE claiming HRA exemption — the portal validates HRA exemption against actual HRA received in salary schedule.",
}

# ── LTA Rules ─────────────────────────────────────────────────────────
LTA_RULES = {
    "section": "Section 10(5) read with Rule 2B",
    "conditions": [
        "Only domestic travel within India",
        "Only economy class airfare or AC first class rail fare",
        "Limited to actual travel cost — not total LTA received",
        "Allowed twice in a block of 4 calendar years",
        "Current block: 2022-2025 (Jan 2022 to Dec 2025)",
        "Next block: 2026-2029",
        "Carry-forward: Unused journey from one block can be carried to first year of next block",
    ],
    "important_notes": [
        "Travel bills (flight/train tickets) must be retained",
        "Family includes spouse, children (max 2 born after 01/10/1998), dependent parents/siblings",
        "Available under OLD regime only",
    ],
}

# ── Section 80C Rules ─────────────────────────────────────────────────
SECTION_80C_RULES = {
    "section": "Section 80C / 80CCC / 80CCD(1)",
    "limit": 150000,
    "components": {
        "EPF (Employee PF contribution)": "Auto from salary",
        "PPF (Public Provident Fund)": "Max 1.5L/year",
        "ELSS (Equity Linked Savings Scheme)": "3-year lock-in",
        "NSC (National Savings Certificate)": "5-year tenure",
        "Tax Saver FD": "5-year lock-in",
        "Life Insurance Premium": "Max 10% of sum assured",
        "Tuition Fees": "Up to 2 children, actual fees",
        "Home Loan Principal Repayment": "Subject to conditions",
        "Sukanya Samriddhi Yojana": "For girl child",
        "Senior Citizen Savings Scheme": "For 60+ age",
    },
    "note": "Combined limit of Rs 1,50,000 for 80C + 80CCC + 80CCD(1). Available only under Old Regime.",
}

# ── Section 80D Rules ─────────────────────────────────────────────────
SECTION_80D_RULES = {
    "section": "Section 80D",
    "limits": {
        "self_family_below_60": 25000,
        "self_family_senior": 50000,
        "parents_below_60": 25000,
        "parents_senior": 50000,
        "preventive_health_checkup": 5000,  # Within overall limit
    },
    "max_total": 100000,  # Self senior + parents senior
    "note": "Preventive health checkup of Rs 5,000 is within the overall limit, not additional.",
}

# ── Capital Gains Rules ──────────────────────────────────────────────
CAPITAL_GAINS_RULES = {
    "source": "Finance (No. 2) Act 2024, effective from 23 July 2024",
    "equity_mutual_funds": {
        "holding_period_ltcg": ">12 months",
        "stcg_rate": "20% u/s 111A (was 15%)",
        "ltcg_rate": "12.5% u/s 112A (was 10%)",
        "ltcg_exemption": "Rs 1,25,000 per year (was Rs 1,00,000)",
    },
    "debt_mutual_funds": {
        "holding_period": "Always STCG (taxed at slab rate) for funds purchased after 01/04/2023",
        "note": "No LTCG benefit for debt MF purchased after April 2023",
    },
    "listed_shares": {
        "stcg_rate": "20% u/s 111A",
        "ltcg_rate": "12.5% u/s 112A",
        "ltcg_exemption": "Rs 1,25,000 per year",
    },
    "table_f_quarterly_breakup": {
        "description": "Schedule CG Table F requires period-wise breakup of capital gains",
        "periods": [
            "(i) Up to 15th June",
            "(ii) 16th June to 15th September",
            "(iii) 16th September to 15th December",
            "(iv) 16th December to 15th March",
            "(v) 16th March to 31st March",
        ],
        "lesson_learned": "Table F quarterly breakup must EXACTLY match item 3iii of Schedule BFLA. Even Rs 1 mismatch causes validation error. Use exact redemption dates to categorize into correct period.",
    },
}

# ── Surcharge Threshold Warning ──────────────────────────────────────
SURCHARGE_THRESHOLDS = {
    "50_lakh": {
        "threshold": 5000000,
        "surcharge_rate": 0.10,
        "impact": "10% surcharge on total tax — significant jump in liability",
        "strategy": "If income is slightly above 50L, explore deductions (80C, 80D, 80CCD(1B), 80CCD(2), 80DDB, HRA, LTA) to bring it below 50L",
        "lesson_learned": "Even Rs 1 above 50L triggers 10% surcharge on ENTIRE tax. Worth spending effort to optimize deductions to stay below threshold.",
    },
    "1_crore": {
        "threshold": 10000000,
        "surcharge_rate": 0.15,
    },
}

# ── Portal Validation Lessons ────────────────────────────────────────
PORTAL_LESSONS = [
    {
        "issue": "HRA exemption rejected with validation error",
        "cause": "Salary breakup (Basic, HRA component) not entered in Schedule S before claiming exemption in Section 10(13A)",
        "fix": "Always fill salary details FIRST with component-wise breakup, then claim exemptions",
    },
    {
        "issue": "Section 80C fields greyed out",
        "cause": "Portal auto-populates 80C from employer Form 16 data. Manual salary entry may not trigger auto-population",
        "fix": "Delete the 80C entry and re-add it fresh. Or check if there's a toggle to edit auto-populated values",
    },
    {
        "issue": "Multiple zero-value rows in Section 10 exemptions causing validation errors",
        "cause": "Portal pre-fills empty exemption rows from AIS/Form 26AS without selecting 'Nature' dropdown",
        "fix": "Delete ALL zero-value rows in Section 3 (Exempt Allowances) that don't have a valid Nature selected",
    },
    {
        "issue": "Gratuity exemption validation error",
        "cause": "Gratuity not entered as a separate salary component under Section 17(1) in employer details",
        "fix": "Add Gratuity as a distinct line item in salary breakup, so portal can match 10(10) exemption against actual gratuity received",
    },
    {
        "issue": "Capital gains Table F quarterly breakup mismatch",
        "cause": "Table F periods use specific date ranges (not calendar quarters). Sum must exactly match Schedule BFLA item 3iii",
        "fix": "Use redemption dates to categorize into exact Table F periods. Adjust rounding to ensure exact match",
    },
    {
        "issue": "Driver/Vehicle/Fuel allowance rejected under Section 10(14)(i)",
        "cause": "These allowances are related to Rule 3(2) car perquisite valuation, not genuinely exempt under 10(14)(i) for private sector employees",
        "fix": "Either claim under correct head or skip if total income is safely below surcharge threshold without it",
    },
    {
        "issue": "City type wrong for HRA (Non-Metro instead of Metro)",
        "cause": "Bangalore/Bengaluru not auto-detected as Metro by portal",
        "fix": "Manually change to Metro for Delhi, Mumbai, Kolkata, Chennai, Bangalore, Hyderabad",
    },
    {
        "issue": "Secondary address validation error",
        "cause": "Portal requires answering 'Is secondary address same as primary?'",
        "fix": "Select 'Yes' if only one address, or fill secondary address details",
    },
]

# ── Section 10(14) Prescribed Allowances ─────────────────────────────
PRESCRIBED_ALLOWANCES_SEC10_14 = {
    "rule_2bb_1": {
        "section": "Sec 10(14)(i) read with Rule 2BB(1)",
        "description": "Allowances to meet expenses wholly, necessarily, and exclusively in performance of duties",
        "examples": [
            "Conveyance allowance for official travel",
            "Daily allowance during tour/transfer",
            "Helper/academic allowance",
            "Uniform allowance",
        ],
    },
    "rule_2bb_2": {
        "section": "Sec 10(14)(ii) read with Rule 2BB(2)",
        "description": "Specific personal allowances granted to meet personal expenses at the place of posting",
        "examples": [
            "Children Education Allowance (Rs 100/month per child, max 2 children)",
            "Hostel Expenditure Allowance (Rs 300/month per child, max 2 children)",
            "Transport allowance for disabled (Rs 3,200/month)",
            "Tribal area allowance",
            "Border area allowance",
        ],
    },
}

# ── Multiple Employer Handling ───────────────────────────────────────
MULTIPLE_EMPLOYER_RULES = {
    "section": "Section 192(2) read with Rule 26B",
    "key_points": [
        "Previous employer income should be reported to new employer for correct TDS",
        "If not reported, employee must reconcile in ITR",
        "Form 16 from each employer to be obtained separately",
        "TDS credit from all employers to be verified against Form 26AS/AIS",
        "HRA/LTA exemptions can be claimed at ITR stage even if not claimed at employer level",
        "If employee was on New Regime at one employer and Old Regime at another, ITR filing determines the final regime choice",
    ],
    "lesson_learned": "When switching jobs mid-year, always consolidate salary from both employers. Exemptions not claimed at previous employer (due to different regime) can be claimed while filing ITR under chosen regime.",
}
