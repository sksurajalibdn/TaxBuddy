"""Launch TaxBuddy web app via `taxbuddy` command."""
import sys
import os


def main():
    from streamlit.web import cli as st_cli
    app_path = os.path.join(os.path.dirname(__file__), "app.py")
    sys.argv = ["streamlit", "run", app_path, "--server.headless=true"]
    st_cli.main()


if __name__ == "__main__":
    main()
