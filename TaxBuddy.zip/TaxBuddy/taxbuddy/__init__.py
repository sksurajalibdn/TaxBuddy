"""TaxBuddy - AI-powered Indian Income Tax Filing Assistant for ITR-1 and ITR-2."""

__version__ = "2.0.0"
