"""Allow running TaxBuddy with `python -m taxbuddy`."""
from taxbuddy.run import main

if __name__ == "__main__":
    main()
