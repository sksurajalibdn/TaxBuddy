# TaxBuddy v2 — Installation Guide (Web App)

## What You Get

A beautiful **web application** that opens in your browser — drag-and-drop your tax documents, and TaxBuddy does the rest.

---

## Quick Install (3 Steps)

### Step 1: Install Python

| OS | Command |
|----|---------|
| **Mac** | `brew install python` or download from [python.org](https://www.python.org/downloads/) |
| **Windows** | Download from [python.org](https://www.python.org/downloads/) (check "Add to PATH") |
| **Linux** | `sudo apt install python3 python3-pip` |

Verify: `python3 --version` (need 3.9+)

### Step 2: Install TaxBuddy

```bash
# Unzip the TaxBuddy folder, then:
cd TaxBuddy
pip3 install .
```

Or use the install script:
```bash
chmod +x install.sh
./install.sh
```

### Step 3: Launch

```bash
taxbuddy
```

Or:
```bash
python3 -m taxbuddy
```

The app opens at **http://localhost:8501** in your default browser.

---

## Alternative: Run Without Installing

```bash
cd TaxBuddy
pip3 install -r requirements.txt
streamlit run taxbuddy/app.py
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `taxbuddy: command not found` | Run `python3 -m taxbuddy` instead, or add `~/.local/bin` to PATH |
| `pip3: command not found` | Run `python3 -m pip install .` |
| Browser doesn't open | Go to http://localhost:8501 manually |
| Port 8501 in use | `streamlit run taxbuddy/app.py --server.port 8502` |

---

## What to Keep Ready

1. **Form 16** (PDF) — from your employer's HR
2. **AIS** (PDF) — download from eportal.incometax.gov.in → AIS/TIS
3. **Form 26AS** (PDF) — from TRACES portal
4. **Payslip** (PDF) — optional, latest month
5. **MF Capital Gains Report** (Excel .xlsx) — from your AMC/broker
