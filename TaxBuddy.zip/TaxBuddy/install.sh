#!/bin/bash
# TaxBuddy v2 Installer — Web App Edition
set -e

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║            🧾 TaxBuddy v2 — Web App Installer              ║"
echo "║       Indian Income Tax Filing Assistant (ITR-1/ITR-2)      ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed."
    echo "   Install from https://www.python.org/downloads/"
    exit 1
fi

PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "✅ Python $PYTHON_VERSION found"

# Check pip
if ! python3 -m pip --version &> /dev/null; then
    echo "❌ pip is not installed. Run: python3 -m ensurepip --upgrade"
    exit 1
fi
echo "✅ pip found"

# Install
echo ""
echo "📦 Installing TaxBuddy..."
echo ""
python3 -m pip install . --quiet

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                  ✅ Installation Complete!                  ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║                                                            ║"
echo "║  To launch TaxBuddy, run:                                  ║"
echo "║                                                            ║"
echo "║     taxbuddy                                               ║"
echo "║                                                            ║"
echo "║  Or alternatively:                                         ║"
echo "║                                                            ║"
echo "║     python3 -m taxbuddy                                    ║"
echo "║                                                            ║"
echo "║  TaxBuddy will open in your browser at:                    ║"
echo "║     http://localhost:8501                                   ║"
echo "║                                                            ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""
